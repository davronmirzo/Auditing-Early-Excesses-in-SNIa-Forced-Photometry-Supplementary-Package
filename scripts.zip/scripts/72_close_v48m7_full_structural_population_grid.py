from __future__ import annotations

import argparse
import importlib.util
import json
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd


VERSION = "v48m7_full_structural_population_grid_1.0.0"


def load_module(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot load {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def truthy(series: pd.Series) -> pd.Series:
    return series.astype(str).str.strip().str.lower().isin({"true", "1", "yes", "y", "t"})


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=".")
    args = parser.parse_args()
    root = Path(args.root).resolve()
    gridmod = load_module(root / "scripts/71_run_v48m7_matched_structural_grid.py", "v48m7_grid_defs")
    infer = load_module(root / "scripts/70_close_v48m6_population_inference.py", "v48m7_inference_math")

    archive = pd.read_csv(root / "results/v48m6_end_to_end/production/v48m6_injection_trials_43050.csv.gz")
    candidates = pd.read_csv(root / "results/v48m7_matched_endpoint/structural_grid/v48m7_structural_candidate_trials_455.csv.gz")
    observed = pd.read_csv(root / "results/v48m7_matched_endpoint/structural_grid/v48m7_observed_matched_endpoint_summary_13.csv")
    objects = pd.read_csv(root / "results/v48_canonical/baseline/v48b_object_summary.csv")
    fits = pd.read_csv(root / "results/v48_canonical/baseline/v48b_object_band_fits.csv")
    canonical = json.loads((root / "config/v48g1_injection_contract.json").read_text())
    templates = [x["template_id"] for x in canonical["templates"]]
    if len(archive) != 43050 or len(candidates) != 455 or len(observed) != 13:
        raise RuntimeError("V48M7 frozen input counts changed")
    if not observed["observed_structural_n"].eq(0).all():
        raise RuntimeError("A nonzero observed structural cell requires a separately frozen count model")

    objects["fit_valid_bool"] = truthy(objects["fit_valid"])
    objects["median_chi2_dof"] = pd.to_numeric(objects["median_chi2_dof"], errors="coerce")
    fits = fits[truthy(fits["valid_fit"])].copy()
    fits["object_id"] = fits["object_id"].astype(str)
    fits["band"] = fits["band"].astype(str).str.lower()
    both_band_ids = {
        oid for oid, q in fits.groupby("object_id")
        if {"c", "o"}.issubset(set(q["band"]))
    }

    key_cols = ["object_id", "template_id", "realization"]
    archive["object_id"] = archive["object_id"].astype(str)
    candidates["object_id"] = candidates["object_id"].astype(str)
    candidate_index = candidates.set_index(key_cols)
    raw_rows: list[dict[str, Any]] = []
    structural_rows: list[dict[str, Any]] = []
    object_rows: list[dict[str, Any]] = []
    attrition_rows: list[dict[str, Any]] = []
    bootstrap_rows: list[dict[str, Any]] = []
    rng = np.random.default_rng(4807)

    for axis, setting, config_id, threshold in gridmod.AXIS_CONFIGS:
        cfg = observed[(observed["axis"] == axis) & (observed["setting"] == setting)].iloc[0]
        ids = set(objects.loc[objects["fit_valid_bool"] & objects["median_chi2_dof"].le(float(threshold)), "object_id"].astype(str))
        if len(ids) != int(cfg["denominator_n"]):
            raise RuntimeError(f"Denominator mismatch for {axis} {setting}")
        raw_flag = gridmod.UNIQUE_CONFIGS[config_id][3]
        structural_flag = f"{config_id}__confirmed"
        single_flag = f"{config_id}__single"
        two_flag = f"{config_id}__two_band"
        lono_attempted_flag = f"{config_id}__lono_attempted"
        lono_survives_flag = f"{config_id}__lono_survives"
        for template in templates:
            subset = archive[(archive["object_id"].isin(ids)) & (archive["template_id"] == template)].copy()
            if len(subset) != len(ids) * 30 or subset.duplicated(key_cols).any():
                raise RuntimeError(f"Incomplete trial cell for {axis} {setting} {template}")
            subset["raw_hit"] = truthy(subset[raw_flag])
            joined = subset[key_cols].merge(
                candidates[key_cols + [structural_flag, single_flag, two_flag, lono_attempted_flag, lono_survives_flag]],
                on=key_cols,
                how="left",
                validate="one_to_one",
            )
            for col in (structural_flag, single_flag, two_flag, lono_attempted_flag, lono_survives_flag):
                joined[col] = truthy(joined[col])
            subset["structural_hit"] = joined[structural_flag].to_numpy(bool)
            if (subset["structural_hit"] & ~subset["raw_hit"]).any():
                raise RuntimeError(f"Structural hit without raw hit for {axis} {setting} {template}")

            by_object = subset.groupby("object_id", as_index=False).agg(
                trials=("structural_hit", "size"),
                structural_recovered=("structural_hit", "sum"),
                raw_recovered=("raw_hit", "sum"),
            )
            if len(by_object) != len(ids) or not by_object["trials"].eq(30).all():
                raise RuntimeError(f"Incomplete object grid for {axis} {setting} {template}")
            by_object["structural_efficiency"] = by_object["structural_recovered"] / 30.0
            by_object["raw_efficiency"] = by_object["raw_recovered"] / 30.0
            eps_struct = by_object["structural_efficiency"].to_numpy(float)
            eps_raw = by_object["raw_efficiency"].to_numpy(float)
            structural_f95, structural_capped = infer.frequentist_f95(eps_struct)
            raw_f95, raw_capped = infer.frequentist_f95(eps_raw)

            common = {
                "axis": axis,
                "setting": setting,
                "config_id": config_id,
                "template_id": template,
                "objects": len(ids),
                "trials": len(subset),
                "quality_threshold": float(threshold),
                "window_lo": float(cfg["window_lo"]),
                "window_hi": float(cfg["window_hi"]),
                "phase_offset": float(cfg["phase_offset"]),
                "both_valid_band_hosts": len(ids & both_band_ids),
                "version": VERSION,
            }
            raw_rows.append({
                **common,
                "analysis_family": "raw_zero_count_sensitivity_equivalent",
                "observed_count": int(cfg["observed_raw_positive_n"]),
                "recovered": int(subset["raw_hit"].sum()),
                "mean_efficiency": float(eps_raw.mean()),
                "hosts_with_nonzero_efficiency": int((eps_raw > 0).sum()),
                "f95_object_specific": raw_f95,
                "f95_capped_at_one": raw_capped,
                "bayes95_uniform": infer.bayesian_upper(eps_raw, 1.0, 1.0),
                "bayes95_beta_half": infer.bayesian_upper(eps_raw, 0.5, 0.5),
                "interpretation": "optimistic zero-count diagnostic; observed raw count is reported separately",
            })
            structural_rows.append({
                **common,
                "analysis_family": "matched_structural_end_to_end",
                "observed_count": int(cfg["observed_structural_n"]),
                "recovered": int(subset["structural_hit"].sum()),
                "mean_efficiency": float(eps_struct.mean()),
                "hosts_with_nonzero_efficiency": int((eps_struct > 0).sum()),
                "f95_object_specific": structural_f95,
                "f95_capped_at_one": structural_capped,
                "bayes95_uniform": infer.bayesian_upper(eps_struct, 1.0, 1.0),
                "bayes95_beta_half": infer.bayesian_upper(eps_struct, 0.5, 0.5),
                "interpretation": "formal matched-endpoint occurrence calculation",
            })
            for row in by_object.itertuples(index=False):
                object_rows.append({
                    "axis": axis, "setting": setting, "config_id": config_id,
                    "template_id": template, "object_id": row.object_id,
                    "trials": int(row.trials),
                    "structural_recovered": int(row.structural_recovered),
                    "structural_efficiency": float(row.structural_efficiency),
                    "raw_recovered": int(row.raw_recovered),
                    "raw_efficiency": float(row.raw_efficiency),
                    "version": VERSION,
                })
            attrition_rows.append({
                **common,
                "raw": int(subset["raw_hit"].sum()),
                "single_point_survives": int(joined[single_flag].sum()),
                "two_band_support": int(joined[two_flag].sum()),
                "lono_attempted": int(joined[lono_attempted_flag].sum()),
                "lono_survives": int(joined[lono_survives_flag].sum()),
                "structurally_confirmed": int(subset["structural_hit"].sum()),
            })
            if np.all(eps_struct == 0.0):
                draws = np.ones(20000, dtype=float)
            else:
                draws = infer.bootstrap_f95(eps_struct, rng, draws=20000)
            bootstrap_rows.append({
                **common,
                "bootstrap_draws": len(draws),
                "seed": 4807,
                "f95_p2p5": float(np.quantile(draws, 0.025)),
                "f95_median": float(np.quantile(draws, 0.5)),
                "f95_p97p5": float(np.quantile(draws, 0.975)),
                "fraction_capped_at_one": float(np.mean(draws >= 1.0 - 1e-12)),
            })

    raw = pd.DataFrame(raw_rows)
    structural = pd.DataFrame(structural_rows)
    objects_out = pd.DataFrame(object_rows)
    attrition = pd.DataFrame(attrition_rows)
    bootstrap = pd.DataFrame(bootstrap_rows)
    if len(raw) != 65 or len(structural) != 65 or len(attrition) != 65 or len(bootstrap) != 65:
        raise RuntimeError("Axis-indexed population cell count is not 65")
    unique_cols = ["template_id", "quality_threshold", "window_lo", "window_hi", "phase_offset", "analysis_family"]
    if len(structural.drop_duplicates(unique_cols)) != 55:
        raise RuntimeError("Unique structural-configuration count is not 55")
    if not structural["observed_count"].eq(0).all():
        raise RuntimeError("Matched structural observed count is nonzero")

    out = root / "results/v48m7_matched_endpoint/population"
    out.mkdir(parents=True, exist_ok=True)
    pd.concat([raw, structural], ignore_index=True).to_csv(out / "v48m7_full_population_sensitivity_130_axis_cells.csv", index=False)
    structural.to_csv(out / "v48m7_structural_population_sensitivity_65_axis_cells.csv", index=False)
    objects_out.to_csv(out / "v48m7_structural_object_specific_efficiencies.csv.gz", index=False, compression="gzip")
    attrition.to_csv(out / "v48m7_structural_criterion_attrition_65_axis_cells.csv", index=False)
    bootstrap.to_csv(out / "v48m7_structural_bootstrap_65_axis_cells.csv", index=False)

    primary = structural[(structural["axis"] == "quality_threshold") & (structural["setting"] == "chi2_dof_le_5")]
    primary_attrition = attrition[(attrition["axis"] == "quality_threshold") & (attrition["setting"] == "chi2_dof_le_5")]
    summary = {
        "status": "V48M7_FULL_MATCHED_STRUCTURAL_POPULATION_GRID_COMPLETE",
        "version": VERSION,
        "gate_pass": True,
        "axis_indexed_raw_cells": len(raw),
        "axis_indexed_structural_cells": len(structural),
        "unique_raw_configurations": len(raw.drop_duplicates(unique_cols)),
        "unique_structural_configurations": len(structural.drop_duplicates(unique_cols)),
        "duplicate_primary_rows_per_family": len(structural) - len(structural.drop_duplicates(unique_cols)),
        "all_observed_structural_counts_zero": bool(structural["observed_count"].eq(0).all()),
        "all_structural_recoveries_zero": bool(structural["recovered"].eq(0).all()),
        "all_structural_efficiencies_zero": bool(structural["mean_efficiency"].eq(0).all()),
        "all_structural_f95_equal_one": bool(structural["f95_object_specific"].eq(1.0).all()),
        "all_structural_bayes_uniform_equal_prior_quantile": bool(np.allclose(structural["bayes95_uniform"], 0.95)),
        "all_structural_bayes_beta_half_equal_prior_quantile": bool(np.allclose(structural["bayes95_beta_half"], 0.9938441702975689)),
        "primary_raw_crossings": dict(zip(primary_attrition["template_id"], primary_attrition["raw"].astype(int))),
        "primary_single_point_survivors": dict(zip(primary_attrition["template_id"], primary_attrition["single_point_survives"].astype(int))),
        "primary_two_band_survivors": dict(zip(primary_attrition["template_id"], primary_attrition["two_band_support"].astype(int))),
        "primary_lono_evaluations": dict(zip(primary_attrition["template_id"], primary_attrition["lono_attempted"].astype(int))),
        "primary_both_valid_band_hosts": int(primary["both_valid_band_hosts"].iloc[0]),
        "primary_total_hosts": int(primary["objects"].iloc[0]),
        "bootstrap_draws_per_structural_cell": 20000,
        "bootstrap_seed": 4807,
        "beta_half_prior_called_jeffreys": False,
        "raw_values_authorized_as_occurrence_limits": False,
        "physical_channel_occurrence_claim_authorized": False,
    }
    (out / "v48m7_population_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps(summary, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
