from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
from pathlib import Path

import numpy as np
import pandas as pd


VERSION = "v48e_point_baseline_forensics_1.0.0"
STATUS = "V48E_POINT_LEVEL_AND_BASELINE_INFLUENCE_FORENSICS_COMPLETE"
CANDIDATES = {
    "ZTF18abebzog": "positive", "ZTF19acoxgqw": "positive",
    "ZTF18ablqlzp": "negative", "ZTF18abnygkb": "negative", "ZTF19aawupxb": "negative",
}


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def classify(q: pd.DataFrame, residual_col: str) -> tuple[bool, bool, int, int, int, int]:
    if q.empty:
        return False, False, 0, 0, 0, 0
    x = q.copy(); x["night"] = np.floor(pd.to_numeric(x["mjd"], errors="coerce")).astype("Int64")
    z = x.groupby(["band", "night"])[residual_col].agg(["max", "min"])
    p5 = int((z["max"] > 5).sum()); p3 = int((z["max"] > 3).sum())
    n5 = int((z["min"] < -5).sum()); n3 = int((z["min"] < -3).sum())
    return bool(p5 >= 1 or p3 >= 2), bool(n5 >= 1 or n3 >= 2), p5, p3, n5, n3


def load_v48b(path: Path):
    spec = importlib.util.spec_from_file_location("v48b_for_v48e", path)
    if spec is None or spec.loader is None:
        raise RuntimeError("Cannot load frozen V48B implementation")
    module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    return module


def main() -> int:
    ap = argparse.ArgumentParser(); ap.add_argument("--root", default=".")
    root = Path(ap.parse_args().root).resolve()
    base = root / "results" / "v48_canonical" / "baseline"
    sens = root / "results" / "v48_canonical" / "sensitivity"
    out = root / "results" / "v48_canonical" / "forensics"
    paths = {
        "contract": root / "config" / "v48a_canonical_methods_contract.json",
        "implementation": root / "scripts" / "59_run_v48b_canonical_baseline_scatter.py",
        "lightcurves": root / "data" / "processed" / "earlyrise_lightcurves.csv",
        "fits": base / "v48b_object_band_fits.csv",
        "objects": base / "v48b_object_summary.csv",
        "points": base / "v48b_point_residuals.csv.gz",
        "v48d": sens / "v48d_prespecified_sensitivity_summary.json",
    }
    for path in paths.values():
        if not path.is_file(): raise FileNotFoundError(path)
    if json.loads(paths["v48d"].read_text(encoding="utf-8")).get("status") != "V48D_PRESPECIFIED_SENSITIVITY_COMPLETE":
        raise RuntimeError("V48D gate is not closed")
    cfg = json.loads(paths["contract"].read_text(encoding="utf-8"))
    v48b = load_v48b(paths["implementation"])
    fits = pd.read_csv(paths["fits"])
    objects = pd.read_csv(paths["objects"])
    points = pd.read_csv(paths["points"])
    lc_all = pd.read_csv(paths["lightcurves"], low_memory=False)
    for frame in (points, lc_all):
        for col in ("mjd", "flux", "fluxerr", "rest_phase", "redshift"):
            if col in frame: frame[col] = pd.to_numeric(frame[col], errors="coerce")
        frame["object_id"] = frame["object_id"].astype(str).str.strip()
        frame["band"] = frame["band"].astype(str).str.strip().str.lower()
    points["in_signal_bool"] = points["in_signal_window"].astype(str).str.lower().isin({"true", "1"})
    fit_valid = fits[fits["valid_fit"].astype(str).str.lower().isin({"true", "1"})].copy()
    lo, hi = cfg["eligibility"]["phase_window_days"]
    lc_fit = lc_all[
        lc_all["object_id"].isin(CANDIDATES) & lc_all["band"].isin({"c", "o"})
        & lc_all["mjd"].notna() & lc_all["flux"].notna() & lc_all["fluxerr"].gt(0)
        & lc_all["rest_phase"].between(lo, hi, inclusive="both")
    ].copy()

    source_cols = [c for c in ("object_id", "band", "mjd", "source_file", "source_relpath", "survey") if c in lc_all]
    source = lc_all[source_cols].drop_duplicates(["object_id", "band", "mjd"])
    forensic_points = points[points["object_id"].isin(CANDIDATES) & points["in_signal_bool"]].copy()
    forensic_points = forensic_points.merge(source, on=["object_id", "band", "mjd"], how="left")
    forensic_points["night"] = np.floor(forensic_points["mjd"]).astype("Int64")
    forensic_points["abs_residual_sigma"] = forensic_points["residual_sigma"].abs()
    forensic_points["point_gt3"] = forensic_points["residual_sigma"] > 3
    forensic_points["point_gt5"] = forensic_points["residual_sigma"] > 5
    forensic_points["point_lt_minus3"] = forensic_points["residual_sigma"] < -3
    forensic_points["point_lt_minus5"] = forensic_points["residual_sigma"] < -5
    forensic_points["version"] = VERSION

    deletion_rows = []
    trigger_nights: dict[str, list[int]] = {}
    for oid, kind in CANDIDATES.items():
        q = forensic_points[forensic_points["object_id"] == oid].copy()
        original = classify(q, "residual_sigma")
        index = q["residual_sigma"].idxmax() if kind == "positive" else q["residual_sigma"].idxmin()
        removed = q.loc[index]
        after = classify(q.drop(index=index), "residual_sigma")
        trigger_mask = (q["residual_sigma"] > 3) if kind == "positive" else (q["residual_sigma"] < -3)
        trigger_nights[oid] = sorted(q.loc[trigger_mask, "night"].dropna().astype(int).unique().tolist())
        deletion_rows.append({
            "object_id": oid, "crossing_label": kind,
            "removed_mjd": removed["mjd"], "removed_band": removed["band"], "removed_night": removed["night"],
            "removed_residual_sigma": removed["residual_sigma"], "removed_source_file": removed.get("source_file", ""),
            "original_positive": original[0], "original_negative": original[1],
            "after_deletion_positive": after[0], "after_deletion_negative": after[1],
            "crossing_survives_single_extreme_deletion": after[0] if kind == "positive" else after[1],
            "version": VERSION,
        })
    deletion = pd.DataFrame(deletion_rows)

    influence_rows = []
    for oid, kind in CANDIDATES.items():
        q0 = forensic_points[forensic_points["object_id"] == oid].copy()
        for night in trigger_nights[oid]:
            variants = {"reestimated_scatter": q0.copy(), "frozen_scatter": q0.copy()}
            refit_ok = True
            for band in sorted(q0["band"].unique()):
                train = lc_fit[(lc_fit["object_id"] == oid) & (lc_fit["band"] == band) & (np.floor(lc_fit["mjd"]) != night)]
                refit = v48b.fit_band(train, cfg["baseline"], cfg["empirical_scatter"])
                original_fit = fit_valid[(fit_valid["object_id"] == oid) & (fit_valid["band"] == band)]
                if not refit.get("valid_fit", False) or original_fit.empty:
                    refit_ok = False; continue
                mask = variants["reestimated_scatter"]["band"] == band
                eval_points = variants["reestimated_scatter"].loc[mask]
                pred = v48b.model(eval_points["mjd"].to_numpy(float), refit["amplitude"], refit["t0"], refit["alpha"])
                frozen_scatter = float(original_fit.iloc[0]["extra_scatter"])
                for name, scatter in (("reestimated_scatter", float(refit["extra_scatter"])), ("frozen_scatter", frozen_scatter)):
                    denom = np.sqrt(eval_points["fluxerr"].to_numpy(float) ** 2 + scatter ** 2)
                    variants[name].loc[mask, "refit_residual_sigma"] = (eval_points["flux"].to_numpy(float) - pred) / denom
            for name, q in variants.items():
                if "refit_residual_sigma" not in q: q["refit_residual_sigma"] = q["residual_sigma"]
                q["refit_residual_sigma"] = q["refit_residual_sigma"].fillna(q["residual_sigma"])
                result = classify(q, "refit_residual_sigma")
                influence_rows.append({
                    "object_id": oid, "crossing_label": kind, "dropped_trigger_night": night,
                    "scatter_policy": name, "all_refits_valid": refit_ok,
                    "positive_after_refit": result[0], "negative_after_refit": result[1],
                    "crossing_survives_refit": result[0] if kind == "positive" else result[1],
                    "max_refit_residual_sigma": q["refit_residual_sigma"].max(),
                    "min_refit_residual_sigma": q["refit_residual_sigma"].min(), "version": VERSION,
                })
    influence = pd.DataFrame(influence_rows)

    decisions = deletion[["object_id", "crossing_label", "crossing_survives_single_extreme_deletion"]].copy()
    lono = influence.groupby("object_id")["crossing_survives_refit"].all().rename("survives_all_leave_trigger_night_refits")
    decisions = decisions.merge(lono, on="object_id", how="left")
    decisions["astrophysical_detection"] = False
    decisions["decision"] = np.where(
        (decisions["crossing_label"] == "positive") & decisions["crossing_survives_single_extreme_deletion"] & decisions["survives_all_leave_trigger_night_refits"],
        "retain_forensic_positive_candidate_not_detection",
        np.where(decisions["crossing_label"] == "positive", "downgrade_fragile_positive_crossing",
                 "retain_as_sign_reversed_control_only"),
    )
    decisions["version"] = VERSION
    expected = {
        "ZTF18abebzog": "downgrade_fragile_positive_crossing",
        "ZTF19acoxgqw": "retain_forensic_positive_candidate_not_detection",
        "ZTF18ablqlzp": "retain_as_sign_reversed_control_only",
        "ZTF18abnygkb": "retain_as_sign_reversed_control_only",
        "ZTF19aawupxb": "retain_as_sign_reversed_control_only",
    }
    if dict(zip(decisions["object_id"], decisions["decision"])) != expected:
        raise RuntimeError("V48E adjudication differs from validated forensic result")

    out.mkdir(parents=True, exist_ok=True)
    forensic_points.to_csv(out / "v48e_candidate_signal_points_with_provenance.csv", index=False)
    deletion.to_csv(out / "v48e_single_extreme_point_deletion_5.csv", index=False)
    influence.to_csv(out / "v48e_leave_trigger_night_out_refits.csv", index=False)
    decisions.to_csv(out / "v48e_candidate_adjudication_5.csv", index=False)
    summary = {
        "status": STATUS, "version": VERSION, "input_sha256": {k: sha256(v) for k, v in paths.items()},
        "forensic_objects": 5, "positive_crossings_entering": 2, "negative_controls_entering": 3,
        "retained_forensic_positive_candidates": ["ZTF19acoxgqw"],
        "downgraded_fragile_positive_crossings": ["ZTF18abebzog"],
        "astrophysical_detections_confirmed": 0,
        "new_population_fit_executed": False, "injection_recovery_executed": False,
        "population_limits_computed": False, "archived_outputs_overwritten": False,
        "next_authorized_stage": "V48F_CANDIDATE_PHOTOMETRIC_VETTING_AND_NULL_CALIBRATION",
    }
    (out / "v48e_forensic_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    lines = [
        STATUS, "V48E_FORENSIC_GATE_PASS", "V48E_NO_ASTROPHYSICAL_DETECTION_CONFIRMED",
        "Forensic objects: 5", "Positive crossings entering: 2",
        "Retained forensic positive candidate (not detection): ZTF19acoxgqw",
        "Downgraded fragile positive crossing: ZTF18abebzog",
        "Sign-reversed controls retained: ZTF18ablqlzp|ZTF18abnygkb|ZTF19aawupxb",
        "Injection-recovery executed: False", "Population limits computed: False",
        "Archived 219/v44 outputs overwritten: False",
        "NEXT_AUTHORIZED_STAGE=V48F_CANDIDATE_PHOTOMETRIC_VETTING_AND_NULL_CALIBRATION",
    ]
    (out / "v48e_forensic_claim_box.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print("\n".join(lines)); return 0


if __name__ == "__main__": raise SystemExit(main())
