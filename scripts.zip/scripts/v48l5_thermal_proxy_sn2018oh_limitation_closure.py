from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd

VERSION = "v48l5_thermal_proxy_sn2018oh_limitation_closure_1.0.0"
OUT_REL = Path("results/v48_canonical/revision/v48l5_thermal_sn2018oh")


def require(ok: bool, message: str) -> None:
    if not ok:
        raise RuntimeError(message)


def bool_series(s: pd.Series) -> pd.Series:
    return s.astype(str).str.strip().str.lower().isin({"true", "1", "yes"})


def fit_inventory(path: Path, subset: str) -> dict:
    if not path.is_file() or path.stat().st_size == 0:
        return {"subset": subset, "path": str(path), "file_present": path.is_file(), "rows": 0,
                "successful_bands": 0, "positive_trigger_bands": 0, "negative_trigger_bands": 0,
                "evaluable": False}
    try:
        d = pd.read_csv(path)
    except pd.errors.EmptyDataError:
        d = pd.DataFrame()
    success = bool_series(d["success"]) if "success" in d else pd.Series(False, index=d.index)
    positive = bool_series(d["positive_flag"]) if "positive_flag" in d else pd.Series(False, index=d.index)
    negative = bool_series(d["negative_flag"]) if "negative_flag" in d else pd.Series(False, index=d.index)
    return {"subset": subset, "path": str(path), "file_present": True, "rows": len(d),
            "successful_bands": int(success.sum()), "positive_trigger_bands": int((success & positive).sum()),
            "negative_trigger_bands": int((success & negative).sum()), "evaluable": bool(success.any())}


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--project-root", default=".")
    args = ap.parse_args()
    root = Path(args.project_root).resolve()
    out = root / OUT_REL
    out.mkdir(parents=True, exist_ok=True)

    templates_path = root / "results/v48_canonical/injection/freeze/v48g1_proxy_templates_5.csv"
    primary_path = root / "results/v48_canonical/injection/population_limits/v48g2c_primary_population_limits.csv"
    v44_cfg_path = root / "config/v44_sn2018oh_transport_config.json"
    v44_src_path = root / "scripts/54_run_v44_sn2018oh_atlas_native_transport.py"
    for p in (templates_path, primary_path, v44_cfg_path, v44_src_path):
        require(p.is_file(), f"Missing required evidence: {p}")

    templates = pd.read_csv(templates_path)
    limits = pd.read_csv(primary_path)
    require(len(templates) == 5, "Expected five V48 proxy templates")
    t = templates[templates["template_id"] == "SN2018oh_scale_broad_proxy"]
    require(len(t) == 1, "SN2018oh-scale proxy missing or duplicated")
    t = t.iloc[0]
    require(str(t.model_family) == "broad_optical_excess_proxy", "SN2018oh proxy family changed")
    require(float(t.peak_sigma) == 4.0 and float(t.width_days) == 3.5 and float(t.phase_peak_days) == 3.0, "SN2018oh proxy shape changed")
    require(float(t.c_scale) == 1.05 and float(t.o_scale) == 1.0, "SN2018oh proxy band scaling changed")
    lp = limits[limits["template_id"] == "SN2018oh_scale_broad_proxy"]
    require(len(lp) == 1, "SN2018oh primary limit cell missing")
    lp = lp.iloc[0]

    cfg = json.loads(v44_cfg_path.read_text(encoding="utf-8"))
    src = v44_src_path.read_text(encoding="utf-8", errors="replace")
    require(float(cfg["template_temperature_K"]) == 17500.0, "V44 temperature changed")
    require(cfg["atlas_c_support_angstrom"] == [4200.0, 6500.0], "V44 c support changed")
    require(cfg["atlas_o_support_angstrom"] == [5600.0, 8200.0], "V44 o support changed")
    require('supports = {"c": (4200.0, 6500.0), "o": (5600.0, 8200.0)}' in src, "Literal top-hat supports not found in V44 source")
    require("219-object EERI denominator" in src and "minimum_primary_overlap" in src, "Historical 219-denominator linkage not found")

    table_dir = root / "results/tables"
    inv = []
    for subset in ("ALL", "K2", "ATLAS"):
        inv.append(fit_inventory(table_dir / f"v40_benchmark_event_fit_summary_{subset}.csv", subset))
    inventory = pd.DataFrame(inv)
    inventory.to_csv(out / "v48l5_v40_benchmark_subset_inventory.csv", index=False)
    all_row = inventory[inventory.subset == "ALL"].iloc[0]
    atlas_row = inventory[inventory.subset == "ATLAS"].iloc[0]
    require(bool(all_row.evaluable), "Combined V40 benchmark fit is not evaluable")
    require(int(all_row.positive_trigger_bands) >= 1 and int(all_row.negative_trigger_bands) >= 1,
            "Combined V40 fit does not reproduce both positive and negative trigger bands")
    require(not bool(atlas_row.evaluable), "ATLAS-only V40 subset unexpectedly has a successful evaluable fit")

    evidence = {
        "version": VERSION,
        "canonical_v48_proxy": {
            "template_id": str(t.template_id), "model_family": str(t.model_family),
            "peak_sigma": float(t.peak_sigma), "width_days": float(t.width_days),
            "phase_peak_days": float(t.phase_peak_days), "c_scale": float(t.c_scale), "o_scale": float(t.o_scale),
            "physical_thermal_model": False,
            "measured_atlas_throughput_used": False,
            "interpretation": "illustrative colour-timescale proxy only",
        },
        "canonical_v48_primary_result": {
            "trials": int(lp.injection_trials), "recovered": int(lp.recovered),
            "efficiency": float(lp.efficiency), "frequentist_exact_f95": float(lp.frequentist_exact_f95),
            "bayesian_beta11_f95": float(lp.bayesian_beta11_f95), "bayesian_beta05_f95": float(lp.bayesian_beta05_f95),
        },
        "archived_v44_transport": {
            "canonical_v48_result": False, "historical_denominator": 219,
            "temperature_K": float(cfg["template_temperature_K"]),
            "atlas_c_top_hat_support_angstrom": cfg["atlas_c_support_angstrom"],
            "atlas_o_top_hat_support_angstrom": cfg["atlas_o_support_angstrom"],
            "measured_throughput_curves_used": False,
            "allowed_role": "illustrative morphology/colour transport diagnostic only",
        },
        "v40_benchmark": {
            "combined_positive_trigger_bands": int(all_row.positive_trigger_bands),
            "combined_negative_trigger_bands": int(all_row.negative_trigger_bands),
            "atlas_only_evaluable": bool(atlas_row.evaluable),
            "independent_validation_of_atlas_search": False,
        },
        "fits_transport_or_injections_rerun": False,
        "canonical_outputs_modified": False,
        "claims_frozen": True,
        "next_authorized_stage": "V48L6_LIU_2026_AND_LITERATURE_CONTEXT_CLOSURE",
    }
    (out / "v48l5_closure_summary.json").write_text(json.dumps(evidence, indent=2), encoding="utf-8")

    manuscript = """**Thermal and SN 2018oh proxy limitations.** **The canonical `SN2018oh_scale_broad_proxy` is a phenomenological broad optical excess, not a forward thermal model of SN 2018oh. It is defined by a 4-sigma nominal peak, a 3.5-d width, a peak at 3 d, and fixed relative c/o scales of 1.05/1.00. Neither a spectral-energy-distribution fit nor measured ATLAS throughput curves enter this canonical proxy. Its recovery efficiency and limits must therefore be interpreted only as illustrative colour-timescale sensitivity under the stated injection model.**

**For completeness, the earlier K2-to-ATLAS transport used a 17,500-K blackbody colour weighting integrated over top-hat approximations of 4200-6500 Angstrom for c and 5600-8200 Angstrom for o, rather than measured throughput curves. That archived calculation was tied to the superseded 219-object denominator and is not a canonical V48 population result. We retain it only as an illustrative morphology-transport diagnostic and do not use it to infer a physical-channel rate.**

**The SN 2018oh event-level benchmark also does not provide independent validation of the ATLAS search. The combined benchmark fit contains both positive and negative trigger bands, while the ATLAS-only subset has no successful evaluable band fit. This mixed-sign, multi-instrument behaviour may demonstrate how the residual rule responds to a published early-excess event in the available benchmark product, but it neither establishes ATLAS-only recovery nor validates the canonical survey selection independently.**
"""
    (out / "v48l5_manuscript_insertion_bold.txt").write_text(manuscript, encoding="utf-8")
    response = """**Response — thermal proxy and SN 2018oh benchmark.** **We have narrowed both claims as requested. The canonical SN2018oh-scale injection is now described explicitly as a phenomenological colour-timescale proxy, with its fixed temporal and c/o scaling parameters stated; it is not presented as a thermal or physical-channel model. We also disclose that the archived 17,500-K K2-to-ATLAS transport used top-hat c and o supports rather than measured throughput curves and belonged to the superseded 219-object analysis. Finally, we report that the combined SN 2018oh benchmark produces both positive and negative trigger bands and that the ATLAS-only subset is not evaluable. We therefore no longer describe this benchmark as independent validation of the ATLAS search.**
"""
    (out / "v48l5_response_letter_text_bold.txt").write_text(response, encoding="utf-8")
    (out / "v48l5_allowed_claims.txt").write_text(
        "ALLOWED CLAIMS\n- The V48 SN2018oh-scale template is a phenomenological broad optical proxy.\n- Its exact peak, width, phase, and c/o scales may be stated.\n- V44 used a 17,500-K blackbody with top-hat c/o supports and is illustrative only.\n- The combined V40 benchmark has both positive and negative trigger bands.\n- The ATLAS-only V40 subset is not evaluable.\n", encoding="utf-8")
    (out / "v48l5_prohibited_claims.txt").write_text(
        "PROHIBITED CLAIMS\n- Do not call the V48 SN2018oh proxy a fitted thermal model.\n- Do not claim measured ATLAS throughput curves were used in V44.\n- Do not promote archived V44/219 limits as canonical V48/277 limits.\n- Do not call the SN2018oh benchmark independent validation of the ATLAS search.\n- Do not interpret proxy recovery as a companion-interaction or other physical-channel rate.\n", encoding="utf-8")

    report = [
        "V48L5_THERMAL_PROXY_AND_SN2018OH_LIMITATION_CLOSURE_PASS",
        f"Canonical SN2018oh proxy peak/width/phase: {float(t.peak_sigma):.1f}/{float(t.width_days):.1f}/{float(t.phase_peak_days):.1f}",
        f"Canonical SN2018oh proxy c/o scales: {float(t.c_scale):.2f}/{float(t.o_scale):.2f}",
        "Canonical proxy is a fitted thermal model: False",
        "Measured ATLAS throughput curves used: False",
        f"Archived V44 temperature / denominator: {float(cfg['template_temperature_K']):.0f}/219",
        f"Combined V40 positive/negative trigger bands: {int(all_row.positive_trigger_bands)}/{int(all_row.negative_trigger_bands)}",
        f"ATLAS-only V40 evaluable: {bool(atlas_row.evaluable)}",
        "Independent validation of ATLAS search: False",
        "Fits, transport, or injections rerun: False",
        "Canonical outputs modified: False",
        "Claims frozen: True",
        "NEXT_AUTHORIZED_STAGE=V48L6_LIU_2026_AND_LITERATURE_CONTEXT_CLOSURE",
    ]
    (out / "v48l5_report.txt").write_text("\n".join(report) + "\n", encoding="utf-8")
    print("\n".join(report))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
