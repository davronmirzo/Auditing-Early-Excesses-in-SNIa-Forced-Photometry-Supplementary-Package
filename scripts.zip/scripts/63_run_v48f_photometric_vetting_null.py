from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd


VERSION = "v48f_photometric_vetting_null_1.0.0"
STATUS = "V48F_PHOTOMETRIC_VETTING_AND_NULL_CALIBRATION_COMPLETE"
TARGET = "ZTF19acoxgqw"
RAW_FILE = "job4493111.txt"
CHI_N_DIAGNOSTIC_CUTOFF = 3.0
RAW_COLUMNS = ["mjd", "mag", "dmag", "flux_uJy", "fluxerr_uJy", "band", "err", "chi_n",
               "ra", "dec", "x", "y", "maj", "min", "phi", "apfit", "mag5sig", "sky", "obs"]


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def classify(q: pd.DataFrame, residual_col: str = "residual_sigma") -> tuple[bool, bool]:
    if q.empty: return False, False
    x = q.copy(); x["night"] = np.floor(x["mjd"]).astype(int)
    z = x.groupby(["band", "night"])[residual_col].agg(["max", "min"])
    return bool((z["max"] > 5).any() or (z["max"] > 3).sum() >= 2), \
           bool((z["min"] < -5).any() or (z["min"] < -3).sum() >= 2)


def main() -> int:
    ap = argparse.ArgumentParser(); ap.add_argument("--root", default=".")
    root = Path(ap.parse_args().root).resolve()
    base = root / "results" / "v48_canonical" / "baseline"
    forensic = root / "results" / "v48_canonical" / "forensics"
    out = root / "results" / "v48_canonical" / "null_calibration"
    paths = {
        "objects": base / "v48b_object_summary.csv",
        "points": base / "v48b_point_residuals.csv.gz",
        "v48e_summary": forensic / "v48e_forensic_summary.json",
        "v48e_decisions": forensic / "v48e_candidate_adjudication_5.csv",
    }
    for path in paths.values():
        if not path.is_file(): raise FileNotFoundError(path)
    if json.loads(paths["v48e_summary"].read_text(encoding="utf-8")).get("status") != "V48E_POINT_LEVEL_AND_BASELINE_INFLUENCE_FORENSICS_COMPLETE":
        raise RuntimeError("V48E gate is not closed")
    raw_hits = sorted((root / "data" / "raw" / "atlas").rglob(RAW_FILE))
    if not raw_hits: raise FileNotFoundError(f"Raw ATLAS source not found: {RAW_FILE}")
    raw_path = raw_hits[0]
    raw = pd.read_csv(raw_path, sep=r"\s+", comment="#", names=RAW_COLUMNS, engine="python")
    for col in ("mjd", "flux_uJy", "fluxerr_uJy", "chi_n"):
        raw[col] = pd.to_numeric(raw[col], errors="coerce")
    raw = raw.dropna(subset=["mjd"])

    objects = pd.read_csv(paths["objects"])
    points = pd.read_csv(paths["points"])
    primary_ids = set(objects.loc[objects["primary_chi2_le_5"].astype(str).str.lower().isin({"true", "1"}), "object_id"].astype(str))
    q = points[points["object_id"].astype(str).isin(primary_ids) & points["in_signal_window"].astype(str).str.lower().isin({"true", "1"})].copy()
    q["mjd"] = pd.to_numeric(q["mjd"], errors="coerce")
    q["residual_sigma"] = pd.to_numeric(q["residual_sigma"], errors="coerce")
    if len(primary_ids) != 277: raise RuntimeError("Primary denominator is not 277 objects")

    target = q[q["object_id"] == TARGET].copy().sort_values("mjd")
    target["raw_match_delta_days"] = np.nan; target["raw_chi_n"] = np.nan
    target["raw_err"] = np.nan; target["raw_obs"] = ""
    for idx, row in target.iterrows():
        delta = (raw["mjd"] - float(row["mjd"])).abs()
        j = delta.idxmin()
        if float(delta.loc[j]) <= 1e-6:
            target.loc[idx, "raw_match_delta_days"] = float(delta.loc[j])
            target.loc[idx, "raw_chi_n"] = float(raw.loc[j, "chi_n"])
            target.loc[idx, "raw_err"] = float(raw.loc[j, "err"])
            target.loc[idx, "raw_obs"] = str(raw.loc[j, "obs"])
    if int(target["raw_chi_n"].notna().sum()) != len(target):
        raise RuntimeError("Not every target signal-window point matched the raw ATLAS file")
    target["supports_positive_rule"] = target["residual_sigma"] > 3
    target["poor_psf_fit_chi_n_gt_3"] = target["raw_chi_n"] > CHI_N_DIAGNOSTIC_CUTOFF
    target["passes_chi_n_diagnostic"] = target["raw_chi_n"] <= CHI_N_DIAGNOSTIC_CUTOFF
    target["version"] = VERSION
    support = target[target["supports_positive_rule"]]
    support_values = sorted(np.round(support["raw_chi_n"].to_numpy(float), 2).tolist())
    if support_values != [4.91, 5.39, 6.72]:
        raise RuntimeError(f"Unexpected raw chi/N support values: {support_values}")
    original_positive, _ = classify(target)
    quality_positive, _ = classify(target[target["passes_chi_n_diagnostic"]])
    if not original_positive or quality_positive:
        raise RuntimeError("Raw-quality reclassification did not produce the validated downgrade")

    pairs = []
    object_rows = []
    for oid in sorted(primary_ids):
        g = q[q["object_id"] == oid].copy()
        pos, neg = classify(g)
        rev = g.copy(); rev["reversed_residual"] = -rev["residual_sigma"]
        rev_pos, _ = classify(rev, "reversed_residual")
        pairs.append((int(pos), int(rev_pos)))
        object_rows.append({"object_id": oid, "observed_positive": pos,
                            "positive_after_full_sign_reverse": rev_pos, "version": VERSION})
    observed_n = int(sum(a for a, _ in pairs))
    reversed_n = int(sum(b for _, b in pairs))
    dp = np.array([1.0])
    for a, bval in pairs:
        mass = np.zeros(max(a, bval) + 1); mass[a] += 0.5; mass[bval] += 0.5
        dp = np.convolve(dp, mass)
    p_ge_observed = float(dp[observed_n:].sum())
    if observed_n != 2 or reversed_n != 3 or abs(p_ge_observed - 0.8125) > 1e-12:
        raise RuntimeError("Exact object-level sign-flip result differs from 2/3 and p=0.8125")
    p_equal_observed = float(dp[observed_n])
    p_two_sided = float(dp[dp <= dp[observed_n] + 1e-15].sum())
    if abs(p_equal_observed - 0.3125) > 1e-12 or abs(p_two_sided - 1.0) > 1e-12:
        raise RuntimeError("Exact point probability or two-sided binomial result changed")
    null_dist = pd.DataFrame({"positive_count": np.arange(len(dp)), "exact_probability": dp})
    null_dist = null_dist[null_dist["exact_probability"] > 0].copy(); null_dist["version"] = VERSION

    out.mkdir(parents=True, exist_ok=True)
    target.to_csv(out / "v48f_ztf19acoxgqw_raw_quality_audit.csv", index=False)
    pd.DataFrame(object_rows).to_csv(out / "v48f_object_level_sign_flip_pairs_277.csv", index=False)
    null_dist.to_csv(out / "v48f_exact_sign_flip_positive_count_distribution.csv", index=False)
    decision = pd.DataFrame([{
        "object_id": TARGET, "status_entering": "retained_forensic_positive_candidate_not_detection",
        "positive_support_points": len(support), "support_points_chi_n_gt_3": int(support["poor_psf_fit_chi_n_gt_3"].sum()),
        "positive_after_chi_n_le_3_diagnostic": quality_positive,
        "final_decision": "downgrade_poor_psf_fit_artifact", "astrophysical_detection": False, "version": VERSION,
    }])
    decision.to_csv(out / "v48f_candidate_final_adjudication.csv", index=False)
    summary = {
        "status": STATUS, "version": VERSION, "input_sha256": {k: sha256(v) for k, v in paths.items()},
        "raw_source": str(raw_path.relative_to(root)).replace("\\", "/"), "raw_source_sha256": sha256(raw_path),
        "primary_objects": 277, "observed_positive_crossings": observed_n,
        "sign_reversed_positive_crossings": reversed_n,
        "exact_sign_flip_p_npositive_ge_2": p_ge_observed,
        "exact_sign_flip_p_npositive_eq_2": p_equal_observed,
        "exact_sign_flip_two_sided_p": p_two_sided,
        "target": TARGET, "positive_support_chi_n": support_values,
        "target_positive_after_chi_n_le_3_diagnostic": quality_positive,
        "target_final_decision": "downgrade_poor_psf_fit_artifact",
        "confirmed_astrophysical_positives": 0,
        "injection_recovery_executed": False, "population_limits_computed": False,
        "archived_outputs_overwritten": False,
        "next_authorized_stage": "V48G_CANONICAL_INJECTION_RECOVERY_AND_POPULATION_LIMITS",
    }
    (out / "v48f_photometric_null_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    lines = [
        STATUS, "V48F_RAW_PHOTOMETRIC_QUALITY_GATE_PASS", "V48F_GLOBAL_NULL_CALIBRATION_COMPLETE",
        "V48F_NO_ASTROPHYSICAL_POSITIVE_CONFIRMED",
        "Primary objects: 277", "Observed/sign-reversed positive crossings: 2/3",
        "Exact sign-flip P(Npositive=2): 0.312500",
        "Exact two-sided binomial p: 1.000000",
        "ZTF19acoxgqw positive-support chi/N: 5.39|6.72|4.91",
        "ZTF19acoxgqw after chi/N<=3 diagnostic: no positive flag",
        "ZTF19acoxgqw final decision: downgrade_poor_psf_fit_artifact",
        "Confirmed astrophysical positives: 0", "Injection-recovery executed: False",
        "Population limits computed: False", "Archived 219/v44 outputs overwritten: False",
        "NEXT_AUTHORIZED_STAGE=V48G_CANONICAL_INJECTION_RECOVERY_AND_POPULATION_LIMITS",
    ]
    (out / "v48f_photometric_null_claim_box.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print("\n".join(lines)); return 0


if __name__ == "__main__": raise SystemExit(main())
