from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import os
import time
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd


VERSION = "v48g2b_canonical_injection_recovery_1.0.0"
STATUS = "V48G2B_193200_TRIAL_PRODUCTION_COMPLETE"
EXPECTED_TOTAL = 193200
EXPECTED_FROZEN = 163200
EXPECTED_REESTIMATED = 30000

G: dict[str, Any] = {}


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def truthy(series: pd.Series) -> pd.Series:
    return series.astype(str).str.strip().str.lower().isin({"true", "1", "yes", "y", "t"})


def load_engine(root: Path):
    path = root / "scripts/65_validate_v48g2_full_refit_engine.py"
    spec = importlib.util.spec_from_file_location("v48g2a_engine", path)
    if spec is None or spec.loader is None: raise RuntimeError(f"Cannot load {path}")
    module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    return module


def worker_init(root_text: str) -> None:
    root = Path(root_text)
    methods = json.loads((root / "config/v48a_canonical_methods_contract.json").read_text(encoding="utf-8"))
    contract = json.loads((root / "config/v48g1_injection_contract.json").read_text(encoding="utf-8"))
    fits = pd.read_csv(root / "results/v48_canonical/baseline/v48b_object_band_fits.csv")
    fits = fits[truthy(fits["valid_fit"])].copy()
    d = pd.read_csv(root / "data/processed/earlyrise_lightcurves.csv", low_memory=False)
    for col in ("mjd", "flux", "fluxerr", "redshift", "rest_phase"): d[col] = pd.to_numeric(d[col], errors="coerce")
    d["object_id"] = d["object_id"].astype(str); d["band"] = d["band"].astype(str).str.lower()
    lo, hi = methods["eligibility"]["phase_window_days"]
    d = d[d["band"].isin({"c", "o"}) & d["mjd"].notna() & d["flux"].notna() & d["fluxerr"].gt(0) & d["rest_phase"].between(lo, hi, inclusive="both")].copy()
    G.update(root=root, methods=methods, contract=contract, fits=fits, data=d, engine=load_engine(root))


def run_host(task: tuple[str, bool, str, str]) -> tuple[str, list[dict[str, Any]]]:
    oid, do_reestimated, contract_hash, engine_hash = task
    methods, contract, engine = G["methods"], G["contract"], G["engine"]
    d = G["data"]; fits = G["fits"]
    od = d[d["object_id"] == oid].copy(); ofits = fits[fits["object_id"] == oid].copy()
    z = float(od["redshift"].median()); z = z if np.isfinite(z) else 0.0
    shared_anchor = float(ofits["t0"].median())
    scatter_policies = ["frozen-pre-injection"] + (["reestimated-post-injection"] if do_reestimated else [])
    rows: list[dict[str, Any]] = []
    for template in contract["templates"]:
        for alpha_mode in contract["mode_grid"]["alpha_refit_modes"]:
            for calendar_mode in contract["mode_grid"]["calendar_modes"]:
                for realization in range(int(contract["realizations_per_host_template_mode"])):
                    seed_text = f"{contract['random_seed']}|{oid}|{template['template_id']}|{alpha_mode}|{calendar_mode}|{realization}"
                    trial_seed = int(hashlib.sha256(seed_text.encode()).hexdigest()[:16], 16)
                    rng = np.random.default_rng(trial_seed)
                    phase_jitter = float(rng.normal(0.0, contract["phase_jitter_days"]))
                    amplitude_jitter = float(max(0.0, rng.normal(1.0, contract["amplitude_jitter_fraction"])))
                    for scatter_policy in scatter_policies:
                        point_parts: list[pd.DataFrame] = []; band_success = True; fixed_ok = True
                        scatter_converged = True; n_band_refits = 0
                        for prefit in ofits.itertuples(index=False):
                            g = od[od["band"] == prefit.band].sort_values("mjd").copy()
                            anchor = shared_anchor if calendar_mode == "shared-physical-date" else float(prefit.t0)
                            peak_mjd = anchor + (float(template["phase_peak_days"]) + phase_jitter) * (1.0 + z)
                            width_obs = float(template["width_days"]) * (1.0 + z)
                            band_scale = float(template["c_scale"] if prefit.band == "c" else template["o_scale"])
                            eff_pre = np.sqrt(g["fluxerr"].to_numpy(float) ** 2 + float(prefit.extra_scatter) ** 2)
                            bump = float(template["peak_sigma"]) * band_scale * amplitude_jitter * float(np.median(eff_pre)) * np.exp(-0.5 * ((g["mjd"].to_numpy(float) - peak_mjd) / width_obs) ** 2)
                            result = engine.refit_band(g, g["flux"].to_numpy(float) + bump, methods["baseline"], alpha_mode, pd.Series(prefit._asdict()), scatter_policy)
                            if not result["success"]:
                                band_success = False; continue
                            n_band_refits += 1
                            fixed_ok = fixed_ok and (alpha_mode != "fixed-to-pre-injection" or abs(float(result["alpha"]) - float(prefit.alpha)) < 1e-12)
                            scatter_converged = scatter_converged and bool(result["scatter_converged"])
                            phase = (g["mjd"].to_numpy(float) - float(result["t0"])) / (1.0 + z)
                            q = pd.DataFrame({"band": prefit.band, "night": np.floor(g["mjd"]).astype(int), "residual_sigma": result["residual_sigma"]})
                            point_parts.append(q[(phase >= contract["signal_window_days"][0]) & (phase <= contract["signal_window_days"][1])])
                        blocks = pd.concat(point_parts, ignore_index=True) if point_parts else pd.DataFrame()
                        maxima = blocks.groupby(["band", "night"])["residual_sigma"].max().to_numpy(float) if len(blocks) else np.array([])
                        rows.append({"object_id": oid, "template_id": template["template_id"], "alpha_refit_mode": alpha_mode,
                                     "calendar_mode": calendar_mode, "realization": realization, "trial_seed": trial_seed,
                                     "scatter_policy": scatter_policy, "phase_jitter_days": phase_jitter,
                                     "amplitude_jitter_factor": amplitude_jitter, "valid_band_refits": n_band_refits,
                                     "all_band_refits_success": band_success, "fixed_alpha_invariant": fixed_ok,
                                     "scatter_converged_all_bands": scatter_converged, "n_signal_blocks": int(len(maxima)),
                                     "max_positive_block_residual": float(np.max(maxima)) if len(maxima) else np.nan,
                                     "n_blocks_gt3": int(np.sum(maxima > 3.0)), "recovered": engine.recovered(blocks),
                                     "contract_sha256": contract_hash, "engine_sha256": engine_hash, "version": VERSION})
    return oid, rows


def valid_checkpoint(path: Path, expected_rows: int, contract_hash: str, engine_hash: str) -> bool:
    try:
        d = pd.read_csv(path)
        return len(d) == expected_rows and d["contract_sha256"].eq(contract_hash).all() and d["engine_sha256"].eq(engine_hash).all() and not d.duplicated(["object_id", "template_id", "alpha_refit_mode", "calendar_mode", "realization", "scatter_policy"]).any()
    except Exception:  # noqa: BLE001
        return False


def atomic_csv(rows: list[dict[str, Any]], path: Path) -> None:
    temp = path.with_suffix(path.suffix + ".tmp")
    pd.DataFrame(rows).to_csv(temp, index=False); os.replace(temp, path)


def main() -> int:
    ap = argparse.ArgumentParser(); ap.add_argument("--root", default="."); ap.add_argument("--workers", type=int, default=4)
    ap.add_argument("--max-hosts", type=int, default=0, help="Smoke/testing only; 0 means the full frozen host set")
    args = ap.parse_args(); root = Path(args.root).resolve(); workers = max(1, int(args.workers))
    required = {
        "contract": root / "config/v48g1_injection_contract.json", "freeze": root / "results/v48_canonical/injection/freeze/v48g1_injection_contract_freeze.json",
        "hosts": root / "results/v48_canonical/injection/freeze/v48g1_injection_hosts_272.csv", "subset": root / "results/v48_canonical/injection/freeze/v48g1_reestimated_scatter_hosts_50.csv",
        "g2a": root / "results/v48_canonical/injection/engine_validation/v48g2a_engine_validation_summary.json", "engine": root / "scripts/65_validate_v48g2_full_refit_engine.py",
    }
    for path in required.values():
        if not path.is_file(): raise FileNotFoundError(path)
    freeze = json.loads(required["freeze"].read_text(encoding="utf-8")); g2a = json.loads(required["g2a"].read_text(encoding="utf-8"))
    contract_hash = sha256(required["contract"]); engine_hash = sha256(required["engine"])
    if freeze.get("status") != "V48G1_CANONICAL_INJECTION_CONTRACT_FROZEN" or freeze.get("contract_sha256") != contract_hash:
        raise RuntimeError("V48G1 freeze/hash gate failed")
    if g2a.get("status") != "V48G2A_FULL_REFIT_ENGINE_VALIDATION_COMPLETE" or not g2a.get("gate_pass") or g2a.get("version") != "v48g2a_full_refit_engine_validation_1.0.2":
        raise RuntimeError("Corrected V48G2A v1.0.2 gate is not closed")
    hosts = pd.read_csv(required["hosts"])["object_id"].astype(str).tolist(); subset = set(pd.read_csv(required["subset"])["object_id"].astype(str))
    if len(hosts) != 272 or len(subset) != 50: raise RuntimeError("Frozen host/subset counts changed")
    production = args.max_hosts == 0
    if not production: hosts = hosts[:args.max_hosts]
    out = root / "results/v48_canonical/injection/production"; checkpoint = out / "checkpoints"; checkpoint.mkdir(parents=True, exist_ok=True)
    tasks = []
    for oid in hosts:
        expected = 1200 if oid in subset else 600; path = checkpoint / f"{oid}.csv"
        if not valid_checkpoint(path, expected, contract_hash, engine_hash): tasks.append((oid, oid in subset, contract_hash, engine_hash))
    started = time.time(); completed_before = len(hosts) - len(tasks)
    print(f"V48G2B resume: {completed_before}/{len(hosts)} host checkpoints already complete", flush=True)
    try:
        with ProcessPoolExecutor(max_workers=workers, initializer=worker_init, initargs=(str(root),)) as pool:
            futures = {pool.submit(run_host, task): task[0] for task in tasks}
            completed = completed_before
            for future in as_completed(futures):
                oid, rows = future.result(); expected = 1200 if oid in subset else 600
                if len(rows) != expected: raise RuntimeError(f"{oid}: expected {expected} rows, got {len(rows)}")
                atomic_csv(rows, checkpoint / f"{oid}.csv"); completed += 1
                print(f"V48G2B progress: {completed}/{len(hosts)} host checkpoints complete", flush=True)
    except KeyboardInterrupt:
        print("V48G2B_INTERRUPTED_CHECKPOINTS_PRESERVED", flush=True); return 130
    pieces = [pd.read_csv(checkpoint / f"{oid}.csv") for oid in hosts]
    trials = pd.concat(pieces, ignore_index=True)
    frozen_n = int((trials["scatter_policy"] == "frozen-pre-injection").sum()); reestimated_n = int((trials["scatter_policy"] == "reestimated-post-injection").sum())
    unique = not trials.duplicated(["object_id", "template_id", "alpha_refit_mode", "calendar_mode", "realization", "scatter_policy"]).any()
    all_success = bool(truthy(trials["all_band_refits_success"]).all()); fixed_ok = bool(truthy(trials["fixed_alpha_invariant"]).all())
    gate = bool(production and len(trials) == EXPECTED_TOTAL and frozen_n == EXPECTED_FROZEN and reestimated_n == EXPECTED_REESTIMATED and unique and all_success and fixed_ok)
    trials.to_csv(out / "v48g2b_injection_recovery_trials_193200.csv.gz", index=False, compression="gzip")
    grouped = trials.groupby(["template_id", "alpha_refit_mode", "calendar_mode", "scatter_policy"], as_index=False).agg(trials=("recovered", "size"), recovered=("recovered", lambda x: int(truthy(x).sum())), refit_failures=("all_band_refits_success", lambda x: int((~truthy(x)).sum())))
    grouped["efficiency"] = grouped["recovered"] / grouped["trials"]; grouped.to_csv(out / "v48g2b_recovery_efficiency_by_mode.csv", index=False)
    summary = {"status": STATUS if gate else "V48G2B_PRODUCTION_GATE_NOT_CLOSED", "version": VERSION, "gate_pass": gate,
               "hosts": len(hosts), "total_trials": len(trials), "frozen_scatter_trials": frozen_n, "reestimated_scatter_trials": reestimated_n,
               "all_refits_success": all_success, "fixed_alpha_invariant": fixed_ok, "trial_keys_unique": unique,
               "workers": workers, "elapsed_seconds_this_invocation": time.time() - started, "contract_sha256": contract_hash, "engine_sha256": engine_hash,
               "injection_recovery_executed": production, "population_limits_computed": False, "archived_outputs_overwritten": False,
               "next_authorized_stage": "V48G2C_POPULATION_LIMIT_CLOSURE" if gate else "V48G2B_RESUME_OR_REPAIR"}
    (out / "v48g2b_production_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    lines = [summary["status"], "V48G2B_PRODUCTION_GATE_PASS" if gate else "V48G2B_PRODUCTION_GATE_NOT_CLOSED",
             f"Hosts/trials: {len(hosts)}/{len(trials)}", f"Frozen/re-estimated scatter trials: {frozen_n}/{reestimated_n}",
             f"All object-band refits succeeded: {all_success}", f"Fixed-alpha invariant: {fixed_ok}", f"Unique trial keys: {unique}",
             f"Workers: {workers}", "Injection-recovery executed: " + str(production), "Population limits computed: False",
             "Archived 219/v44 outputs overwritten: False", f"NEXT_AUTHORIZED_STAGE={summary['next_authorized_stage']}"]
    (out / "v48g2b_production_claim_box.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print("\n".join(lines)); return 0 if gate or not production else 2


if __name__ == "__main__": raise SystemExit(main())
