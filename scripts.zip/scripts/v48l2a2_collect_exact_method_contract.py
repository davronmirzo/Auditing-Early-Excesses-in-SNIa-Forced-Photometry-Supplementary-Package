from __future__ import annotations
import argparse, hashlib, json, shutil
from pathlib import Path

KEYS={"phase_window_days","native_bands","minimum_points_per_band","t0_relative_bounds_days","alpha_bounds","multistart_t0_guesses_days","initial_alpha","robust_loss","robust_f_scale","maximum_function_evaluations"}
SOURCE_NAMES=["58_freeze_v48a_canonical_methods_contract.py","59_run_v48b_canonical_baseline_scatter.py","64_freeze_v48g1_injection_contract.py","65_validate_v48g2_full_refit_engine.py","66_run_v48g2b_production.py"]
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 ap=argparse.ArgumentParser(); ap.add_argument('--project-root',type=Path,default=Path.cwd()); ap.add_argument('--output-dir',type=Path,default=Path('results/v48_canonical/revision/v48l2a2_exact_contract')); a=ap.parse_args()
 root=a.project_root.resolve(); out=(root/a.output_dir).resolve() if not a.output_dir.is_absolute() else a.output_dir; out.mkdir(parents=True,exist_ok=True)
 srcout=out/'canonical_source'; srcout.mkdir(exist_ok=True); manifest=[]
 for name in SOURCE_NAMES:
  p=root/'scripts'/name
  if not p.exists(): raise SystemExit(f'MISSING_CANONICAL_SOURCE={p}')
  q=srcout/name; shutil.copy2(p,q); manifest.append({'kind':'source','relative_path':str(p.relative_to(root)),'sha256':sha(p),'bytes':p.stat().st_size})
 found=[]
 for p in root.rglob('*.json'):
  if any(x in p.parts for x in ['.git','checkpoints']): continue
  if p.stat().st_size>2_000_000: continue
  try:
   txt=p.read_text(encoding='utf-8'); obj=json.loads(txt)
  except Exception: continue
  hits=sorted(k for k in KEYS if f'"{k}"' in txt)
  if hits:
   q=out/('contract_'+str(len(found)+1).zfill(2)+'_'+p.name); shutil.copy2(p,q)
   found.append({'kind':'contract_json','relative_path':str(p.relative_to(root)),'copied_name':q.name,'matched_keys':'|'.join(hits),'sha256':sha(p),'bytes':p.stat().st_size})
 manifest.extend(found)
 if not found: raise SystemExit('NO_EXACT_METHOD_CONTRACT_JSON_FOUND')
 import pandas as pd
 pd.DataFrame(manifest).to_csv(out/'v48l2a2_exact_contract_manifest.csv',index=False)
 report=['V48L2A2_EXACT_METHOD_CONTRACT_COLLECTION_PASS',f'Canonical source files: {len(SOURCE_NAMES)}',f'Contract JSON files: {len(found)}','Scientific calculations executed: False','Canonical outputs modified: False','NEXT_AUTHORIZED_STAGE=V48L2B_BASELINE_SCATTER_REPRODUCIBILITY_CONTRACT_FREEZE']
 (out/'v48l2a2_report.txt').write_text('\n'.join(report)+'\n',encoding='utf-8'); print('\n'.join(report)); print('\nCONTRACTS')
 for x in found: print(x['relative_path'],x['matched_keys'])
if __name__=='__main__': main()
