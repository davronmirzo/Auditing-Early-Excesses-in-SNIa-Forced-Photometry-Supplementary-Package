from __future__ import annotations

import argparse
import itertools
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd


VERSION = "v48m8_causal_signflip_reconciliation_1.0.0"
OUT_REL = Path("results/v48_canonical/revision/v48m8_reconciliation")


def require(condition: bool, message: str) -> None:
    if not condition:
        raise RuntimeError(message)


def as_bool(series: pd.Series) -> pd.Series:
    return series.astype(str).str.strip().str.lower().isin({"true", "1", "yes"})


def poisson_binomial(probabilities: list[float]) -> np.ndarray:
    pmf = np.array([1.0], dtype=float)
    for q in probabilities:
        pmf = np.convolve(pmf, np.array([1.0 - q, q], dtype=float))
    return pmf / pmf.sum()


def probability_ordered_two_sided(pmf: np.ndarray, observed: int) -> float:
    point_probability = float(pmf[observed])
    return float(pmf[pmf <= point_probability + 1.0e-15].sum())


def exact_blockwise_probabilities(
    residuals: pd.DataFrame, objects: pd.DataFrame
) -> tuple[pd.DataFrame, np.ndarray]:
    primary = objects[as_bool(objects["primary_chi2_le_5"])].copy()
    primary["object_id"] = primary["object_id"].astype(str)

    points = residuals.copy()
    points["object_id"] = points["object_id"].astype(str)
    points = points[
        points["object_id"].isin(set(primary["object_id"]))
        & as_bool(points["in_signal_window"])
    ].copy()
    points["block"] = (
        points["band"].astype(str)
        + ":"
        + np.floor(pd.to_numeric(points["mjd"])).astype(int).astype(str)
    )

    rows: list[dict[str, object]] = []
    probabilities: list[float] = []
    for obj in primary.itertuples(index=False):
        object_id = str(obj.object_id)
        group = points[points["object_id"].eq(object_id)]
        blocks = [
            block["residual_sigma"].to_numpy(float)
            for _, block in group.groupby("block", sort=False)
        ]
        n_blocks = len(blocks)
        positive = 0
        negative = 0
        for signs in itertools.product((-1.0, 1.0), repeat=n_blocks):
            positive_gt5 = any(np.any(sign * values > 5.0) for sign, values in zip(signs, blocks))
            positive_gt3 = sum(
                bool(np.any(sign * values > 3.0)) for sign, values in zip(signs, blocks)
            ) >= 2
            negative_lt5 = any(np.any(sign * values < -5.0) for sign, values in zip(signs, blocks))
            negative_lt3 = sum(
                bool(np.any(sign * values < -3.0)) for sign, values in zip(signs, blocks)
            ) >= 2
            positive += int(positive_gt5 or positive_gt3)
            negative += int(negative_lt5 or negative_lt3)
        n_assignments = 2**n_blocks
        q_positive = positive / n_assignments
        q_negative = negative / n_assignments
        probabilities.append(q_positive)
        rows.append(
            {
                "object_id": object_id,
                "n_blocks": n_blocks,
                "n_sign_assignments": n_assignments,
                "q_positive": q_positive,
                "q_negative": q_negative,
                "observed_positive": bool(obj.positive_flag),
                "observed_sign_reversed": bool(obj.negative_flag),
                "version": VERSION,
            }
        )
    return pd.DataFrame(rows), poisson_binomial(probabilities)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--project-root", default=".")
    args = parser.parse_args()
    root = Path(args.project_root).resolve()
    out = root / OUT_REL
    out.mkdir(parents=True, exist_ok=True)

    baseline = root / "results/v48_canonical/baseline"
    provenance = root / "data/provenance/v1_stage5_stage8"
    current_objects = pd.read_csv(baseline / "v48b_object_summary.csv")
    current_fits = pd.read_csv(baseline / "v48b_object_band_fits.csv")
    current_residuals = pd.read_csv(baseline / "v48b_point_residuals.csv.gz")
    old_objects = pd.read_csv(provenance / "stage5_primary_object_summary.csv")
    old_fits = pd.read_csv(provenance / "stage5_primary_fit_results.csv")
    old_audit = json.loads((provenance / "stage5_core_audit.json").read_text(encoding="utf-8"))

    require(len(current_objects) == 368, "Expected 368 current eligible objects")
    require(len(current_fits) == 736 and len(old_fits) == 736, "Expected paired 736-fit ledgers")
    require(int(as_bool(current_objects["primary_chi2_le_5"]).sum()) == 277, "Current denominator changed")
    require(int(old_audit["primary_objects"]) == 219, "Archived denominator changed")

    blockwise_objects, blockwise_pmf = exact_blockwise_probabilities(
        current_residuals, current_objects
    )
    current_primary = current_objects[as_bool(current_objects["primary_chi2_le_5"])].copy()
    observed_positive = int(as_bool(current_primary["positive_flag"]).sum())
    observed_negative = int(as_bool(current_primary["negative_flag"]).sum())
    require(observed_positive == 2 and observed_negative == 3, "Canonical crossing roster changed")
    support = blockwise_objects[blockwise_objects["q_positive"].gt(0)].copy()
    require(len(support) == 5, "Expected five blockwise threshold-capable objects")
    require(
        np.allclose(sorted(support["q_positive"]), [0.25, 0.5, 0.5, 0.5, 0.5]),
        "Blockwise object probabilities changed",
    )

    k = np.arange(len(blockwise_pmf), dtype=float)
    blockwise_mean = float(np.sum(k * blockwise_pmf))
    blockwise_variance = float(np.sum((k - blockwise_mean) ** 2 * blockwise_pmf))
    blockwise_point = float(blockwise_pmf[observed_positive])
    blockwise_two_sided = probability_ordered_two_sided(blockwise_pmf, observed_positive)

    complete_vector_pmf = np.array(
        [math.comb(5, count) / 32.0 for count in range(6)], dtype=float
    )
    complete_vector_point = float(complete_vector_pmf[observed_positive])
    complete_vector_two_sided = probability_ordered_two_sided(
        complete_vector_pmf, observed_positive
    )

    blockwise_objects.to_csv(out / "v48m8_blockwise_object_probabilities_277.csv", index=False)
    pd.DataFrame(
        {
            "positive_count": np.arange(len(blockwise_pmf)),
            "exact_probability": blockwise_pmf,
            "version": VERSION,
        }
    ).to_csv(out / "v48m8_blockwise_positive_count_pmf.csv", index=False)

    method_comparison = pd.DataFrame(
        [
            {
                "diagnostic": "independent band-night block sign randomization",
                "assumption": "conditional exchangeability of individual band-night block signs",
                "expected_positive_count": blockwise_mean,
                "variance_positive_count": blockwise_variance,
                "p_zero": float(blockwise_pmf[0]),
                "p_observed_count_eq_2": blockwise_point,
                "two_sided_probability_ordered_p": blockwise_two_sided,
            },
            {
                "diagnostic": "complete object-vector sign reversal",
                "assumption": "conditional exchangeability of the two complete-vector orientations",
                "expected_positive_count": 2.5,
                "variance_positive_count": 1.25,
                "p_zero": float(complete_vector_pmf[0]),
                "p_observed_count_eq_2": complete_vector_point,
                "two_sided_probability_ordered_p": complete_vector_two_sided,
            },
        ]
    )
    method_comparison["version"] = VERSION
    method_comparison.to_csv(out / "v48m8_sign_diagnostic_comparison.csv", index=False)

    old_fit_valid_ids = set(old_objects["ztf_id"].astype(str))
    old_primary_ids = set(
        old_objects.loc[as_bool(old_objects["sample_chi2_le_5"]), "ztf_id"].astype(str)
    )
    current_fit_valid_ids = set(
        current_objects.loc[as_bool(current_objects["fit_valid"]), "object_id"].astype(str)
    )
    current_primary_ids = set(
        current_objects.loc[as_bool(current_objects["primary_chi2_le_5"]), "object_id"].astype(str)
    )

    membership = current_objects[["object_id"]].copy()
    membership["old_fit_valid"] = membership["object_id"].isin(old_fit_valid_ids)
    membership["current_fit_valid"] = membership["object_id"].isin(current_fit_valid_ids)
    membership["old_primary"] = membership["object_id"].isin(old_primary_ids)
    membership["current_primary"] = membership["object_id"].isin(current_primary_ids)
    membership["fit_valid_transition"] = np.select(
        [
            membership["old_fit_valid"] & membership["current_fit_valid"],
            ~membership["old_fit_valid"] & membership["current_fit_valid"],
            membership["old_fit_valid"] & ~membership["current_fit_valid"],
        ],
        ["retained", "added", "dropped"],
        default="neither",
    )
    membership["primary_transition"] = np.select(
        [
            membership["old_primary"] & membership["current_primary"],
            ~membership["old_primary"] & membership["current_primary"],
            membership["old_primary"] & ~membership["current_primary"],
        ],
        ["retained", "added", "dropped"],
        default="neither",
    )
    old_flags = old_objects.set_index(old_objects["ztf_id"].astype(str))
    membership["old_positive"] = membership["object_id"].map(
        as_bool(old_flags["positive_band_night"])
    ).astype("boolean").fillna(False).astype(bool)
    membership["old_sign_reversed"] = membership["object_id"].map(
        as_bool(old_flags["negative_band_night"])
    ).astype("boolean").fillna(False).astype(bool)
    current_index = current_objects.set_index(current_objects["object_id"].astype(str))
    membership["current_positive"] = membership["object_id"].map(
        as_bool(current_index["positive_flag"])
    ).astype("boolean").fillna(False).astype(bool)
    membership["current_sign_reversed"] = membership["object_id"].map(
        as_bool(current_index["negative_flag"])
    ).astype("boolean").fillna(False).astype(bool)
    membership["version"] = VERSION
    membership.to_csv(out / "v48m8_original_current_membership_368.csv", index=False)

    old_fit = old_fits.copy()
    old_fit["object_id"] = old_fit["ztf_id"].astype(str)
    new_fit = current_fits.copy()
    new_fit["object_id"] = new_fit["object_id"].astype(str)
    fit_transition = old_fit[
        [
            "object_id", "band", "fit_valid", "failure_reason", "alpha",
            "t0_rest_days", "chi2_dof", "scatter_uJy",
        ]
    ].merge(
        new_fit[
            [
                "object_id", "band", "valid_fit", "success", "alpha_boundary",
                "alpha", "t0", "chi2_dof", "extra_scatter",
            ]
        ],
        on=["object_id", "band"],
        how="outer",
        validate="one_to_one",
        suffixes=("_original", "_current"),
    )
    fit_transition["fit_valid_original"] = as_bool(fit_transition["fit_valid"])
    fit_transition["fit_valid_current"] = as_bool(fit_transition["valid_fit"])
    fit_transition["transition"] = np.select(
        [
            fit_transition["fit_valid_original"] & fit_transition["fit_valid_current"],
            ~fit_transition["fit_valid_original"] & fit_transition["fit_valid_current"],
            fit_transition["fit_valid_original"] & ~fit_transition["fit_valid_current"],
        ],
        ["valid_to_valid", "invalid_to_valid", "valid_to_invalid"],
        default="invalid_to_invalid",
    )
    fit_transition["version"] = VERSION
    fit_transition.to_csv(out / "v48m8_original_current_band_fit_transitions_736.csv", index=False)

    def transition_counts(values: pd.Series) -> dict[str, int]:
        return {str(key): int(value) for key, value in values.value_counts().items()}

    old_cand = old_objects.set_index(old_objects["ztf_id"].astype(str))
    summary = {
        "version": VERSION,
        "three_generation_scope": {
            "generation_1": "simplified non-refit estimate: 70.3 per cent recovery and f95=1.73 per cent",
            "generation_2": "submitted Stage-5/Stage-8 analysis: 245 fit-valid, 219 primary, 0 positive and 3 sign-reversed crossings",
            "generation_3": "canonical revision contract: 303 fit-valid, 277 primary, 2 positive and 3 sign-reversed crossings",
        },
        "paired_band_fit_attempts": 736,
        "band_fit_transitions": transition_counts(fit_transition["transition"]),
        "fit_valid_object_transition": transition_counts(membership["fit_valid_transition"]),
        "primary_object_transition": transition_counts(membership["primary_transition"]),
        "positive_crossing_reconciliation": {
            "ZTF18abebzog": {
                "original_fit_valid": False,
                "current_primary": True,
                "current_max_positive_residual": float(
                    current_index.loc["ZTF18abebzog", "max_positive_residual"]
                ),
            },
            "ZTF19acoxgqw": {
                "original_primary": True,
                "original_max_positive_residual": float(
                    old_cand.loc["ZTF19acoxgqw", "max_positive_residual"]
                ),
                "current_primary": True,
                "current_max_positive_residual": float(
                    current_index.loc["ZTF19acoxgqw", "max_positive_residual"]
                ),
            },
        },
        "blockwise_sign_diagnostic": {
            "threshold_capable_objects": int(len(support)),
            "q_positive_values": sorted(float(value) for value in support["q_positive"]),
            "expected_positive_count": blockwise_mean,
            "variance_positive_count": blockwise_variance,
            "p_zero": float(blockwise_pmf[0]),
            "p_observed_count_eq_2": blockwise_point,
            "two_sided_probability_ordered_p": blockwise_two_sided,
        },
        "complete_vector_sensitivity": {
            "expected_positive_count": 2.5,
            "p_zero": float(complete_vector_pmf[0]),
            "p_observed_count_eq_2": complete_vector_point,
            "two_sided_probability_ordered_p": complete_vector_two_sided,
        },
    }
    require(summary["band_fit_transitions"] == {
        "invalid_to_invalid": 297,
        "valid_to_valid": 274,
        "invalid_to_valid": 131,
        "valid_to_invalid": 34,
    }, "Band-fit transition ledger changed")
    require(summary["fit_valid_object_transition"] == {
        "retained": 236, "neither": 56, "added": 67, "dropped": 9
    }, "Fit-valid object transition ledger changed")
    require(summary["primary_object_transition"] == {
        "retained": 206, "added": 71, "neither": 78, "dropped": 13
    }, "Primary object transition ledger changed")
    (out / "v48m8_causal_reconciliation_summary.json").write_text(
        json.dumps(summary, indent=2), encoding="utf-8"
    )

    report = [
        "V48M8_CAUSAL_SIGNFLIP_RECONCILIATION_PASS",
        "Original/current paired band fits: 736",
        "Band transitions (I-I/V-V/I-V/V-I): 297/274/131/34",
        "Fit-valid objects original/current: 245/303 (retained/added/dropped 236/67/9)",
        "Primary objects original/current: 219/277 (retained/added/dropped 206/71/13)",
        "Observed current positive/sign-reversed crossings: 2/3",
        f"Blockwise E[N+]/P0/P(N+=2)/two-sided p: {blockwise_mean:.6f}/{blockwise_pmf[0]:.6f}/{blockwise_point:.6f}/{blockwise_two_sided:.6f}",
        f"Complete-vector P(N+=2)/two-sided p: {complete_vector_point:.6f}/{complete_vector_two_sided:.6f}",
    ]
    (out / "v48m8_reconciliation_report.txt").write_text(
        "\n".join(report) + "\n", encoding="utf-8"
    )
    print("\n".join(report))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
