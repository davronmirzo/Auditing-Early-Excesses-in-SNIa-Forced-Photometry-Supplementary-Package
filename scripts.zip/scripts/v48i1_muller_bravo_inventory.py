#!/usr/bin/env python3
import argparse
import csv
import gzip
import re
from pathlib import Path

CANDIDATES = [
    ("ZTF18abfhryc","2018dhw","PL,MPL","DD,CI","norm",0.032,True),
    ("ZTF18abmwnov","2018fiw","S,PL,MPL,ND","CI","norm",0.048,False),
    ("ZTF18abspqsn","2018gdl","S,PL","","03fg",0.036,True),
    ("ZTF18abtfvsk","2018fop","MPL,ND","DD,CI","norm",0.021,True),
    ("ZTF18abxxssh","2018gvj","S,PL,MPL,ND","DD","norm",0.066,True),
    ("ZTF18acxyarg","2018kij","MPL,ND","","norm",0.041,True),
    ("ZTF18acybdar","2018kku","MPL,ND","DD,CI","norm",0.064,True),
    ("ZTF19aawmqtd","2019gwg","S,PL,ND","DD","91T",0.056,True),
    ("ZTF19aayfaum","2019hez","PL,MPL","CI","norm",0.024,True),
    ("ZTF19abqhikf","2019nvv","MPL,ND","","91T",0.032,True),
    ("ZTF19aclofmz","2019uaf","MPL,ND","CI","norm",0.031,True),
    ("ZTF20aahkgcz","2020axk","PL,MPL","CI","norm",0.041,True),
    ("ZTF20aajjxwc","2020btv","PL,MPL","DD","91T",0.060,True),
    ("ZTF20aaqpxtm","2020dgc","S,MPL","DD","91T",0.052,True),
    ("ZTF20aazquhc","2020kbh","MPL,ND","","91T",0.034,True),
    ("ZTF20abeywdn","2020mon","MPL,ND","","norm",0.025,True),
    ("ZTF20abnrdse","2020qkw","S,MPL,ND","DD","unknown",0.072,False),
]
SOURCE = "Muller-Bravo et al. 2026, arXiv:2607.22050v1, Table 5"
ID_RX = re.compile(r"(?i)^(object_id|ztf_id|ztfname|ztf_name|name|transient_id|survey_id)$")

def opener(path):
    return gzip.open(path, "rt", encoding="utf-8-sig", newline="") if path.suffix == ".gz" else path.open("r", encoding="utf-8-sig", newline="")

def norm(v):
    return re.sub(r"[^a-z0-9]", "", str(v).lower())

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--project-root", required=True)
    args = ap.parse_args()
    root = Path(args.project_root).resolve()
    out = root / "results" / "v48_canonical" / "external_crossmatch" / "muller_bravo"
    out.mkdir(parents=True, exist_ok=True)

    cat_path = out / "v48i1_catalogue_frozen.csv"
    with cat_path.open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["published_ztf_name","iau_name","empirical_methods","physical_model_methods","subtype","redshift","published_fitquality_flag","candidate_tier","source"])
        for row in CANDIDATES:
            w.writerow([*row,"best_multi_method",SOURCE])

    wanted = {norm(r[0]): r[0] for r in CANDIDATES}
    inventory, hits = [], []
    skip_parts = {".git", ".venv", "site-packages", "node_modules"}
    files = sorted(list(root.rglob("*.csv")) + list(root.rglob("*.csv.gz")))
    for path in files:
        if any(x in path.parts for x in skip_parts) or out in path.parents:
            continue
        rel = str(path.relative_to(root))
        cols, idcols, nrows, err = [], [], 0, ""
        found = set()
        try:
            with opener(path) as f:
                reader = csv.DictReader(f)
                cols = reader.fieldnames or []
                idcols = [c for c in cols if ID_RX.match(c.strip())]
                for row in reader:
                    nrows += 1
                    for c in idcols:
                        key = norm(row.get(c, ""))
                        if key in wanted:
                            found.add((wanted[key], c, str(row.get(c, ""))))
        except Exception as exc:
            err = f"{type(exc).__name__}: {exc}"[:500]
        inventory.append([rel,nrows,"|".join(cols),"|".join(idcols),len(found),err])
        for ztf, col, value in sorted(found):
            hits.append([ztf,rel,col,value])

    with (out / "v48i1_local_csv_inventory.csv").open("w", newline="", encoding="utf-8") as f:
        w=csv.writer(f); w.writerow(["relative_path","rows_scanned","columns","candidate_id_columns","candidate_hits","read_error"]); w.writerows(inventory)
    with (out / "v48i1_candidate_file_hits.csv").open("w", newline="", encoding="utf-8") as f:
        w=csv.writer(f); w.writerow(["published_ztf_name","relative_path","matched_column","matched_value"]); w.writerows(hits)

    hit_names = {h[0] for h in hits}
    report = [
        "V48I1_MULLER_BRAVO_CATALOGUE_FREEZE_AND_LOCAL_SCHEMA_INVENTORY_PASS",
        f"Project root: {root}",
        f"Frozen best multi-method candidates: {len(CANDIDATES)}",
        f"CSV/CSV.GZ tables inventoried: {len(inventory)}",
        f"Candidates found in at least one local table: {len(hit_names)}/17",
        "Found: " + (", ".join(sorted(hit_names)) if hit_names else "NONE"),
        "Not found: " + (", ".join(sorted(set(wanted.values())-hit_names)) or "NONE"),
        "Existing canonical outputs modified: False",
        "Obsolete 219 denominator reused: False",
        "Final attrition inferred in this pass: False",
        "NEXT_AUTHORIZED_STAGE=V48I2_CANONICAL_277_OBJECT_LEVEL_CROSSMATCH",
    ]
    (out / "v48i1_schema_report.txt").write_text("\n".join(report)+"\n", encoding="utf-8")
    print("\n".join(report))

if __name__ == "__main__":
    main()
