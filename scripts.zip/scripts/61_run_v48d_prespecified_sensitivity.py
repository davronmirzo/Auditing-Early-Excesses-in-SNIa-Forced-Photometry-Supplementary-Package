from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd


VERSION = "v48d_prespecified_sensitivity_1.0.0"
STATUS = "V48D_PRESPECIFIED_SENSITIVITY_COMPLETE"
QUALITY_THRESHOLDS = [3.0, 5.0, 7.0, 10.0]
SIGNAL_WINDOWS = [(-0.5, 6.0), (0.0, 6.0), (-0.5, 5.0), (-1.0, 6.0)]
PHASE_OFFSETS = [-0.5, -0.25, 0.0, 0.25, 0.5]


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def b(series: pd.Series) -> pd.Series:
    return series.astype(str).str.strip().str.lower().isin({"true", "1", "yes", "y", "t"})


def classify(points: pd.DataFrame) -> tuple[bool, bool, int, int, int, int]:
    if points.empty:
        return False, False, 0, 0, 0, 0
    x = points.copy()
    x["night"] = np.floor(pd.to_numeric(x["mjd"], errors="coerce")).astype("Int64")
    block = x.groupby(["band", "night"])["residual_sigma"].agg(["max", "min"])
    p5 = int((block["max"] > 5).sum()); p3 = int((block["max"] > 3).sum())
    n5 = int((block["min"] < -5).sum()); n3 = int((block["min"] < -3).sum())
    return bool(p5 >= 1 or p3 >= 2), bool(n5 >= 1 or n3 >= 2), p5, p3, n5, n3


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=".")
    args = ap.parse_args()
    root = Path(args.root).resolve()
    base = root / "results" / "v48_canonical" / "baseline"
    audit = root / "results" / "v48_canonical" / "audit"
    out = root / "results" / "v48_canonical" / "sensitivity"
    paths = {
        "contract": root / "config" / "v48a_canonical_methods_contract.json",
        "v48b_summary": base / "v48b_baseline_scatter_summary.json",
        "objects": base / "v48b_object_summary.csv",
        "points": base / "v48b_point_residuals.csv.gz",
        "v48c_summary": audit / "v48c_denominator_baseline_audit_summary.json",
        "v48c_candidates": audit / "v48c_threshold_crossing_forensic_5.csv",
    }
    for path in paths.values():
        if not path.is_file():
            raise FileNotFoundError(path)
    contract = json.loads(paths["contract"].read_text(encoding="utf-8"))
    v48b = json.loads(paths["v48b_summary"].read_text(encoding="utf-8"))
    v48c = json.loads(paths["v48c_summary"].read_text(encoding="utf-8"))
    if v48b.get("status") != "V48B_CANONICAL_BASELINE_AND_SCATTER_RERUN_COMPLETE":
        raise RuntimeError("V48B gate is not closed")
    if v48c.get("status") != "V48C_DENOMINATOR_AND_BASELINE_AUDIT_COMPLETE":
        raise RuntimeError("V48C gate is not closed")
    frozen = contract["prespecified_sensitivity"]
    if [float(x) for x in frozen["quality_thresholds"]] != QUALITY_THRESHOLDS:
        raise RuntimeError("Quality-threshold grid differs from V48A freeze")
    if [tuple(map(float, x)) for x in frozen["signal_windows_days"]] != SIGNAL_WINDOWS:
        raise RuntimeError("Signal-window grid differs from V48A freeze")
    if [float(x) for x in frozen["named_phase_offsets_days"]] != PHASE_OFFSETS:
        raise RuntimeError("Named phase-offset grid differs from V48A freeze")

    objects = pd.read_csv(paths["objects"])
    points = pd.read_csv(paths["points"])
    candidates0 = pd.read_csv(paths["v48c_candidates"])
    candidate_ids = set(candidates0["object_id"].astype(str))
    if len(objects) != 368 or len(candidate_ids) != 5:
        raise RuntimeError("Expected 368 objects and five V48C threshold crossings")
    objects["fit_valid_bool"] = b(objects["fit_valid"])
    points["phase_since_t0_rest"] = pd.to_numeric(points["phase_since_t0_rest"], errors="coerce")
    points["residual_sigma"] = pd.to_numeric(points["residual_sigma"], errors="coerce")

    grid_rows = []
    membership_rows = []
    for quality in QUALITY_THRESHOLDS:
        eligible = set(objects.loc[objects["fit_valid_bool"] & (pd.to_numeric(objects["median_chi2_dof"], errors="coerce") <= quality), "object_id"].astype(str))
        for lo, hi in SIGNAL_WINDOWS:
            q = points[points["object_id"].astype(str).isin(eligible) & points["phase_since_t0_rest"].between(lo, hi, inclusive="both")]
            result = {oid: classify(g) for oid, g in q.groupby("object_id")}
            positives = sorted(oid for oid, r in result.items() if r[0])
            negatives = sorted(oid for oid, r in result.items() if r[1])
            grid_rows.append({
                "quality_threshold": quality, "window_lo_days": lo, "window_hi_days": hi,
                "denominator_n": len(eligible), "positive_n": len(positives), "negative_n": len(negatives),
                "positive_ids": "|".join(positives), "negative_ids": "|".join(negatives), "version": VERSION,
            })
            for oid in sorted(candidate_ids):
                r = result.get(oid, (False, False, 0, 0, 0, 0))
                membership_rows.append({
                    "object_id": oid, "quality_threshold": quality, "window_lo_days": lo, "window_hi_days": hi,
                    "in_denominator": oid in eligible, "positive_flag": r[0], "negative_flag": r[1],
                    "positive_blocks_gt5": r[2], "positive_blocks_gt3": r[3],
                    "negative_blocks_lt_minus5": r[4], "negative_blocks_lt_minus3": r[5], "version": VERSION,
                })

    offset_rows = []
    offset_membership = []
    primary_ids = set(objects.loc[objects["fit_valid_bool"] & (pd.to_numeric(objects["median_chi2_dof"], errors="coerce") <= 5.0), "object_id"].astype(str))
    for offset in PHASE_OFFSETS:
        # Positive offset means a later assumed t0: phase_shifted = frozen_phase - offset.
        phase_shifted = points["phase_since_t0_rest"] - offset
        q = points[points["object_id"].astype(str).isin(primary_ids) & phase_shifted.between(-0.5, 6.0, inclusive="both")]
        result = {oid: classify(g) for oid, g in q.groupby("object_id")}
        positives = sorted(oid for oid, r in result.items() if r[0])
        negatives = sorted(oid for oid, r in result.items() if r[1])
        offset_rows.append({
            "phase_offset_days": offset, "phase_convention": "shifted_phase=frozen_phase-offset",
            "denominator_n": len(primary_ids), "positive_n": len(positives), "negative_n": len(negatives),
            "positive_ids": "|".join(positives), "negative_ids": "|".join(negatives), "version": VERSION,
        })
        for oid in sorted(candidate_ids):
            r = result.get(oid, (False, False, 0, 0, 0, 0))
            offset_membership.append({"object_id": oid, "phase_offset_days": offset,
                                      "positive_flag": r[0], "negative_flag": r[1], "version": VERSION})

    grid = pd.DataFrame(grid_rows)
    membership = pd.DataFrame(membership_rows)
    offsets = pd.DataFrame(offset_rows)
    offset_member = pd.DataFrame(offset_membership)
    primary_window = membership[(membership["quality_threshold"] == 5.0)]
    primary_kind = dict(zip(candidates0["object_id"].astype(str), candidates0["crossing_label"].astype(str)))
    persistence_rows = []
    for oid in sorted(candidate_ids):
        kind = primary_kind[oid]
        flagcol = "positive_flag" if kind == "positive" else "negative_flag"
        w = primary_window[primary_window["object_id"] == oid]
        off = offset_member[offset_member["object_id"] == oid]
        qbase = membership[(membership["object_id"] == oid) & (membership["window_lo_days"] == -0.5) & (membership["window_hi_days"] == 6.0)]
        nwin = int(w[flagcol].sum()); noff = int(off[flagcol].sum()); nqual = int(qbase[flagcol].sum())
        robust = bool(nwin == 4 and noff == 5)
        persistence_rows.append({
            "object_id": oid, "crossing_label": kind,
            "quality_cells_flagged_of_4": nqual, "primary_window_cells_flagged_of_4": nwin,
            "named_offset_cells_flagged_of_5": noff,
            "all_primary_windows_and_offsets": robust,
            "adjudication": "sensitivity_supported_threshold_crossing" if robust else "sensitivity_fragile_threshold_crossing",
            "astrophysical_detection": False,
            "required_next_check": "point-level photometric and baseline-influence forensics", "version": VERSION,
        })
    persistence = pd.DataFrame(persistence_rows)

    expected = {
        "ZTF18abebzog": ("positive", 3, 4, False),
        "ZTF19acoxgqw": ("positive", 4, 5, True),
        "ZTF18ablqlzp": ("negative", 3, 4, False),
        "ZTF18abnygkb": ("negative", 4, 5, True),
        "ZTF19aawupxb": ("negative", 4, 5, True),
    }
    observed = {r.object_id: (r.crossing_label, int(r.primary_window_cells_flagged_of_4),
                              int(r.named_offset_cells_flagged_of_5), bool(r.all_primary_windows_and_offsets))
                for r in persistence.itertuples(index=False)}
    if observed != expected:
        raise RuntimeError(f"V48D persistence result differs from validated contract: {observed}")

    out.mkdir(parents=True, exist_ok=True)
    grid.to_csv(out / "v48d_quality_window_grid_16.csv", index=False)
    membership.to_csv(out / "v48d_candidate_quality_window_membership_80.csv", index=False)
    offsets.to_csv(out / "v48d_named_phase_offset_grid_5.csv", index=False)
    offset_member.to_csv(out / "v48d_candidate_phase_offset_membership_25.csv", index=False)
    persistence.to_csv(out / "v48d_candidate_persistence_5.csv", index=False)
    summary = {
        "status": STATUS, "version": VERSION,
        "input_sha256": {k: sha256(v) for k, v in paths.items()},
        "quality_thresholds": QUALITY_THRESHOLDS,
        "signal_windows_days": SIGNAL_WINDOWS,
        "phase_offsets_days": PHASE_OFFSETS,
        "primary_positive_negative": [2, 3],
        "sensitivity_supported_positive_ids": ["ZTF19acoxgqw"],
        "sensitivity_fragile_positive_ids": ["ZTF18abebzog"],
        "sensitivity_supported_negative_ids": ["ZTF18abnygkb", "ZTF19aawupxb"],
        "sensitivity_fragile_negative_ids": ["ZTF18ablqlzp"],
        "detections_confirmed": 0,
        "new_fit_executed": False, "injection_recovery_executed": False,
        "population_limits_computed": False, "archived_outputs_overwritten": False,
        "next_authorized_stage": "V48E_POINT_LEVEL_PHOTOMETRIC_AND_BASELINE_INFLUENCE_FORENSICS",
    }
    (out / "v48d_prespecified_sensitivity_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    lines = [
        STATUS, "V48D_FROZEN_GRID_GATE_PASS", "V48D_NO_ASTROPHYSICAL_DETECTION_CONFIRMED",
        "Quality thresholds: 3,5,7,10", "Signal windows evaluated: 4", "Named phase offsets evaluated: 5",
        "Primary positive/negative threshold crossings: 2/3",
        "Sensitivity-supported positive: ZTF19acoxgqw",
        "Sensitivity-fragile positive: ZTF18abebzog",
        "Sensitivity-supported negatives: ZTF18abnygkb|ZTF19aawupxb",
        "Sensitivity-fragile negative: ZTF18ablqlzp",
        "New fit executed: False", "Injection-recovery executed: False", "Population limits computed: False",
        "Archived 219/v44 outputs overwritten: False",
        "NEXT_AUTHORIZED_STAGE=V48E_POINT_LEVEL_PHOTOMETRIC_AND_BASELINE_INFLUENCE_FORENSICS",
    ]
    (out / "v48d_prespecified_sensitivity_claim_box.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print("\n".join(lines))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
