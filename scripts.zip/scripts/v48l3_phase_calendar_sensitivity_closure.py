from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd

VERSION = "v48l3_phase_calendar_sensitivity_closure_1.0.0"
OUT_REL = Path("results/v48_canonical/revision/v48l3_phase_calendar")


def require(ok: bool, message: str) -> None:
    if not ok:
        raise RuntimeError(message)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--project-root", default=".")
    args = ap.parse_args()
    root = Path(args.project_root).resolve()
    out = root / OUT_REL
    out.mkdir(parents=True, exist_ok=True)

    sens = root / "results/v48_canonical/sensitivity"
    inj = root / "results/v48_canonical/injection/production"
    forensic = root / "results/v48_canonical/forensics/v48e_candidate_adjudication_5.csv"
    qpath = sens / "v48d_quality_window_grid_16.csv"
    opath = sens / "v48d_named_phase_offset_grid_5.csv"
    epath = inj / "v48g2b_recovery_efficiency_by_mode.csv"
    for p in (qpath, opath, epath, forensic):
        require(p.is_file(), f"Missing canonical input: {p}")

    q = pd.read_csv(qpath)
    o = pd.read_csv(opath)
    e = pd.read_csv(epath)
    f = pd.read_csv(forensic)
    require(len(q) == 16, f"Expected 16 quality-window cells, got {len(q)}")
    require(len(o) == 5, f"Expected 5 named phase-offset cells, got {len(o)}")
    require(len(e) == 40, f"Expected 40 injection-mode cells, got {len(e)}")
    require(set(q["quality_threshold"].astype(float)) == {3.0, 5.0, 7.0, 10.0}, "Quality grid changed")
    require(set(o["phase_offset_days"].astype(float)) == {-0.5, -0.25, 0.0, 0.25, 0.5}, "Offset grid changed")
    require(set(e["calendar_mode"]) == {"shared-physical-date", "band-relative-date"}, "Calendar modes changed")
    require(set(e["alpha_refit_mode"]) == {"free", "fixed-to-pre-injection"}, "Alpha modes changed")
    require(set(e["scatter_policy"]) == {"frozen-pre-injection", "reestimated-post-injection"}, "Scatter modes changed")
    require(int(pd.to_numeric(e["refit_failures"], errors="raise").sum()) == 0, "Nonzero refit failures")

    astro = f["astrophysical_detection"].astype(str).str.lower().isin({"true", "1", "yes"})
    confirmed = int(astro.sum())
    require(confirmed == 0, f"Expected zero confirmed detections, got {confirmed}")

    q_primary = q[pd.to_numeric(q["quality_threshold"]) == 5.0].copy()
    phase_rows = []
    for kind, d, xcol in (("signal_window_at_primary_chi2", q_primary, "window_lo_days"),
                           ("named_phase_offset", o, "phase_offset_days")):
        phase_rows.append({
            "sensitivity_axis": kind,
            "cells": len(d),
            "positive_raw_min": int(d["positive_n"].min()),
            "positive_raw_max": int(d["positive_n"].max()),
            "negative_raw_min": int(d["negative_n"].min()),
            "negative_raw_max": int(d["negative_n"].max()),
            "confirmed_astrophysical_detections": confirmed,
            "interpretation": "raw crossing counts vary; forensic confirmed count remains zero",
        })
    phase_summary = pd.DataFrame(phase_rows)
    phase_summary.to_csv(out / "v48l3_phase_sensitivity_summary.csv", index=False)

    keys = ["template_id", "alpha_refit_mode", "scatter_policy"]
    a = e[e["calendar_mode"] == "band-relative-date"].set_index(keys)
    s = e[e["calendar_mode"] == "shared-physical-date"].set_index(keys)
    require(set(a.index) == set(s.index) and len(a) == 20, "Calendar cells do not pair one-to-one")
    rows = []
    for key in sorted(a.index):
        ar, sr = a.loc[key], s.loc[key]
        eb, es = float(ar.efficiency), float(sr.efficiency)
        rows.append({
            "template_id": key[0], "alpha_refit_mode": key[1], "scatter_policy": key[2],
            "band_relative_trials": int(ar.trials), "band_relative_recovered": int(ar.recovered),
            "band_relative_efficiency": eb,
            "shared_physical_trials": int(sr.trials), "shared_physical_recovered": int(sr.recovered),
            "shared_physical_efficiency": es,
            "band_minus_shared_efficiency": eb - es,
            "band_over_shared_efficiency": (eb / es if es > 0 else np.nan),
            "calendar_equal": bool(np.isclose(eb, es, rtol=0, atol=1e-15)),
        })
    cal = pd.DataFrame(rows)
    cal.to_csv(out / "v48l3_calendar_mode_paired_efficiencies.csv", index=False)

    primary = e[(e["alpha_refit_mode"] == "free") &
                (e["calendar_mode"] == "shared-physical-date") &
                (e["scatter_policy"] == "frozen-pre-injection")].copy()
    require(len(primary) == 5, f"Expected 5 primary template cells, got {len(primary)}")

    frozen_cal = cal[cal["scatter_policy"] == "frozen-pre-injection"]
    closure = {
        "version": VERSION,
        "canonical_phase_grid_cells": len(q),
        "primary_chi2_signal_window_cells": len(q_primary),
        "named_phase_offset_cells": len(o),
        "phase_offset_range_days": [float(o.phase_offset_days.min()), float(o.phase_offset_days.max())],
        "primary_window_raw_positive_range": [int(q_primary.positive_n.min()), int(q_primary.positive_n.max())],
        "primary_window_raw_negative_range": [int(q_primary.negative_n.min()), int(q_primary.negative_n.max())],
        "named_offset_raw_positive_range": [int(o.positive_n.min()), int(o.positive_n.max())],
        "named_offset_raw_negative_range": [int(o.negative_n.min()), int(o.negative_n.max())],
        "confirmed_astrophysical_detections": confirmed,
        "injection_mode_cells": len(e),
        "paired_calendar_comparisons": len(cal),
        "equal_calendar_efficiency_pairs": int(cal.calendar_equal.sum()),
        "unequal_calendar_efficiency_pairs": int((~cal.calendar_equal).sum()),
        "maximum_absolute_calendar_efficiency_difference": float(cal.band_minus_shared_efficiency.abs().max()),
        "frozen_scatter_calendar_pairs": len(frozen_cal),
        "primary_mode": {"alpha_refit_mode": "free", "calendar_mode": "shared-physical-date", "scatter_policy": "frozen-pre-injection"},
        "primary_template_efficiency_min": float(primary.efficiency.min()),
        "primary_template_efficiency_max": float(primary.efficiency.max()),
        "claim_phase_robustness": "The raw-crossing roster is phase-definition dependent, but no phase cell establishes a confirmed astrophysical detection because all crossings remain subject to the completed V48E/V48F adjudication.",
        "claim_calendar_robustness": "Recovery efficiency is calendar-mode dependent and must be reported by mode; calendar modes must not be pooled or described as interchangeable.",
        "derived_audit_summaries_computed": True,
        "fits_or_injections_rerun": False,
        "canonical_outputs_modified": False,
        "claims_frozen": True,
        "next_authorized_stage": "V48L4_POPULATION_LIMIT_SENSITIVITY_CLOSURE",
    }
    (out / "v48l3_closure_summary.json").write_text(json.dumps(closure, indent=2), encoding="utf-8")

    manuscript = """**Phase and calendar sensitivity.** **At the primary reduced-chi-square threshold, the four prespecified signal windows produced one to two raw positive crossings and two to three sign-reversed crossings. Across the five named phase offsets from -0.5 to +0.5 d, the corresponding ranges were one to two and two to three. Thus, individual raw-crossing membership is phase-definition dependent. These counts are screening diagnostics rather than detections: after the completed point-level, leave-trigger-night-out, and raw-photometry adjudication, the confirmed astrophysical count remains zero. We therefore do not interpret invariance of every raw candidate as a requirement for the null detection result.**

**Injection recovery was also evaluated separately under a shared physical injection date and band-relative dates, crossed with free or fixed-to-pre-injection alpha and frozen or re-estimated empirical scatter. The 40 mode cells cannot be pooled: paired calendar efficiencies are not generally equal, and the associated population limits are correspondingly mode dependent. Our primary mode is the prospectively frozen combination of free alpha, a shared physical date, and pre-injection frozen scatter; every alternative calendar, alpha, and scatter result is reported as sensitivity rather than substituted for that primary definition.**
"""
    (out / "v48l3_manuscript_insertion_bold.txt").write_text(manuscript, encoding="utf-8")
    response = """**Response — phase and calendar sensitivity.** **We now report the complete prespecified phase/window and injection-calendar sensitivity rather than relying on a single timing convention. Four signal windows at the primary quality threshold and five named offsets spanning -0.5 to +0.5 d show that the raw-crossing roster varies modestly, while the completed forensic classification remains at zero confirmed astrophysical detections. We also provide paired recovery efficiencies for the shared-physical-date and band-relative-date injection calendars across every template, alpha-refit, and scatter-policy combination. These efficiencies are explicitly treated as mode dependent and are not pooled. The prospectively frozen free-alpha/shared-physical-date/frozen-scatter cell remains primary, with all other cells labelled sensitivity analyses. No fit or injection trial was rerun in this closure stage.**
"""
    (out / "v48l3_response_letter_text_bold.txt").write_text(response, encoding="utf-8")
    (out / "v48l3_allowed_claims.txt").write_text(
        "ALLOWED CLAIMS\n- Raw crossings vary with phase/window definition.\n- Confirmed astrophysical detections remain zero after canonical forensics.\n- Calendar-mode efficiencies are mode dependent and separately reported.\n- The primary mode is free alpha, shared physical date, and frozen pre-injection scatter.\n", encoding="utf-8")
    (out / "v48l3_prohibited_claims.txt").write_text(
        "PROHIBITED CLAIMS\n- Do not claim every raw candidate is phase invariant.\n- Do not call non-primary phase-grid crossings confirmed detections.\n- Do not pool calendar modes or call them interchangeable.\n- Do not select the most constraining mode after inspecting results.\n- Do not infer a physical-channel occurrence rate from proxy-template limits.\n", encoding="utf-8")

    report = [
        "V48L3_PHASE_CALENDAR_SENSITIVITY_CLOSURE_PASS",
        f"Quality-window/named-offset cells: {len(q)}/{len(o)}",
        f"Primary-window raw positive/negative ranges: {q_primary.positive_n.min()}-{q_primary.positive_n.max()}/{q_primary.negative_n.min()}-{q_primary.negative_n.max()}",
        f"Named-offset raw positive/negative ranges: {o.positive_n.min()}-{o.positive_n.max()}/{o.negative_n.min()}-{o.negative_n.max()}",
        f"Confirmed astrophysical detections: {confirmed}",
        f"Injection/calendar-paired cells: {len(e)}/{len(cal)}",
        f"Equal/unequal calendar-efficiency pairs: {int(cal.calendar_equal.sum())}/{int((~cal.calendar_equal).sum())}",
        f"Maximum absolute calendar efficiency difference: {cal.band_minus_shared_efficiency.abs().max():.9f}",
        "Fits or injections rerun: False",
        "Canonical outputs modified: False",
        "Claims frozen: True",
        "NEXT_AUTHORIZED_STAGE=V48L4_POPULATION_LIMIT_SENSITIVITY_CLOSURE",
    ]
    (out / "v48l3_report.txt").write_text("\n".join(report) + "\n", encoding="utf-8")
    print("\n".join(report))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
