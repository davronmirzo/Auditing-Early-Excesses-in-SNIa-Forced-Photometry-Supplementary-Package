from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from scipy.optimize import least_squares


VERSION = "v48b_canonical_baseline_scatter_1.0.0"
STATUS = "V48B_CANONICAL_BASELINE_AND_SCATTER_RERUN_COMPLETE"


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def to_bool(s: pd.Series) -> pd.Series:
    return s.astype(str).str.strip().str.lower().isin({"true", "1", "yes", "y", "t"})


def model(t_rel: np.ndarray, amp: float, t0_rel: float, alpha: float) -> np.ndarray:
    return float(amp) * np.power(np.maximum(np.asarray(t_rel, float) - float(t0_rel), 0.0), float(alpha))


def robust_scale(raw_residual: np.ndarray, formal: np.ndarray) -> float:
    r = np.asarray(raw_residual, float)
    f = np.asarray(formal, float)
    good = np.isfinite(r) & np.isfinite(f) & (f > 0)
    if not np.any(good):
        return 0.0
    r = r[good]; f = f[good]
    med = float(np.median(r))
    mad = 1.4826 * float(np.median(np.abs(r - med)))
    fmed = float(np.median(f))
    if not np.isfinite(mad) or not np.isfinite(fmed):
        return 0.0
    return float(math.sqrt(max(mad * mad - fmed * fmed, 0.0)))


def fit_once(t: np.ndarray, y: np.ndarray, eff: np.ndarray, cfg: dict[str, Any], init: dict[str, Any] | None = None) -> dict[str, Any]:
    tref = float(np.min(t)); tr = np.asarray(t, float) - tref
    yscale = max(float(np.nanpercentile(np.abs(y), 90)), float(np.nanmedian(eff)), 1.0)
    t0_lo = float(cfg["t0_relative_bounds_days"][0])
    t0_hi = min(5.0, float(np.min(tr)) + 2.0)
    alpha_lo, alpha_hi = map(float, cfg["alpha_bounds"])
    best = None
    starts = cfg["multistart_t0_guesses_days"] if init is None else [float(init["t0_rel"])]
    for t0g in starts:
        t0g = float(np.clip(float(t0g), t0_lo + 1e-8, t0_hi - 1e-8))
        base = max(float(np.max(tr) - t0g), 1.0)
        amp0 = max(float(np.nanmax(y)) / (base ** float(cfg["initial_alpha"])), 1e-8) if init is None else max(float(init["amp"]), 1e-8)
        alpha0 = float(cfg["initial_alpha"]) if init is None else float(init["alpha"])
        p0 = np.array([amp0, t0g, alpha0], float)
        lo = np.array([1e-14, t0_lo, alpha_lo], float)
        hi = np.array([max(1e6 * yscale, 1.0), t0_hi, alpha_hi], float)

        def resid(p: np.ndarray) -> np.ndarray:
            return (y - model(tr, p[0], p[1], p[2])) / eff

        try:
            res = least_squares(
                resid, p0, bounds=(lo, hi), loss=str(cfg["robust_loss"]),
                f_scale=float(cfg["robust_f_scale"]),
                max_nfev=int(cfg["maximum_function_evaluations"]),
            )
        except Exception as exc:  # noqa: BLE001
            candidate = {"success": False, "message": str(exc)[:200], "cost": np.inf}
        else:
            candidate = {
                "success": bool(res.success and np.all(np.isfinite(res.x))),
                "message": str(res.message)[:200], "cost": float(res.cost),
                "amp": float(res.x[0]), "t0_rel": float(res.x[1]),
                "alpha": float(res.x[2]), "nfev": int(res.nfev),
            }
        if best is None or candidate["cost"] < best["cost"]:
            best = candidate
    assert best is not None
    best["t_ref"] = tref
    best["t0"] = tref + float(best.get("t0_rel", np.nan))
    return best


def fit_band(g: pd.DataFrame, cfg: dict[str, Any], scatter_cfg: dict[str, Any]) -> dict[str, Any]:
    g = g.sort_values("mjd").copy()
    t = g["mjd"].to_numpy(float); y = g["flux"].to_numpy(float); formal = g["fluxerr"].to_numpy(float)
    if len(g) < int(cfg["minimum_points_per_band"]):
        return {"success": False, "valid_fit": False, "message": "too_few_points", "n_points": len(g)}
    scatter = 0.0; converged = False; iterations = 0; best: dict[str, Any] = {}
    for iteration in range(1, 21):
        iterations = iteration
        eff = np.sqrt(formal * formal + scatter * scatter)
        best = fit_once(t, y, eff, cfg, None if iteration == 1 else best)
        if not best.get("success", False):
            break
        pred = model(t - best["t_ref"], best["amp"], best["t0_rel"], best["alpha"])
        new_scatter = robust_scale(y - pred, formal)
        scale = max(abs(scatter), abs(new_scatter), 1e-8)
        if abs(new_scatter - scatter) / scale <= 1e-4:
            scatter = new_scatter; converged = True; break
        scatter = new_scatter
    if best.get("success", False):
        eff = np.sqrt(formal * formal + scatter * scatter)
        best = fit_once(t, y, eff, cfg, best)
    success = bool(best.get("success", False))
    if success:
        pred = model(t - best["t_ref"], best["amp"], best["t0_rel"], best["alpha"])
        rr = (y - pred) / np.sqrt(formal * formal + scatter * scatter)
        dof = int(len(y) - 3)
        chi2 = float(np.sum(rr * rr)); chi2_dof = chi2 / dof if dof > 0 else np.nan
        tol = 0.01; alo, ahi = map(float, cfg["alpha_bounds"])
        alpha_boundary = bool(best["alpha"] <= alo + tol or best["alpha"] >= ahi - tol)
        valid_fit = bool(dof > 0 and best["amp"] > 0 and np.all(np.isfinite([best["t0"], best["amp"], best["alpha"], chi2_dof])) and not alpha_boundary)
    else:
        dof = 0; chi2 = chi2_dof = np.nan; alpha_boundary = False; valid_fit = False
    return {
        "success": success, "valid_fit": valid_fit, "message": best.get("message", "fit_failed"),
        "n_points": int(len(g)), "dof": dof, "chi2": chi2, "chi2_dof": chi2_dof,
        "t0": best.get("t0", np.nan), "amplitude": best.get("amp", np.nan),
        "alpha": best.get("alpha", np.nan), "alpha_boundary": alpha_boundary,
        "extra_scatter": float(scatter), "scatter_iterations": iterations,
        "scatter_converged": converged, "nfev_final": best.get("nfev", 0),
    }


def classify(q: pd.DataFrame) -> dict[str, Any]:
    if q.empty:
        return {"positive_flag": False, "negative_flag": False, "n_night_blocks": 0,
                "max_positive_residual": np.nan, "max_negative_abs_residual": np.nan}
    x = q.copy(); x["night"] = np.floor(x["mjd"]).astype(int)
    gb = x.groupby(["band", "night"])["residual_sigma"]
    mx = gb.max().to_numpy(float); mn = gb.min().to_numpy(float)
    return {
        "positive_flag": bool(np.any(mx > 5.0) or np.sum(mx > 3.0) >= 2),
        "negative_flag": bool(np.any(mn < -5.0) or np.sum(mn < -3.0) >= 2),
        "n_night_blocks": int(len(mx)),
        "max_positive_residual": float(np.max(mx)),
        "max_negative_abs_residual": float(abs(np.min(mn))),
    }


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=".")
    args = ap.parse_args()
    root = Path(args.root).resolve()
    contract_path = root / "config" / "v48a_canonical_methods_contract.json"
    freeze_path = root / "results" / "v48_canonical" / "freeze" / "v48a_methods_contract_freeze.json"
    eligible_path = root / "results" / "v48_canonical" / "freeze" / "v48a_eligible_native_co_368.csv"
    lc_path = root / "data" / "processed" / "earlyrise_lightcurves.csv"
    for p in (contract_path, freeze_path, eligible_path, lc_path):
        if not p.is_file(): raise FileNotFoundError(p)
    contract = json.loads(contract_path.read_text(encoding="utf-8"))
    freeze = json.loads(freeze_path.read_text(encoding="utf-8"))
    if freeze.get("status") != "V48A_CANONICAL_METHODS_CONTRACT_FROZEN":
        raise RuntimeError("V48A freeze gate is not closed")
    if freeze.get("contract_sha256") != sha256(contract_path) or freeze.get("input_sha256") != sha256(lc_path):
        raise RuntimeError("Frozen contract or input changed after V48A")

    eligible = pd.read_csv(eligible_path); eligible_ids = set(eligible["object_id"].astype(str))
    if len(eligible_ids) != 368: raise RuntimeError("Frozen eligible set is not 368 objects")
    d = pd.read_csv(lc_path, low_memory=False)
    for c in ("mjd", "flux", "fluxerr", "redshift", "rest_phase"):
        d[c] = pd.to_numeric(d[c], errors="coerce")
    d["object_id"] = d["object_id"].astype(str).str.strip(); d["band"] = d["band"].astype(str).str.strip().str.lower()
    lo, hi = contract["eligibility"]["phase_window_days"]
    d = d[d["object_id"].isin(eligible_ids) & d["band"].isin({"c", "o"}) & d["mjd"].notna() & d["flux"].notna() & d["fluxerr"].gt(0) & d["rest_phase"].between(lo, hi, inclusive="both")].copy()

    fit_rows = []
    groups = list(d.groupby(["object_id", "band"], sort=True))
    for idx, ((oid, band), g) in enumerate(groups, start=1):
        r = fit_band(g, contract["baseline"], contract["empirical_scatter"])
        r.update({"object_id": oid, "band": band, "version": VERSION})
        fit_rows.append(r)
        if idx % 100 == 0:
            print(f"V48B fit progress: {idx}/{len(groups)} object-band groups", flush=True)
    fits = pd.DataFrame(fit_rows)
    valid = fits[fits["valid_fit"]].copy()

    point_rows = []
    zmap = d.groupby("object_id")["redshift"].median().to_dict()
    for r in valid.itertuples(index=False):
        g = d[(d["object_id"] == r.object_id) & (d["band"] == r.band)].copy()
        pred = model(g["mjd"].to_numpy(float) - float(g["mjd"].min()), float(r.amplitude), float(r.t0) - float(g["mjd"].min()), float(r.alpha))
        eff = np.sqrt(g["fluxerr"].to_numpy(float) ** 2 + float(r.extra_scatter) ** 2)
        z = float(zmap.get(r.object_id, 0.0)); z = z if np.isfinite(z) else 0.0
        g["model_flux"] = pred; g["effective_sigma"] = eff
        g["residual_sigma"] = (g["flux"].to_numpy(float) - pred) / eff
        g["phase_since_t0_rest"] = (g["mjd"].to_numpy(float) - float(r.t0)) / (1.0 + z)
        g["in_signal_window"] = g["phase_since_t0_rest"].between(-0.5, 6.0, inclusive="both")
        g["extra_scatter"] = float(r.extra_scatter)
        point_rows.append(g[["object_id", "band", "mjd", "flux", "fluxerr", "model_flux", "effective_sigma", "extra_scatter", "residual_sigma", "phase_since_t0_rest", "in_signal_window"]])
    points = pd.concat(point_rows, ignore_index=True) if point_rows else pd.DataFrame()

    obj_rows = []
    for oid in sorted(eligible_ids):
        vf = valid[valid["object_id"] == oid]
        q = points[(points["object_id"] == oid) & to_bool(points["in_signal_window"])] if not points.empty else pd.DataFrame()
        c = classify(q)
        obj_rows.append({
            "object_id": oid, "eligible": True, "n_valid_band_fits": int(len(vf)),
            "fit_valid": bool(len(vf) >= 1),
            "median_chi2_dof": float(vf["chi2_dof"].median()) if len(vf) else np.nan,
            "primary_chi2_le_5": bool(len(vf) and vf["chi2_dof"].median() <= 5.0),
            "n_signal_points": int(len(q)), "n_signal_bands": int(q["band"].nunique()) if len(q) else 0,
            **c,
        })
    objects = pd.DataFrame(obj_rows)

    out = root / "results" / "v48_canonical" / "baseline"; out.mkdir(parents=True, exist_ok=True)
    fits.to_csv(out / "v48b_object_band_fits.csv", index=False)
    points.to_csv(out / "v48b_point_residuals.csv.gz", index=False, compression="gzip")
    objects.to_csv(out / "v48b_object_summary.csv", index=False)
    fit_valid_n = int(objects["fit_valid"].sum()); primary_n = int(objects["primary_chi2_le_5"].sum())
    primary = objects[objects["primary_chi2_le_5"]]
    summary = {
        "status": STATUS, "version": VERSION,
        "contract_sha256": sha256(contract_path), "input_sha256": sha256(lc_path),
        "eligible_objects": 368, "object_band_fit_attempts": int(len(fits)),
        "valid_object_band_fits": int(fits["valid_fit"].sum()),
        "fit_valid_objects": fit_valid_n, "primary_chi2_le_5_objects": primary_n,
        "positive_flags_primary": int(primary["positive_flag"].sum()),
        "negative_flags_primary": int(primary["negative_flag"].sum()),
        "scatter_converged_fraction_all_attempts": float(fits["scatter_converged"].mean()),
        "archived_219_outputs_overwritten": False, "v44_outputs_overwritten": False,
        "injection_recovery_executed": False, "population_limits_computed": False,
    }
    (out / "v48b_baseline_scatter_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    lines = [
        STATUS, f"Eligible objects: 368", f"Object-band fit attempts: {len(fits)}",
        f"Valid object-band fits: {int(fits['valid_fit'].sum())}", f"Fit-valid objects: {fit_valid_n}",
        f"Primary chi2<=5 objects: {primary_n}",
        f"Primary positive/negative flags: {int(primary['positive_flag'].sum())}/{int(primary['negative_flag'].sum())}",
        f"Scatter-converged fraction: {fits['scatter_converged'].mean():.6f}",
        "Archived 219/v44 outputs overwritten: False", "Injection-recovery executed: False",
        "Population limits computed: False", "NEXT_AUTHORIZED_STAGE=V48C_DENOMINATOR_AND_BASELINE_AUDIT"
    ]
    (out / "v48b_baseline_scatter_claim_box.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print("\n".join(lines))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
