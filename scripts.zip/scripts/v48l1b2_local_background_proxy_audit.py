from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import kruskal, mannwhitneyu

VERSION = "v48l1b2_local_background_proxy_audit_1.0.0"
GROUPS = ["no_valid_fit", "fit_valid_chi2_gt5", "primary_chi2_le5"]


def truth(s):
    return s.astype(str).str.strip().str.lower().isin(["true", "1", "yes"])


def cliffs(x, y):
    x, y = np.asarray(x, float), np.asarray(y, float)
    x, y = x[np.isfinite(x)], y[np.isfinite(y)]
    if not len(x) or not len(y):
        return np.nan
    return float(sum(np.sign(v-y).sum() for v in x)/(len(x)*len(y)))


def qsummary(x):
    x = pd.to_numeric(x, errors="coerce").dropna().to_numpy(float)
    return len(x), (np.median(x) if len(x) else np.nan), (np.percentile(x,16) if len(x) else np.nan), (np.percentile(x,84) if len(x) else np.nan)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--project-root", type=Path, default=Path.cwd())
    ap.add_argument("--output-dir", type=Path, default=Path("results/v48_canonical/revision/v48l1b2_background"))
    a = ap.parse_args(); root = a.project_root.resolve()
    out = (root/a.output_dir).resolve() if not a.output_dir.is_absolute() else a.output_dir
    out.mkdir(parents=True, exist_ok=True)
    p_attr = root/"results/v48_canonical/revision/v48l1b_attrition/v48l1b_object_level_attrition_covariates_368.csv"
    p_phot = root/"data/interim/atlas_forcedphot_standardized.csv"
    p_snia = root/"data/raw/ztf_dr2/tables/local_snia_data.csv"
    for p in [p_attr,p_phot,p_snia]:
        if not p.exists(): raise SystemExit(f"MISSING_INPUT={p}")
    d = pd.read_csv(p_attr)
    if len(d)!=368 or d.object_id.astype(str).nunique()!=368: raise SystemExit("ATTRITION_368_GATE_FAIL")
    phot = pd.read_csv(p_phot)
    req = {"object_id","mjd","band","flux","fluxerr"}
    if not req.issubset(phot.columns): raise SystemExit(f"PHOTOMETRY_COLUMNS_MISSING={sorted(req-set(phot.columns))}")
    sn = pd.read_csv(p_snia)
    if not {"ztfname","t0","redshift"}.issubset(sn.columns): raise SystemExit("SNIA_T0_REDSHIFT_COLUMNS_MISSING")
    sn = sn[["ztfname","t0","redshift"]].rename(columns={"ztfname":"object_id"}).drop_duplicates("object_id")
    phot["object_id"] = phot.object_id.astype(str)
    phot = phot.merge(sn, on="object_id", how="left", validate="many_to_one")
    for c in ["mjd","flux","fluxerr","t0","redshift"]: phot[c]=pd.to_numeric(phot[c],errors="coerce")
    phot = phot[phot.band.astype(str).str.lower().isin(["c","o"]) & phot.fluxerr.gt(0)].copy()
    phot["rest_phase"]=(phot.mjd-phot.t0)/(1+phot.redshift)

    def aggregate(g):
        early=g[g.rest_phase.between(-18,-5,inclusive="both")]
        pre=g[g.rest_phase.between(-60,-25,inclusive="both")]
        def mad(x):
            x=pd.to_numeric(x,errors="coerce").dropna().to_numpy(float)
            return np.median(np.abs(x-np.median(x))) if len(x) else np.nan
        return pd.Series({
            "n_native_early_measurements":len(early),
            "early_median_fluxerr":early.fluxerr.median(),
            "early_flux_mad":mad(early.flux),
            "early_median_abs_flux":early.flux.abs().median(),
            "n_native_pre_event_measurements":len(pre),
            "pre_event_median_fluxerr":pre.fluxerr.median(),
            "pre_event_flux_mad":mad(pre.flux),
        })
    agg=phot.groupby("object_id",sort=True).apply(aggregate,include_groups=False).reset_index()
    z=d.merge(agg,on="object_id",how="left",validate="one_to_one")
    metrics=["early_median_fluxerr","early_flux_mad","early_median_abs_flux","pre_event_median_fluxerr","pre_event_flux_mad"]
    rows=[]; pairs=[]
    for m in metrics:
        arrays=[]
        for g in GROUPS:
            vals=z.loc[z.attrition_group.eq(g),m]
            n,med,q16,q84=qsummary(vals); arrays.append(pd.to_numeric(vals,errors="coerce").dropna().to_numpy(float))
            rows.append({"metric":m,"group":g,"n_total":int(z.attrition_group.eq(g).sum()),"n_available":n,
                         "missing_fraction":1-n/int(z.attrition_group.eq(g).sum()),"median":med,"q16":q16,"q84":q84})
        pkw=kruskal(*arrays).pvalue if all(len(x) for x in arrays) else np.nan
        for r in rows[-3:]: r["kruskal_p_all_groups"]=pkw
        y=arrays[2]
        for g,x in zip(GROUPS[:2],arrays[:2]):
            p=mannwhitneyu(x,y,alternative="two-sided").pvalue if len(x) and len(y) else np.nan
            pairs.append({"metric":m,"attrition_group":g,"reference_group":GROUPS[2],"n_attrition":len(x),"n_reference":len(y),"mannwhitney_p":p,"cliffs_delta":cliffs(x,y)})
    summary=pd.DataFrame(rows); pair=pd.DataFrame(pairs)
    pair["holm_significant_0p05"]=False
    order=pair.mannwhitney_p.dropna().sort_values().index; active=True; mm=len(order)
    for rank,idx in enumerate(order,1):
        active=active and pair.loc[idx,"mannwhitney_p"]<=0.05/(mm-rank+1)
        pair.loc[idx,"holm_significant_0p05"]=active
    z.to_csv(out/"v48l1b2_object_background_proxies_368.csv",index=False)
    summary.to_csv(out/"v48l1b2_background_group_summary.csv",index=False)
    pair.to_csv(out/"v48l1b2_background_pairwise_tests.csv",index=False)
    meta={"version":VERSION,"early_window_rest_days":[-18,-5],"pre_event_window_rest_days":[-60,-25],
          "native_bands":["c","o"],"interpretation":"fluxerr and flux MAD are local photometric-noise/background proxies, not direct host surface brightness",
          "canonical_outputs_modified":False,"next_authorized_stage":"V48L1C_ATTRITION_INTERPRETATION_AND_MANUSCRIPT_CLAIM_FREEZE"}
    (out/"v48l1b2_summary.json").write_text(json.dumps(meta,indent=2),encoding="utf-8")
    report=["V48L1B2_LOCAL_BACKGROUND_PROXY_AUDIT_COMPLETE","V48L1B2_BACKGROUND_GATE_PASS",
            "Objects: 368","Native bands: c,o","Early rest-frame window: -18 to -5 d","Pre-event rest-frame window: -60 to -25 d",
            "Direct host surface brightness measured: False","Local photometric noise/background proxies computed: True",
            "Canonical outputs modified: False","NEXT_AUTHORIZED_STAGE=V48L1C_ATTRITION_INTERPRETATION_AND_MANUSCRIPT_CLAIM_FREEZE"]
    (out/"v48l1b2_report.txt").write_text("\n".join(report)+"\n",encoding="utf-8")
    print("\n".join(report)); print("\nGROUP SUMMARY"); print(summary.to_string(index=False)); print("\nPAIRWISE"); print(pair.to_string(index=False))

if __name__=="__main__": main()
