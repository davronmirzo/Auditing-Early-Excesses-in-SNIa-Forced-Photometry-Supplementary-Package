from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import math
import os
import time
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from scipy.integrate import cumulative_trapezoid
from scipy.optimize import brentq
from scipy.stats import beta as beta_distribution


VERSION = "v48m7p2_fixed_alpha_matched_1.0.0"
EXPECTED_HOSTS = 277
EXPECTED_TRIALS = 41550
G: dict[str, Any] = {}


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def truthy(series: pd.Series) -> pd.Series:
    return series.astype(str).str.strip().str.lower().isin({"true", "1", "yes", "y", "t"})


def load_module(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot load {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def classify(points: pd.DataFrame) -> tuple[bool, int, int, float]:
    if points.empty:
        return False, 0, 0, np.nan
    block = points.groupby(["band", "night"])["residual_sigma"].max()
    n5 = int((block > 5.0).sum())
    n3 = int((block > 3.0).sum())
    return bool(n5 >= 1 or n3 >= 2), n5, n3, float(block.max())


def worker_init(root_text: str) -> None:
    root = Path(root_text)
    contract = json.loads((root / "config/v48m7p2_fixed_alpha_matched_contract.json").read_text())
    m6 = json.loads((root / "config/v48m6_end_to_end_contract.json").read_text())
    canonical = json.loads((root / "config/v48g1_injection_contract.json").read_text())
    methods = json.loads((root / "config/v48a_canonical_methods_contract.json").read_text())
    engine = load_module(root / "scripts/65_validate_v48g2_full_refit_engine.py", "v48m7p2_engine")
    fits = pd.read_csv(root / "results/v48_canonical/baseline/v48b_object_band_fits.csv")
    fits["object_id"] = fits["object_id"].astype(str)
    fits["band"] = fits["band"].astype(str).str.lower()
    fits = fits[truthy(fits["valid_fit"])].copy()
    objects = pd.read_csv(root / "results/v48_canonical/baseline/v48b_object_summary.csv")
    objects["object_id"] = objects["object_id"].astype(str)
    primary = objects[truthy(objects["fit_valid"]) & (pd.to_numeric(objects["median_chi2_dof"], errors="coerce") <= 5)]
    host_ids = set(primary["object_id"])
    if len(host_ids) != EXPECTED_HOSTS:
        raise RuntimeError(f"Expected {EXPECTED_HOSTS} primary hosts, found {len(host_ids)}")
    fits = fits[fits["object_id"].isin(host_ids)].copy()
    data = pd.read_csv(root / "data/processed/earlyrise_lightcurves.csv", low_memory=False)
    for col in ("mjd", "flux", "fluxerr", "redshift", "rest_phase"):
        data[col] = pd.to_numeric(data[col], errors="coerce")
    data["object_id"] = data["object_id"].astype(str)
    data["band"] = data["band"].astype(str).str.lower()
    lo, hi = methods["eligibility"]["phase_window_days"]
    data = data[
        data["object_id"].isin(host_ids)
        & data["band"].isin({"c", "o"})
        & data["mjd"].notna()
        & data["flux"].notna()
        & data["fluxerr"].gt(0)
        & data["rest_phase"].between(lo, hi, inclusive="both")
    ].copy()
    G.update(root=root, contract=contract, m6=m6, canonical=canonical, methods=methods,
             engine=engine, fits=fits, data=data)


def injection_parameters(oid: str, template: dict[str, Any], realization: int) -> tuple[float, float, int]:
    seed_text = f"{G['m6']['random_seed']}|{oid}|{template['template_id']}|{realization}"
    trial_seed = int(hashlib.sha256(seed_text.encode()).hexdigest()[:16], 16)
    rng = np.random.default_rng(trial_seed)
    phase_jitter = float(rng.normal(0.0, G["m6"]["injection_mode"]["phase_jitter_days"]))
    amplitude_jitter = float(max(0.0, rng.normal(1.0, G["m6"]["injection_mode"]["amplitude_jitter_fraction"])))
    return phase_jitter, amplitude_jitter, trial_seed


def injected_points(oid: str, template: dict[str, Any], realization: int,
                    omitted_night: int | None = None) -> tuple[pd.DataFrame, bool, bool, float, float, int]:
    od = G["data"][G["data"]["object_id"] == oid].copy()
    ofits = G["fits"][G["fits"]["object_id"] == oid].copy()
    z = float(od["redshift"].median())
    z = z if np.isfinite(z) else 0.0
    shared_anchor = float(ofits["t0"].median())
    phase_jitter, amplitude_jitter, trial_seed = injection_parameters(oid, template, realization)
    rows: list[dict[str, Any]] = []
    all_success = True
    for prefit in ofits.itertuples(index=False):
        full = od[od["band"] == prefit.band].sort_values("mjd").copy()
        peak_mjd = shared_anchor + (float(template["phase_peak_days"]) + phase_jitter) * (1.0 + z)
        width_obs = float(template["width_days"]) * (1.0 + z)
        scale = float(template["c_scale"] if prefit.band == "c" else template["o_scale"])
        eff = np.sqrt(full["fluxerr"].to_numpy(float) ** 2 + float(prefit.extra_scatter) ** 2)
        bump = (
            float(template["peak_sigma"]) * scale * amplitude_jitter * float(np.median(eff))
            * np.exp(-0.5 * ((full["mjd"].to_numpy(float) - peak_mjd) / width_obs) ** 2)
        )
        full["injected_flux"] = full["flux"].to_numpy(float) + bump
        train = full if omitted_night is None else full[np.floor(full["mjd"]).astype(int) != int(omitted_night)].copy()
        result = G["engine"].refit_band(
            train, train["injected_flux"].to_numpy(float), G["methods"]["baseline"],
            "fixed-to-pre-injection", pd.Series(prefit._asdict()), "frozen-pre-injection",
        )
        if not result["success"]:
            all_success = False
            continue
        phase = (train["mjd"].to_numpy(float) - float(result["t0"])) / (1.0 + z)
        for idx, row in enumerate(train.itertuples(index=False)):
            rows.append({"band": str(prefit.band), "mjd": float(row.mjd),
                         "night": int(np.floor(float(row.mjd))), "phase": float(phase[idx]),
                         "residual_sigma": float(result["residual_sigma"][idx])})
    return pd.DataFrame(rows), all_success, len(rows) > 0, phase_jitter, amplitude_jitter, trial_seed


def classify_trial(oid: str, template: dict[str, Any], realization: int) -> dict[str, Any]:
    points, success, complete, phase_jitter, amp_jitter, trial_seed = injected_points(oid, template, realization)
    q = points[points["phase"].between(-0.5, 6.0, inclusive="both")].copy() if not points.empty else points
    raw, n5, n3, maximum = classify(q)
    single = False
    two_band = False
    lono_attempted = False
    lono_valid = False
    lono_survives = False
    trigger_nights: list[int] = []
    if raw:
        single = classify(q.drop(index=q["residual_sigma"].idxmax()))[0]
        block = q.groupby(["band", "night"])["residual_sigma"].max()
        two_band = {"c", "o"}.issubset(set(block[block > 3.0].index.get_level_values("band")))
        trigger_nights = sorted(set(int(x) for x in block[block > 3.0].index.get_level_values("night")))
    if raw and single and two_band:
        lono_attempted = True
        states = []
        valids = []
        for night in trigger_nights:
            retained, valid, _, _, _, _ = injected_points(oid, template, realization, night)
            rq = retained[retained["phase"].between(-0.5, 6.0, inclusive="both")] if not retained.empty else retained
            valids.append(bool(valid))
            states.append(bool(valid and classify(rq)[0]))
        lono_valid = bool(valids and all(valids))
        lono_survives = bool(states and all(states))
    confirmed = bool(raw and single and two_band and lono_valid and lono_survives)
    return {
        "object_id": oid, "template_id": template["template_id"], "realization": realization,
        "trial_seed": trial_seed, "phase_jitter_days": phase_jitter,
        "amplitude_jitter_factor": amp_jitter, "all_band_refits_success": success,
        "all_valid_bands_present": complete, "raw": raw, "n_blocks_gt5": n5,
        "n_blocks_gt3": n3, "maximum_block_residual": maximum,
        "single_point_survives": single, "two_band_coherent": two_band,
        "n_trigger_nights": len(trigger_nights), "lono_attempted": lono_attempted,
        "lono_refits_valid": lono_valid, "lono_all_survive": lono_survives,
        "structurally_confirmed": confirmed, "version": VERSION,
    }


def run_host(oid: str) -> tuple[str, list[dict[str, Any]]]:
    rows = [classify_trial(oid, template, realization)
            for template in G["canonical"]["templates"]
            for realization in range(30)]
    return oid, rows


def valid_checkpoint(path: Path) -> bool:
    try:
        d = pd.read_csv(path)
        return len(d) == 150 and d["version"].eq(VERSION).all() and not d.duplicated(["object_id", "template_id", "realization"]).any()
    except Exception:  # noqa: BLE001
        return False


def frequentist_limit(eps: np.ndarray) -> tuple[float, str]:
    eps = np.asarray(eps, float)
    def survival(f: float) -> float:
        return float(np.prod(1.0 - f * eps))
    if survival(1.0) > 0.05:
        return 1.0, "no_root_below_one"
    return float(brentq(lambda f: survival(f) - 0.05, 0.0, 1.0)), "root"


def bayes_quantile(eps: np.ndarray, a: float, b: float, q: float = 0.95) -> float:
    if not np.any(np.asarray(eps, float) > 0):
        return float(beta_distribution.ppf(q, a, b))
    grid = np.linspace(0.0, 1.0, 200001)
    like = np.prod(1.0 - grid[:, None] * np.asarray(eps, float)[None, :], axis=1)
    prior = np.power(np.clip(grid, 1e-12, 1.0), a - 1.0) * np.power(np.clip(1.0 - grid, 1e-12, 1.0), b - 1.0)
    post = like * prior
    cdf = np.r_[0.0, cumulative_trapezoid(post, grid)]
    cdf /= cdf[-1]
    return float(np.interp(q, cdf, grid))


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=".")
    ap.add_argument("--workers", type=int, default=12)
    args = ap.parse_args()
    root = Path(args.root).resolve()
    for path in [root / "config/v48m7p2_fixed_alpha_matched_contract.json",
                 root / "config/v48m6_end_to_end_contract.json",
                 root / "config/v48g1_injection_contract.json",
                 root / "config/v48a_canonical_methods_contract.json"]:
        if not path.is_file():
            raise FileNotFoundError(path)
    objects = pd.read_csv(root / "results/v48_canonical/baseline/v48b_object_summary.csv")
    primary = objects[truthy(objects["fit_valid"]) & (pd.to_numeric(objects["median_chi2_dof"], errors="coerce") <= 5)]
    hosts = sorted(primary["object_id"].astype(str).tolist())
    if len(hosts) != EXPECTED_HOSTS:
        raise RuntimeError(f"Expected {EXPECTED_HOSTS} hosts, found {len(hosts)}")
    out = root / "results/v48m7p2_fixed_alpha_matched"
    checkpoint = out / "checkpoints"
    checkpoint.mkdir(parents=True, exist_ok=True)
    tasks = [oid for oid in hosts if not valid_checkpoint(checkpoint / f"{oid}.csv")]
    started = time.time()
    print(f"V48M7P2 resume: {len(hosts)-len(tasks)}/{len(hosts)} checkpoints complete", flush=True)
    with ProcessPoolExecutor(max_workers=max(1, args.workers), initializer=worker_init, initargs=(str(root),)) as pool:
        futures = {pool.submit(run_host, oid): oid for oid in tasks}
        completed = len(hosts) - len(tasks)
        for future in as_completed(futures):
            oid, rows = future.result()
            temp = checkpoint / f"{oid}.csv.tmp"
            pd.DataFrame(rows).to_csv(temp, index=False)
            os.replace(temp, checkpoint / f"{oid}.csv")
            completed += 1
            print(f"V48M7P2 progress: {completed}/{len(hosts)}", flush=True)
    trials = pd.concat([pd.read_csv(checkpoint / f"{oid}.csv") for oid in hosts], ignore_index=True)
    if len(trials) != EXPECTED_TRIALS or trials.duplicated(["object_id", "template_id", "realization"]).any():
        raise RuntimeError("Trial count/key gate failed")
    for col in ["raw", "single_point_survives", "two_band_coherent", "lono_attempted", "lono_refits_valid", "lono_all_survive", "structurally_confirmed"]:
        trials[col] = truthy(trials[col])
    trials.to_csv(out / "v48m7p2_fixed_alpha_matched_trials_41550.csv.gz", index=False, compression="gzip")
    object_rows = []
    for (oid, tid), g in trials.groupby(["object_id", "template_id"]):
        object_rows.append({"object_id": oid, "template_id": tid, "trials": len(g),
                            "raw_recovered": int(g["raw"].sum()),
                            "confirmed_recovered": int(g["structurally_confirmed"].sum()),
                            "raw_efficiency": float(g["raw"].mean()),
                            "confirmed_efficiency": float(g["structurally_confirmed"].mean())})
    object_df = pd.DataFrame(object_rows)
    object_df.to_csv(out / "v48m7p2_fixed_alpha_object_specific_efficiencies_277x5.csv", index=False)
    summary_rows = []
    for tid, g in trials.groupby("template_id"):
        e = object_df.loc[object_df["template_id"] == tid, "confirmed_efficiency"].to_numpy(float)
        f95, status = frequentist_limit(e)
        summary_rows.append({"template_id": tid, "trials": len(g), "raw": int(g["raw"].sum()),
                             "single_point": int(g["single_point_survives"].sum()),
                             "two_band": int(g["two_band_coherent"].sum()),
                             "lono_attempted": int(g["lono_attempted"].sum()),
                             "confirmed": int(g["structurally_confirmed"].sum()),
                             "mean_raw_efficiency": float(g["raw"].mean()),
                             "mean_confirmed_efficiency": float(g["structurally_confirmed"].mean()),
                             "frequentist_f95": f95, "frequentist_status": status,
                             "beta_1_1_q95": bayes_quantile(e, 1.0, 1.0),
                             "beta_half_half_q95": bayes_quantile(e, 0.5, 0.5)})
    summary_df = pd.DataFrame(summary_rows)
    summary_df.to_csv(out / "v48m7p2_fixed_alpha_primary_summary_5.csv", index=False)
    checks = {
        "hosts": len(hosts), "trials": len(trials),
        "trial_keys_unique": not trials.duplicated(["object_id", "template_id", "realization"]).any(),
        "all_base_refits_success": bool(truthy(trials["all_band_refits_success"]).all()),
        "raw": int(trials["raw"].sum()), "single_point": int(trials["single_point_survives"].sum()),
        "two_band": int(trials["two_band_coherent"].sum()), "lono_attempted": int(trials["lono_attempted"].sum()),
        "confirmed": int(trials["structurally_confirmed"].sum()),
        "elapsed_seconds": time.time() - started,
        "contract_sha256": sha256(root / "config/v48m7p2_fixed_alpha_matched_contract.json"),
        "version": VERSION,
    }
    (out / "v48m7p2_fixed_alpha_run_summary.json").write_text(json.dumps(checks, indent=2))
    print(json.dumps(checks, indent=2), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
