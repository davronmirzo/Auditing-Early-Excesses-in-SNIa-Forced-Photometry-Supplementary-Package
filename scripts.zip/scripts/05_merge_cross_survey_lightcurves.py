from __future__ import annotations

import argparse
from pathlib import Path
import sys

import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from earlyrise.io_utils import ensure_dirs, load_config, normalize_columns, project_root
from earlyrise.photometry import clean_common_lightcurve, mag_to_flux_uJy, magerr_to_fluxerr_uJy

VERSION = "hotfix_v5_object_id_alignment_2026-07-05"


def standardize_ztf_lc(path: Path) -> pd.DataFrame:
    df = normalize_columns(pd.read_csv(path))
    # Create output with the input index before assigning scalar columns.
    # This preserves object_id for every row.
    out = pd.DataFrame(index=df.index)
    out["object_id"] = str(path.stem)
    out["survey"] = "ZTF"
    mjd_col = next((c for c in ["mjd", "jd", "time"] if c in df.columns), None)
    if mjd_col is None:
        raise KeyError(f"No mjd/jd/time column in {path.name}")
    if mjd_col == "jd":
        out["mjd"] = pd.to_numeric(df[mjd_col], errors="coerce") - 2400000.5
    else:
        out["mjd"] = pd.to_numeric(df[mjd_col], errors="coerce")
    band_col = next((c for c in ["band", "filter", "passband", "fid"] if c in df.columns), None)
    out["band"] = df[band_col].astype(str) if band_col else "ztf_unknown"

    flux_col = next((c for c in ["flux", "forcediffimflux", "flux_ujy", "flux_microjy"] if c in df.columns), None)
    ferr_col = next((c for c in ["fluxerr", "forcediffimfluxunc", "fluxerr_ujy", "fluxerr_microjy", "eflux"] if c in df.columns), None)
    mag_col = next((c for c in ["mag", "magpsf", "abmag"] if c in df.columns), None)
    magerr_col = next((c for c in ["magerr", "sigmapsf", "emag"] if c in df.columns), None)
    if flux_col and ferr_col:
        out["flux"] = pd.to_numeric(df[flux_col], errors="coerce")
        out["fluxerr"] = pd.to_numeric(df[ferr_col], errors="coerce")
        out["flux_unit"] = "input"
    elif mag_col and magerr_col:
        mag = pd.to_numeric(df[mag_col], errors="coerce")
        magerr = pd.to_numeric(df[magerr_col], errors="coerce")
        out["flux"] = mag_to_flux_uJy(mag)
        out["fluxerr"] = magerr_to_fluxerr_uJy(mag, magerr)
        out["flux_unit"] = "uJy_from_abmag"
    else:
        raise KeyError(f"No usable flux/mag columns in {path.name}: {list(df.columns)}")
    out["source_file"] = path.name
    return out


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=".")
    parser.add_argument("--version", action="store_true")
    args = parser.parse_args()
    if args.version:
        print(VERSION)
        return
    root = project_root(args.root)
    cfg = load_config(root)
    ensure_dirs(root, cfg)

    rows = []
    errors = []
    ztf_lc_dir = root / cfg["paths"]["raw_ztf"] / "lightcurves"
    if ztf_lc_dir.exists():
        for path in sorted(ztf_lc_dir.glob("*.csv")):
            try:
                rows.append(standardize_ztf_lc(path))
            except Exception as exc:  # noqa: BLE001
                errors.append({"survey": "ZTF", "file": path.name, "error": str(exc)})

    atlas_path = root / cfg["paths"]["interim"] / "atlas_forcedphot_standardized.csv"
    if atlas_path.exists():
        atlas = pd.read_csv(atlas_path, dtype={"object_id": "string"})
        atlas["object_id"] = atlas["object_id"].astype(str)
        rows.append(atlas)

    if not rows:
        print("No standardized light curves found. Run ZTF fetch and/or ATLAS parse first.")
        return

    lc = pd.concat(rows, ignore_index=True)
    if "object_id" in lc.columns:
        lc["object_id"] = lc["object_id"].astype(str)
        lc = lc[~lc["object_id"].isin(["nan", "None", "<NA>"])]
    lc = clean_common_lightcurve(lc)
    out = root / cfg["paths"]["processed"] / "cross_survey_lightcurves.csv"
    lc.to_csv(out, index=False)
    print(f"Saved merged light curves: {out} rows={len(lc)}")

    if errors:
        err = root / cfg["paths"]["tables"] / "ztf_lc_parse_errors.csv"
        pd.DataFrame(errors).to_csv(err, index=False)
        print(f"Saved parse errors: {err}")


if __name__ == "__main__":
    main()
