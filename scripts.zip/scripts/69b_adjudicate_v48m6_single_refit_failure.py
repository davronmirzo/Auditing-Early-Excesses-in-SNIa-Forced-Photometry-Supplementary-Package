from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import pandas as pd


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def truthy(series: pd.Series) -> pd.Series:
    return series.astype(str).str.strip().str.lower().isin({"true", "1", "yes", "y", "t"})


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=".")
    root = Path(parser.parse_args().root).resolve()
    trials_path = root / "results/v48m6_end_to_end/production/v48m6_injection_trials_43050.csv.gz"
    production_path = root / "results/v48m6_end_to_end/production/v48m6_production_summary.json"
    adjudication_path = root / "config/v48m6_single_refit_failure_adjudication.json"
    trials = pd.read_csv(trials_path)
    production = json.loads(production_path.read_text(encoding="utf-8"))
    adjudication = json.loads(adjudication_path.read_text(encoding="utf-8"))
    if len(trials) != 43050 or production.get("production") is not True:
        raise RuntimeError("Production trial table is incomplete")
    failed = trials[~truthy(trials["all_band_refits_success"])].copy()
    target = adjudication["affected_trial"]
    if len(failed) != 1:
        raise RuntimeError(f"Expected exactly one failed trial, found {len(failed)}")
    row = failed.iloc[0]
    observed_key = (str(row.object_id), str(row.template_id), int(row.realization))
    expected_key = (target["object_id"], target["template_id"], int(target["realization"]))
    if observed_key != expected_key:
        raise RuntimeError(f"Failure key changed: {observed_key}")
    endpoint_columns = [
        "raw_primary", "structurally_confirmed",
        "window_m0p5_6p0", "window_0p0_6p0", "window_m0p5_5p0", "window_m1p0_6p0",
        "phase_offset_m0p5", "phase_offset_m0p25", "phase_offset_0p0", "phase_offset_0p25", "phase_offset_0p5",
    ]
    if any(bool(truthy(pd.Series([row[col]])).iloc[0]) for col in endpoint_columns):
        raise RuntimeError("The conservatively adjudicated failed trial has a positive endpoint flag")
    unique = not trials.duplicated(["object_id", "template_id", "realization"]).any()
    gate = bool(unique and len(trials) == 43050 and len(failed) == 1)
    summary = {
        "status": "V48M6_END_TO_END_PRODUCTION_COMPLETE_WITH_ONE_CONSERVATIVE_NONRECOVERY",
        "gate_pass": gate,
        "hosts": 287,
        "trials": 43050,
        "successful_base_refit_trials": 43049,
        "conservative_failed_refit_nonrecoveries": 1,
        "trial_keys_unique": unique,
        "raw_primary_recoveries": int(truthy(trials["raw_primary"]).sum()),
        "structural_confirmations": int(truthy(trials["structurally_confirmed"]).sum()),
        "trials_sha256": sha256(trials_path),
        "adjudication_sha256": sha256(adjudication_path),
        "direction_of_effect": "conservative_nonrecovery",
    }
    out = root / "results/v48m6_end_to_end/production/v48m6_adjudicated_production_summary.json"
    out.write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps(summary, indent=2))
    return 0 if gate else 2


if __name__ == "__main__":
    raise SystemExit(main())
