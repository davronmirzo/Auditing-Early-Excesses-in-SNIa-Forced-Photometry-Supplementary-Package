from __future__ import annotations

import argparse
import json
import re
from pathlib import Path

import pandas as pd

VERSION = "v48l1a_denominator_covariate_inventory_1.0.0"

CATEGORIES = {
    "identity": [r"object_id", r"ztf.*name", r"ztf_id", r"name"],
    "redshift": [r"(^|_)z($|_)", r"redshift", r"zhel", r"zcmb"],
    "brightness": [r"peak.*mag", r"mag.*peak", r"mwebv", r"amplitude", r"flux.*peak", r"x0"],
    "host_background": [r"host", r"background", r"surface.*brightness", r"sgscore", r"dist.*host"],
    "subtype": [r"subtype", r"classification", r"spec.*type", r"sn.*type", r"peculiar"],
    "cadence": [r"cadence", r"n_points", r"n_night", r"n_detection", r"mjd", r"phase"],
    "early_structure": [r"residual", r"positive_flag", r"negative_flag", r"crossing", r"signal", r"excess"],
}

SKIP_PARTS = {"checkpoints", "legacy", ".git", "__pycache__"}


def classify_column(col: str) -> list[str]:
    low = str(col).strip().lower()
    return [cat for cat, pats in CATEGORIES.items() if any(re.search(p, low) for p in pats)]


def find_id_column(columns: list[str]) -> str | None:
    preferred = ["object_id", "ztf_name", "published_ztf_name", "ztf_id", "name"]
    lookup = {str(c).lower(): str(c) for c in columns}
    for key in preferred:
        if key in lookup:
            return lookup[key]
    for col in columns:
        low = str(col).lower()
        if "ztf" in low and ("name" in low or "id" in low):
            return str(col)
    return None


def read_header(path: Path) -> list[str]:
    return list(pd.read_csv(path, nrows=0).columns)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--project-root", type=Path, default=Path.cwd())
    ap.add_argument("--output-dir", type=Path,
                    default=Path("results/v48_canonical/revision/v48l1a_inventory"))
    args = ap.parse_args()
    root = args.project_root.resolve()
    out = (root / args.output_dir).resolve() if not args.output_dir.is_absolute() else args.output_dir
    out.mkdir(parents=True, exist_ok=True)

    denom = root / "results/v48_canonical/audit/v48c_denominator_adjudication_368.csv"
    if not denom.exists():
        raise SystemExit(f"MISSING_CANONICAL_DENOMINATOR={denom}")
    dd = pd.read_csv(denom)
    if "object_id" not in dd.columns or len(dd) != 368 or dd["object_id"].astype(str).nunique() != 368:
        raise SystemExit("CANONICAL_368_ID_GATE_FAIL")
    ids = set(dd["object_id"].astype(str))

    rows, registry, coverage = [], [], []
    candidates = sorted(list(root.rglob("*.csv")) + list(root.rglob("*.csv.gz")))
    for path in candidates:
        rel = path.relative_to(root)
        if any(part in SKIP_PARTS for part in rel.parts):
            continue
        if "v48g2b_injection_recovery_trials" in path.name:
            continue
        try:
            cols = read_header(path)
        except Exception as exc:
            rows.append({"relative_path": str(rel), "readable": False, "id_column": "",
                         "matched_ids": 0, "columns": "", "error": type(exc).__name__})
            continue
        idcol = find_id_column(cols)
        tagged = [(c, classify_column(c)) for c in cols]
        useful = [(c, cats) for c, cats in tagged if cats]
        matched = set()
        nrows = None
        if idcol:
            try:
                series = pd.read_csv(path, usecols=[idcol])[idcol].astype(str)
                nrows = len(series)
                matched = ids.intersection(set(series))
            except Exception:
                matched = set()
        if useful or matched:
            rows.append({"relative_path": str(rel), "readable": True, "id_column": idcol or "",
                         "rows_scanned": nrows, "matched_ids": len(matched),
                         "columns": "|".join(map(str, cols)), "error": ""})
            for col, cats in useful:
                for cat in cats:
                    registry.append({"relative_path": str(rel), "id_column": idcol or "",
                                     "column": col, "category": cat, "matched_ids": len(matched)})
            for oid in matched:
                coverage.append({"object_id": oid, "relative_path": str(rel)})

    files = pd.DataFrame(rows).sort_values(["matched_ids", "relative_path"], ascending=[False, True])
    reg = pd.DataFrame(registry).sort_values(["category", "matched_ids", "relative_path", "column"],
                                                   ascending=[True, False, True, True])
    cov = pd.DataFrame(coverage).drop_duplicates()
    if cov.empty:
        per_obj = pd.DataFrame({"object_id": sorted(ids), "n_candidate_tables": 0})
    else:
        counts = cov.groupby("object_id").size().rename("n_candidate_tables")
        per_obj = pd.DataFrame({"object_id": sorted(ids)}).join(counts, on="object_id").fillna(0)
        per_obj["n_candidate_tables"] = per_obj["n_candidate_tables"].astype(int)

    files.to_csv(out / "v48l1a_candidate_table_inventory.csv", index=False)
    reg.to_csv(out / "v48l1a_covariate_column_registry.csv", index=False)
    per_obj.to_csv(out / "v48l1a_object_table_coverage_368.csv", index=False)

    cat_summary = (reg.groupby("category").agg(columns=("column", "size"),
                   files=("relative_path", "nunique"), max_id_coverage=("matched_ids", "max"))
                   .reset_index() if not reg.empty else pd.DataFrame())
    cat_summary.to_csv(out / "v48l1a_category_summary.csv", index=False)
    summary = {
        "version": VERSION,
        "project_root": str(root),
        "canonical_objects": 368,
        "candidate_tables": int(len(files)),
        "registered_columns": int(len(reg)),
        "objects_found_in_candidate_tables": int((per_obj.n_candidate_tables > 0).sum()),
        "existing_canonical_outputs_modified": False,
        "attrition_statistics_computed": False,
        "next_authorized_stage": "V48L1B_DENOMINATOR_ATTRITION_ANALYSIS",
    }
    (out / "v48l1a_inventory_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    lines = ["V48L1A_DENOMINATOR_COVARIATE_INVENTORY_PASS",
             f"Project root: {root}", "Canonical denominator IDs: 368",
             f"Candidate tables: {len(files)}", f"Registered covariate columns: {len(reg)}",
             f"Objects represented: {(per_obj.n_candidate_tables > 0).sum()}/368",
             "Existing canonical outputs modified: False", "Attrition statistics computed: False",
             "NEXT_AUTHORIZED_STAGE=V48L1B_DENOMINATOR_ATTRITION_ANALYSIS"]
    report = "\n".join(lines) + "\n"
    (out / "v48l1a_inventory_report.txt").write_text(report, encoding="utf-8")
    print(report, end="")
    if not cat_summary.empty:
        print("\nCATEGORY COVERAGE")
        print(cat_summary.to_string(index=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
