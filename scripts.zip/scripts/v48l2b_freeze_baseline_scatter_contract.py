from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd

VERSION = "v48l2b_baseline_scatter_reproducibility_contract_1.0.0"
OUT_REL = Path("results/v48_canonical/revision/v48l2b_method_contract")


def require(condition: bool, message: str) -> None:
    if not condition:
        raise RuntimeError(message)


def as_bool(s: pd.Series) -> pd.Series:
    return s.astype(str).str.strip().str.lower().isin({"true", "1", "yes"})


def unique_values(path: Path, column: str) -> list[str]:
    vals: set[str] = set()
    for chunk in pd.read_csv(path, usecols=[column], chunksize=200000):
        vals.update(chunk[column].dropna().astype(str).str.strip().unique())
    return sorted(vals)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--project-root", default=".")
    args = ap.parse_args()
    root = Path(args.project_root).resolve()
    out = root / OUT_REL
    out.mkdir(parents=True, exist_ok=True)

    contract_path = root / "config/v48a_canonical_methods_contract.json"
    require(contract_path.is_file(), f"Missing {contract_path}")
    c = json.loads(contract_path.read_text(encoding="utf-8"))

    # Exact V48A contract checks: fail closed if a canonical definition changed.
    e, b, s, f, p, r, sens = (c[k] for k in (
        "eligibility", "baseline", "empirical_scatter", "fit_validity",
        "primary_denominator", "residual_rule", "prespecified_sensitivity"))
    require(e["phase_window_days"] == [-18.0, -5.0], "Eligibility phase window changed")
    require(e["native_bands"] == ["c", "o"], "Native bands changed")
    require(e["minimum_total_native_band_detections"] == 4, "Minimum detection count changed")
    require(e["require_measurement_rows_in_each_native_band"] is True, "Both-band row requirement changed")
    require(b["model"] == "F_b(t)=A_b*max(t-t0_b,0)^alpha_b", "Model changed")
    require(b["minimum_points_per_band"] == 4, "Minimum points per fit changed")
    require(b["alpha_bounds"] == [0.2, 5.0], "Alpha bounds changed")
    require(b["robust_loss"] == "soft_l1" and b["robust_f_scale"] == 1.0, "Robust loss changed")
    require(b["maximum_function_evaluations"] == 30000, "max_nfev changed")
    require(b["multistart_t0_guesses_days"] == [-5.0, -2.0, -1.0, 0.0, 1.0], "Multistart grid changed")
    require("<= 1e-4 or 20 iterations" in s["iteration"], "Scatter convergence changed")
    require(p["primary_threshold"] == 5.0, "Primary chi-square threshold changed")
    require(r["signal_window_days"] == [-0.5, 6.0], "Signal window changed")
    require(sens["quality_thresholds"] == [3.0, 5.0, 7.0, 10.0], "Sensitivity thresholds changed")

    atlas = root / "data/interim/atlas_forcedphot_standardized.csv"
    lc = root / "data/processed/earlyrise_lightcurves.csv"
    require(atlas.is_file() and lc.is_file(), "Canonical upstream data tables missing")
    atlas_units = unique_values(atlas, "flux_unit")
    lc_units = unique_values(lc, "flux_unit")
    require(atlas_units == ["uJy"] and lc_units == ["uJy"], f"Unexpected flux units: {atlas_units}/{lc_units}")

    fits_path = root / "results/v48_canonical/baseline/v48b_object_band_fits.csv"
    obj_path = root / "results/v48_canonical/baseline/v48b_object_summary.csv"
    require(fits_path.is_file() and obj_path.is_file(), "Canonical V48B outputs missing")
    fits = pd.read_csv(fits_path)
    objs = pd.read_csv(obj_path)
    n_valid_band = int(as_bool(fits["valid_fit"]).sum())
    n_fit_valid = int(as_bool(objs["fit_valid"]).sum())
    n_primary = int((as_bool(objs["fit_valid"]) & (pd.to_numeric(objs["median_chi2_dof"], errors="coerce") <= 5.0)).sum())
    require(len(objs) == 368, f"Expected 368 eligible objects, got {len(objs)}")
    require(n_valid_band == 405, f"Expected 405 valid object-band fits, got {n_valid_band}")
    require(n_fit_valid == 303, f"Expected 303 fit-valid objects, got {n_fit_valid}")
    require(n_primary == 277, f"Expected 277 primary objects, got {n_primary}")

    frozen = {
        "version": VERSION,
        "scope": "canonical V48 baseline/scatter reproducibility contract",
        "data_convention": {
            "survey": "ATLAS forced photometry",
            "canonical_flux_unit": "uJy",
            "canonical_flux_source": "native ATLAS uJy and duJy columns",
            "magnitude_zero_point_applied_to_canonical_rows": False,
            "reason_zero_point_not_applicable": "Both canonical upstream tables contain only flux_unit=uJy; the canonical baseline consumes flux and fluxerr directly.",
            "global_raw_chi_n_cut_applied_before_canonical_fit": False,
            "raw_chi_n_le_3_role": "post-hoc diagnostic for the V48F crossing only, not a primary-sample selection cut",
            "valid_measurement": e["valid_measurement"],
            "detection_definition": e["detection_definition"],
        },
        "eligibility": e,
        "baseline_model": b,
        "empirical_scatter": s,
        "fit_validity": f,
        "primary_denominator": p,
        "residual_trigger": r,
        "prespecified_sensitivity": sens,
        "verified_counts": {
            "eligible_objects": len(objs),
            "valid_object_band_fits": n_valid_band,
            "fit_valid_objects": n_fit_valid,
            "primary_chi2_le_5_objects": n_primary,
        },
        "scientific_calculations_executed": False,
        "canonical_outputs_modified": False,
        "method_claims_frozen": True,
        "next_authorized_stage": "V48L3_PHASE_CALENDAR_SENSITIVITY_CLOSURE",
    }
    (out / "v48l2b_frozen_contract.json").write_text(json.dumps(frozen, indent=2), encoding="utf-8")

    methods = """**Canonical baseline and empirical-scatter specification.** **We analysed the ATLAS forced-photometry flux and uncertainty columns directly in microjanskys (uJy); both canonical upstream tables contain only `flux_unit=uJy`, so no magnitude zero-point conversion enters the canonical V48 analysis. We retained finite MJD, flux, and uncertainty values with strictly positive uncertainty. No global raw ATLAS chi/N cut was imposed before fitting; the chi/N <= 3 check used in V48F was a post-hoc diagnostic for one threshold crossing and was not a denominator-selection rule. Eligibility required rest-frame phase -18 to -5 d, native c and o rows, and at least four >=3-sigma native-band detections in total.**

**Each object and native band was fitted independently over the -18 to -5 d rest-frame interval with F_b(t)=A_b max(t-t0_b,0)^alpha_b and no additive constant. A fit required at least four points; its nominal degrees of freedom were n-3. We constrained A_b>=0 and 0.2<=alpha_b<=5, bounded t0_b to [-30, min(5,min(t-t_ref)+2)] d relative to the reference epoch, initialized alpha_b=2, and tried t0 offsets -5,-2,-1,0,+1 d. We used SciPy least_squares with a soft-L1 loss, f_scale=1, and at most 30000 function evaluations, retaining the converged start with the smallest objective. A band fit was valid only when optimization succeeded, all parameters were finite, A_b>0, n-3>0, and 0.21<alpha<4.99.**

**For every accepted object-band fit, we estimated one non-negative empirical-scatter term as s_emp=sqrt(max{[1.4826 MAD(r_raw)]^2-median(sigma_formal)^2,0}). Model fitting and scatter estimation were alternated until the relative scatter change was <=10^-4 or 20 iterations were reached, and standardized residuals used sigma_eff=sqrt(sigma_formal^2+s_emp^2). An object was fit-valid when at least one c or o fit was valid. The prespecified primary denominator then required the median effective-error reduced chi-square across its valid bands to be <=5, yielding 277 objects from 303 fit-valid objects (405 valid band fits among 368 eligible objects). This post-fit restriction can induce selection effects and is evaluated separately in the denominator-attrition analysis.**

**Residual triggers were evaluated from -0.5 to +6 rest-frame days relative to the fitted band-specific t0. Measurements were grouped by native band and integer-MJD night. A positive crossing required either one band-night block above +5 sigma or at least two distinct blocks above +3 sigma; the sign-reversed rule was identical at -5 and -3 sigma. In the primary injection-recovery analysis the pre-injection empirical scatter was frozen, whereas the prespecified sensitivity branch re-estimated it after injection; free-alpha and fixed-to-pre-injection-alpha refits and shared-physical-date and band-relative-date calendars were retained as separate modes.**
"""
    (out / "v48l2b_manuscript_methods_insertion_bold.txt").write_text(methods, encoding="utf-8")

    response = """**Response — baseline and scatter reproducibility.** **We have expanded the Methods section to provide the complete canonical data, fitting, and empirical-scatter contract. The revision now states the actual ATLAS flux convention (native uJy/duJy values, with no magnitude zero-point conversion in the canonical tables), the finite-value and positive-uncertainty requirements, the eligibility and detection rules, the exact band-wise power-law model, parameter bounds, multi-start initialization, robust loss, function-evaluation limit, fit-validity criteria, degrees of freedom, iterative empirical-scatter estimator and convergence rule, effective-error definition, primary reduced-chi-square criterion, and band-night residual trigger. We also clarify that raw chi/N<=3 was used only as a post-hoc diagnostic for one crossing rather than as a global pre-fit cut, and that injection trials separately preserve the frozen-scatter primary mode and re-estimated-scatter sensitivity mode. These statements were verified against the frozen V48A contract and the canonical V48B outputs; no scientific result was recomputed or altered in this documentation stage.**
"""
    (out / "v48l2b_response_letter_text_bold.txt").write_text(response, encoding="utf-8")

    allowed = """ALLOWED CLAIMS
- Canonical fluxes and uncertainties are direct ATLAS uJy/duJy values.
- No magnitude zero-point conversion enters the canonical V48 tables.
- The complete fitting and scatter definitions in v48l2b_frozen_contract.json may be reported verbatim.
- The verified flow is 368 eligible -> 405 valid band fits -> 303 fit-valid objects -> 277 primary objects.
- The primary injection branch freezes pre-injection scatter; re-estimation is a named sensitivity branch.
- The primary chi-square restriction is a post-fit selection and possible selection effects must be acknowledged.
"""
    prohibited = """PROHIBITED CLAIMS
- Do not claim that a global raw chi/N<=3 cut defined the canonical denominator.
- Do not quote an AB magnitude zero point for the canonical V48 analysis; no magnitude conversion was used for its rows.
- Do not describe the empirical-scatter estimator as a fitted intrinsic astrophysical dispersion.
- Do not describe alpha-boundary proximity as diagnostic only; the production code rejects such fits.
- Do not merge frozen-scatter and re-estimated-scatter efficiencies into one mode.
- Do not replace the canonical denominator 277 with the obsolete historical denominator 219.
- Do not claim that this documentation freeze reran or changed scientific calculations.
"""
    (out / "v48l2b_allowed_claims.txt").write_text(allowed, encoding="utf-8")
    (out / "v48l2b_prohibited_claims.txt").write_text(prohibited, encoding="utf-8")

    report = [
        "V48L2B_BASELINE_SCATTER_REPRODUCIBILITY_CONTRACT_FREEZE_PASS",
        f"Canonical flux units (standardized/processed): {atlas_units}/{lc_units}",
        "Magnitude zero-point conversion in canonical rows: False",
        "Global pre-fit raw chi/N cut: False",
        f"Eligible/valid-band/fit-valid/primary: {len(objs)}/{n_valid_band}/{n_fit_valid}/{n_primary}",
        "Scientific calculations executed: False",
        "Canonical outputs modified: False",
        "Method claims frozen: True",
        "NEXT_AUTHORIZED_STAGE=V48L3_PHASE_CALENDAR_SENSITIVITY_CLOSURE",
    ]
    (out / "v48l2b_report.txt").write_text("\n".join(report) + "\n", encoding="utf-8")
    print("\n".join(report))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
