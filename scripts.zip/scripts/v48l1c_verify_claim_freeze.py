from pathlib import Path
import json
import pandas as pd

root=Path.cwd()
b=root/'results/v48_canonical/revision/v48l1b_attrition'
b2=root/'results/v48_canonical/revision/v48l1b2_background'
freeze=root/'results/v48_canonical/revision/v48l1c_claim_freeze/v48l1c_claim_freeze.json'
for p in [b/'v48l1b_object_level_attrition_covariates_368.csv',b/'v48l1b_chi2_threshold_sensitivity.csv',b2/'v48l1b2_background_group_summary.csv',freeze]:
    if not p.exists(): raise SystemExit(f'MISSING={p}')
d=pd.read_csv(b/'v48l1b_object_level_attrition_covariates_368.csv')
counts=d.attrition_group.value_counts().to_dict()
assert counts=={'primary_chi2_le5':277,'no_valid_fit':65,'fit_valid_chi2_gt5':26},counts
t=pd.read_csv(b/'v48l1b_chi2_threshold_sensitivity.csv')
assert t.denominator_objects.tolist()==[254,277,285,287]
assert t.raw_positive_crossings.tolist()==[0,2,2,2]
assert t.raw_negative_crossings.tolist()==[2,3,7,8]
x=pd.read_csv(b2/'v48l1b2_background_group_summary.csv')
p=float(x.loc[x.metric.eq('early_median_fluxerr'),'kruskal_p_all_groups'].iloc[0])
assert abs(p-0.967243)<1e-5,p
meta=json.loads(freeze.read_text())
assert meta['historical_219_authorized_for_canonical_claims'] is False
print('V48L1C_ATTRITION_INTERPRETATION_AND_MANUSCRIPT_CLAIM_FREEZE_PASS')
print('Group counts: 65/26/277')
print('Threshold denominators: 254/277/285/287')
print('Direct host surface brightness available: False')
print('Historical 219 authorized for canonical claims: False')
print('Canonical outputs modified: False')
print('NEXT_AUTHORIZED_STAGE=V48L2_BASELINE_SCATTER_REPRODUCIBILITY_CLOSURE')
