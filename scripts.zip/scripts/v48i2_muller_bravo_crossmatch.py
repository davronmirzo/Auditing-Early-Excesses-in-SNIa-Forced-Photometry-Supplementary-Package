#!/usr/bin/env python3
import argparse
import csv
import json
import re
from collections import Counter
from pathlib import Path

def norm(v): return re.sub(r"[^a-z0-9]", "", str(v).lower())
def truth(v): return str(v).strip().lower() in {"true","1","yes","y","t"}

def load(path):
    if not path.exists(): raise FileNotFoundError(f"Required input missing: {path}")
    with path.open("r", encoding="utf-8-sig", newline="") as f: return list(csv.DictReader(f))

def id_column(rows, path):
    if not rows: return None
    names = {norm(c): c for c in rows[0]}
    for key in ("objectid","ztfid","ztfname","name","transientid","surveyid"):
        if key in names: return names[key]
    raise RuntimeError(f"No recognized object identifier column: {path}")

def members(path):
    rows=load(path); col=id_column(rows,path)
    return {norm(r.get(col,"")) for r in rows if r.get(col,"")}

def write_csv(path, rows, fields):
    with path.open("w", encoding="utf-8", newline="") as f:
        w=csv.DictWriter(f, fieldnames=fields, extrasaction="ignore"); w.writeheader(); w.writerows(rows)

def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--project-root",required=True); a=ap.parse_args()
    root=Path(a.project_root).resolve()
    out=root/"results"/"v48_canonical"/"external_crossmatch"/"muller_bravo"
    cat=load(out/"v48i1_catalogue_frozen.csv")
    paths={
      "request":root/"data"/"raw"/"atlas"/"request_batches"/"atlas_forcedphot_request_all.csv",
      "raw":root/"data"/"interim"/"atlas_forcedphot_standardized.csv",
      "assoc":root/"results"/"tables"/"eeri_secure_dr2_match_920_from_stage4.csv",
      "coverage":root/"results"/"tables"/"eeri_early_window_761_from_stage4.csv",
      "native":root/"results"/"v48_canonical"/"freeze"/"v48a_eligible_native_co_368.csv",
      "adjud":root/"results"/"v48_canonical"/"audit"/"v48c_denominator_adjudication_368.csv",
      "forensic":root/"results"/"v48_canonical"/"forensics"/"v48e_candidate_adjudication_5.csv",
      "final":root/"results"/"v48_canonical"/"null_calibration"/"v48f_candidate_final_adjudication.csv",
    }
    sets={k:members(v) for k,v in paths.items() if k not in {"adjud","forensic","final"}}
    adjud_rows=load(paths["adjud"]); acol=id_column(adjud_rows,paths["adjud"]); adjud={norm(r[acol]):r for r in adjud_rows}
    forensic_rows=load(paths["forensic"]); fcol=id_column(forensic_rows,paths["forensic"]); forensic={norm(r[fcol]):r for r in forensic_rows}
    final_rows=load(paths["final"]); qcol=id_column(final_rows,paths["final"]); final={norm(r[qcol]):r for r in final_rows}

    rows=[]
    for c in cat:
        key=norm(c["published_ztf_name"]); ad=adjud.get(key,{})
        request=key in sets["request"]; raw=key in sets["raw"]; assoc=key in sets["assoc"]
        coverage=key in sets["coverage"]; native=key in sets["native"]
        fit=truth(ad.get("fit_valid")); primary=truth(ad.get("primary_chi2_le_5"))
        pos=truth(ad.get("positive_threshold_crossing")); neg=truth(ad.get("negative_threshold_crossing"))
        if not request: first="atlas_request"; reason="not_in_atlas_request_manifest"
        elif not raw: first="usable_raw_atlas_photometry"; reason="no_standardized_atlas_photometry"
        elif not assoc: first="secure_ztf_association"; reason="no_secure_ztf_association"
        elif not coverage: first="early_window_coverage"; reason="insufficient_early_window_coverage"
        elif not native: first="native_band_gate"; reason="failed_strict_native_band_gate"
        elif not fit: first="valid_baseline_fit"; reason="no_valid_canonical_baseline_fit"
        elif not primary: first="canonical_277_denominator"; reason="failed_primary_chi2_le_5"
        elif not (pos or neg): first="none"; reason="passed_denominator_no_raw_eeri_crossing"
        else: first="none"; reason="raw_crossing_requires_forensic_adjudication"
        fr=forensic.get(key,{}); qr=final.get(key,{})
        confirmed=truth(fr.get("astrophysical_detection")) or truth(qr.get("astrophysical_detection"))
        robustness=fr.get("decision") or qr.get("final_decision") or ("not_applicable_no_crossing" if not(pos or neg) else "unresolved")
        rows.append({
          **c,"atlas_request_present":request,"raw_atlas_data_present":raw,"secure_ztf_association":assoc,
          "early_window_coverage":coverage,"native_band_gate":native,"valid_baseline_fit":fit,
          "primary_277_member":primary,"median_chi2_dof":ad.get("median_chi2_dof",""),
          "n_valid_band_fits":ad.get("n_valid_band_fits",""),"n_signal_points":ad.get("n_signal_points",""),
          "n_signal_bands":ad.get("n_signal_bands",""),"positive_threshold_crossing":pos,
          "negative_threshold_crossing":neg,"raw_crossing":pos or neg,"robustness_class":robustness,
          "confirmed_positive":confirmed,"first_failure_stage":first,"all_attrition_reasons":reason,
        })

    expected={"published":17,"request":13,"raw":9,"assoc":9,"coverage":9,"native":4,"fit":4,"primary":4,"crossing":0,"confirmed":0}
    observed={"published":len(rows)}
    for k,col in [("request","atlas_request_present"),("raw","raw_atlas_data_present"),("assoc","secure_ztf_association"),("coverage","early_window_coverage"),("native","native_band_gate"),("fit","valid_baseline_fit"),("primary","primary_277_member"),("crossing","raw_crossing"),("confirmed","confirmed_positive")]:
        observed[k]=sum(bool(r[col]) for r in rows)
    if observed != expected: raise AssertionError(f"V48I2 gate mismatch. Expected {expected}; observed {observed}")

    fields=list(rows[0].keys()); write_csv(out/"v48i2_muller_bravo_object_level_crossmatch_17.csv",rows,fields)
    attr=Counter(r["all_attrition_reasons"] for r in rows)
    attr_rows=[{"attrition_reason":k,"objects":v} for k,v in sorted(attr.items())]
    write_csv(out/"v48i2_muller_bravo_attrition_summary.csv",attr_rows,["attrition_reason","objects"])
    gate_rows=[{"stage":k,"objects":observed[k]} for k in expected]
    write_csv(out/"v48i2_muller_bravo_ladder_counts.csv",gate_rows,["stage","objects"])
    audit={"status":"PASS","project_root":str(root),"expected":expected,"observed":observed,
           "obsolete_219_used":False,"canonical_primary_denominator_size":277,
           "physical_channel_occurrence_interpretation_authorized":False,
           "source_catalogue":"Muller-Bravo et al. 2026, arXiv:2607.22050v1, Table 5"}
    (out/"v48i2_crossmatch_audit.json").write_text(json.dumps(audit,indent=2)+"\n",encoding="utf-8")
    lines=["V48I2_MULLER_BRAVO_CANONICAL_277_OBJECT_LEVEL_CROSSMATCH_COMPLETE","V48I2_CROSSMATCH_GATE_PASS",
           "Published/ATLAS-request/usable-ATLAS: 17/13/9","Secure-association/early-coverage/native-gate: 9/9/4",
           "Valid-fit/canonical-277/raw-crossing/confirmed: 4/4/0/0",
           "Obsolete 219 denominator reused: False","Physical-channel occurrence interpretation authorized: False",
           "NEXT_AUTHORIZED_STAGE=V48I3_MANUSCRIPT_CROSSMATCH_INTEGRATION","","ATTRITION"]
    lines += [f"{r['attrition_reason']}: {r['objects']}" for r in attr_rows]
    (out/"v48i2_crossmatch_report.txt").write_text("\n".join(lines)+"\n",encoding="utf-8")
    print("\n".join(lines))

if __name__=="__main__": main()
