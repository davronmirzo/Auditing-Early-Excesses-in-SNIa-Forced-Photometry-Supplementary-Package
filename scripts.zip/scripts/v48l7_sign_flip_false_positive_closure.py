from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd

VERSION = "v48l7_sign_flip_false_positive_interpretation_closure_1.1.0"
OUT_REL = Path("results/v48_canonical/revision/v48l7_sign_flip")


def require(ok: bool, message: str) -> None:
    if not ok:
        raise RuntimeError(message)


def b(s: pd.Series) -> pd.Series:
    return s.astype(str).str.strip().str.lower().isin({"true", "1", "yes"})


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--project-root", default=".")
    args = ap.parse_args()
    root = Path(args.project_root).resolve()
    out = root / OUT_REL
    out.mkdir(parents=True, exist_ok=True)

    null = root / "results/v48_canonical/null_calibration"
    forensic = root / "results/v48_canonical/forensics"
    pairs_path = null / "v48f_object_level_sign_flip_pairs_277.csv"
    dist_path = null / "v48f_exact_sign_flip_positive_count_distribution.csv"
    v48f_path = null / "v48f_photometric_null_summary.json"
    raw_path = null / "v48f_ztf19acoxgqw_raw_quality_audit.csv"
    final_path = null / "v48f_candidate_final_adjudication.csv"
    v48e_path = forensic / "v48e_candidate_adjudication_5.csv"
    for p in (pairs_path, dist_path, v48f_path, raw_path, final_path, v48e_path):
        require(p.is_file(), f"Missing canonical V48E/V48F input: {p}")

    pairs = pd.read_csv(pairs_path)
    dist = pd.read_csv(dist_path)
    summary = json.loads(v48f_path.read_text(encoding="utf-8"))
    raw = pd.read_csv(raw_path)
    final = pd.read_csv(final_path)
    v48e = pd.read_csv(v48e_path)
    require(len(pairs) == 277 and pairs.object_id.nunique() == 277, "Expected 277 unique sign-flip pairs")
    obs = int(b(pairs.observed_positive).sum())
    rev = int(b(pairs.positive_after_full_sign_reverse).sum())
    require(obs == 2 and rev == 3, f"Expected observed/reversed counts 2/3, got {obs}/{rev}")
    require(int((b(pairs.observed_positive) & b(pairs.positive_after_full_sign_reverse)).sum()) == 0, "Observed and reversed crossings overlap")
    require(len(dist) == 6 and list(pd.to_numeric(dist.positive_count).astype(int)) == list(range(6)), "Exact distribution support changed")
    expected_prob = np.array([math.comb(5, k) / 32.0 for k in range(6)])
    require(np.allclose(pd.to_numeric(dist.exact_probability), expected_prob), "Exact distribution is not Binomial(5,0.5)")
    p_ge_2 = float(dist.loc[pd.to_numeric(dist.positive_count) >= 2, "exact_probability"].sum())
    require(np.isclose(p_ge_2, 0.8125), f"Expected P(N>=2)=0.8125, got {p_ge_2}")
    p_eq_2 = float(dist.loc[pd.to_numeric(dist.positive_count) == 2, "exact_probability"].sum())
    p_two_sided = float(dist.loc[pd.to_numeric(dist.exact_probability) <= p_eq_2 + 1e-15, "exact_probability"].sum())
    require(np.isclose(p_eq_2, 0.3125), f"Expected P(N=2)=0.3125, got {p_eq_2}")
    require(np.isclose(p_two_sided, 1.0), f"Expected two-sided exact p=1, got {p_two_sided}")
    require(int(summary["primary_objects"]) == 277 and int(summary["observed_positive_crossings"]) == 2 and int(summary["sign_reversed_positive_crossings"]) == 3, "V48F summary counts changed")
    require(int(summary["confirmed_astrophysical_positives"]) == 0, "Confirmed-positive count changed")

    pos = v48e[v48e.crossing_label == "positive"]
    neg = v48e[v48e.crossing_label == "negative"]
    require(len(pos) == 2 and len(neg) == 3, "V48E positive/negative forensic roster changed")
    require((~b(v48e.astrophysical_detection)).all(), "V48E contains an astrophysical detection")
    require((final.object_id.astype(str) == "ZTF19acoxgqw").all() and len(final) == 1, "V48F final target changed")
    require((~b(final.astrophysical_detection)).all(), "V48F final target is unexpectedly a detection")
    support = raw[b(raw.supports_positive_rule)]
    require(len(support) == 3, "Expected three positive-support raw points")
    require(int(b(support.poor_psf_fit_chi_n_gt_3).sum()) == 3, "Not all support points have chi/N>3")
    chi = sorted(round(float(x), 2) for x in pd.to_numeric(support.raw_chi_n))
    require(chi == [4.91, 5.39, 6.72], f"Raw chi/N support changed: {chi}")

    crossing_table = v48e[["object_id", "crossing_label", "crossing_survives_single_extreme_deletion",
                            "survives_all_leave_trigger_night_refits", "decision", "astrophysical_detection"]].copy()
    crossing_table.to_csv(out / "v48l7_crossing_forensic_disposition_5.csv", index=False)

    closure = {
        "version": VERSION,
        "primary_objects": 277,
        "raw_observed_positive_crossings": obs,
        "raw_sign_reversed_positive_crossings": rev,
        "total_threshold_crossing_objects_conditioned_on": obs + rev,
        "conditional_null": "five crossing signs are exchangeable, each positive with probability 0.5",
        "exact_distribution": "Binomial(n=5,p=0.5)",
        "archived_upper_tail_p_npositive_ge_2": p_ge_2,
        "exact_p_npositive_eq_2": p_eq_2,
        "two_sided_exact_binomial_p": p_two_sided,
        "interpretation_of_p": "The observed two-versus-three split is fully compatible with the conditional sign-exchangeable diagnostic.",
        "not_an_interpretation_of_p": [
            "not the survey false-positive rate", "not the probability that the null hypothesis is true",
            "not proof of residual symmetry", "not the probability that a candidate is astrophysical or artifactual"],
        "positive_forensic_disposition": {
            "ZTF18abebzog": "downgraded as a fragile positive crossing",
            "ZTF19acoxgqw": "survived V48E structural checks but downgraded in V48F because all three support points have raw chi/N>3",
        },
        "negative_crossings_role": "sign-reversed controls only; not negative astrophysical events",
        "ztf19acoxgqw_support_chi_n": chi,
        "confirmed_astrophysical_positives": 0,
        "global_chi_n_cut_used": False,
        "raw_chi_n_check_role": "targeted post-hoc diagnostic for the retained forensic candidate",
        "new_fit_or_candidate_classification_executed": False,
        "canonical_outputs_modified": False,
        "claims_frozen": True,
        "next_authorized_stage": "V48L8_REPRODUCIBILITY_PACKAGE_AND_REVISION_MATRIX_CLOSURE",
    }
    (out / "v48l7_closure_summary.json").write_text(json.dumps(closure, indent=2), encoding="utf-8")

    manuscript = """**Sign-reversal null diagnostic and false-positive interpretation.** **The primary 277-object sample contains two raw positive-oriented crossings and three crossings after full residual-sign reversal. Conditioning on these five threshold-crossing objects and assigning exchangeable signs under the diagnostic null gives N+~Binomial(5,0.5), for which P(N+=2)=0.3125 and the two-sided exact-binomial p-value is 1.0. Thus, the two-versus-three orientation split is fully compatible with the conditional diagnostic. This calculation is not a survey false-positive rate, does not give the probability that the null hypothesis is true, and does not prove exact residual symmetry.**

**The five crossings were therefore treated as a forensic roster rather than detections. ZTF18abebzog failed the single-extreme-point and leave-trigger-night tests. ZTF19acoxgqw survived those structural checks, but all three points supporting its positive rule have raw ATLAS chi/N values above 3 (4.91, 5.39, and 6.72), and the positive flag disappears in the targeted chi/N<=3 diagnostic; it was consequently downgraded as a poor-PSF-fit artifact. This chi/N check is a post-hoc diagnostic for that retained candidate, not a global denominator cut. The three negative-oriented crossings are retained only as sign-reversed controls and are not interpreted as negative astrophysical transients. The final confirmed positive count is zero.**
"""
    (out / "v48l7_manuscript_insertion_bold.txt").write_text(manuscript, encoding="utf-8")
    response = """**Response — sign-flip interpretation.** **We have clarified both the conditioning and the scope of the sign-reversal calculation. The exact distribution is Binomial(5,0.5) conditional on the five objects that cross in either orientation, yielding P(N+=2)=0.3125 and a two-sided exact-binomial p-value of 1.0 for the observed two-versus-three split. We do not describe these quantities as a false-positive rate or as proof of residual symmetry. They are used only as a conditional sign-balance diagnostic that motivates object-level forensics. Those checks downgrade one positive crossing as structurally fragile and the other because all three support points have poor raw ATLAS chi/N; the three negative crossings remain controls only. The resulting confirmed astrophysical count is zero.**
"""
    (out / "v48l7_response_letter_text_bold.txt").write_text(response, encoding="utf-8")
    (out / "v48l7_allowed_claims.txt").write_text(
        "ALLOWED CLAIMS\n- State the observed/reversed raw counts as 2/3 in 277 primary objects.\n- State the conditional Binomial(5,0.5) model, P(Npositive=2)=0.3125, and two-sided exact p=1.0.\n- Say that the two-versus-three split is fully compatible with this conditional diagnostic.\n- Report the complete forensic disposition and zero confirmed detections.\n- Describe negative crossings as sign-reversed controls.\n", encoding="utf-8")
    (out / "v48l7_prohibited_claims.txt").write_text(
        "PROHIBITED CLAIMS\n- Do not present the archived P(Npositive>=2)=0.8125 upper tail as the sign-balance p-value.\n- Do not call the exact-binomial summaries the survey false-positive rate.\n- Do not call them the probability that the null is true.\n- Do not claim the sign-flip proves exact residual symmetry.\n- Do not assign candidate-level artifact probabilities from this diagnostic.\n- Do not call negative crossings astrophysical negative events.\n- Do not present chi/N<=3 as a global pre-fit selection cut.\n", encoding="utf-8")

    report = [
        "V48L7_SIGN_FLIP_AND_FALSE_POSITIVE_INTERPRETATION_CLOSURE_PASS",
        f"Primary objects / observed positive / sign-reversed positive: 277/{obs}/{rev}",
        "Conditional sign-null: Binomial(n=5,p=0.5)",
        f"Exact P(Npositive=2): {p_eq_2:.6f}",
        f"Two-sided exact-binomial p: {p_two_sided:.6f}",
        "Survey false-positive rate measured by sign flip: False",
        "Exact residual symmetry proved: False",
        f"ZTF19acoxgqw positive-support chi/N: {'|'.join(f'{x:.2f}' for x in chi)}",
        "Global chi/N cut used: False",
        "Confirmed astrophysical positives: 0",
        "New fit or candidate classification executed: False",
        "Canonical outputs modified: False",
        "Claims frozen: True",
        "NEXT_AUTHORIZED_STAGE=V48L8_REPRODUCIBILITY_PACKAGE_AND_REVISION_MATRIX_CLOSURE",
    ]
    (out / "v48l7_report.txt").write_text("\n".join(report) + "\n", encoding="utf-8")
    print("\n".join(report))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
