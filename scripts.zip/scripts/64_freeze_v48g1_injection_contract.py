from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import pandas as pd


STATUS = "V48G1_CANONICAL_INJECTION_CONTRACT_FROZEN"


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def main() -> int:
    ap = argparse.ArgumentParser(); ap.add_argument("--root", default=".")
    root = Path(ap.parse_args().root).resolve()
    contract_path = root / "config" / "v48g1_injection_contract.json"
    objects_path = root / "results" / "v48_canonical" / "baseline" / "v48b_object_summary.csv"
    v48f_path = root / "results" / "v48_canonical" / "null_calibration" / "v48f_photometric_null_summary.json"
    for path in (contract_path, objects_path, v48f_path):
        if not path.is_file(): raise FileNotFoundError(path)
    contract = json.loads(contract_path.read_text(encoding="utf-8"))
    v48f = json.loads(v48f_path.read_text(encoding="utf-8"))
    if v48f.get("status") != "V48F_PHOTOMETRIC_VETTING_AND_NULL_CALIBRATION_COMPLETE":
        raise RuntimeError("V48F gate is not closed")
    if int(v48f.get("confirmed_astrophysical_positives", -1)) != 0:
        raise RuntimeError("V48G1 requires zero confirmed astrophysical positives")
    objects = pd.read_csv(objects_path)
    primary = objects[objects["primary_chi2_le_5"].astype(str).str.lower().isin({"true", "1"})].copy()
    primary_ids = set(primary["object_id"].astype(str))
    excluded = set(contract["injection_hosts"]["excluded_object_ids"])
    if len(primary_ids) != 277 or not excluded.issubset(primary_ids):
        raise RuntimeError("Frozen 277-object denominator or five-object exclusion set is inconsistent")
    host_ids = sorted(primary_ids - excluded)
    if len(host_ids) != 272: raise RuntimeError("Injection host count is not 272")
    templates = contract["templates"]
    if len(templates) != 5 or len({x["template_id"] for x in templates}) != 5:
        raise RuntimeError("Template grid is not five unique proxies")
    modes = contract["mode_grid"]
    n_modes = len(modes["alpha_refit_modes"]) * len(modes["calendar_modes"])
    n_real = int(contract["realizations_per_host_template_mode"])
    expected = len(host_ids) * len(templates) * n_real * n_modes
    if expected != 163200 or expected != int(modes["expected_primary_and_sensitivity_trials"]):
        raise RuntimeError("Full frozen-scatter trial count is not 163200")
    seed = str(contract["random_seed"])
    ranked = sorted(host_ids, key=lambda oid: hashlib.sha256(f"{seed}|{oid}".encode()).hexdigest())
    reestimated = ranked[:int(contract["scatter_policy"]["reestimated_subset_hosts"])]
    reestimated_trials = len(reestimated) * len(templates) * n_real * n_modes
    if reestimated_trials != 30000:
        raise RuntimeError("Re-estimated-scatter sensitivity trial count is not 30000")
    out = root / "results" / "v48_canonical" / "injection" / "freeze"
    out.mkdir(parents=True, exist_ok=True)
    pd.DataFrame({"object_id": host_ids, "injection_host": True}).to_csv(out / "v48g1_injection_hosts_272.csv", index=False)
    pd.DataFrame({"object_id": reestimated, "reestimated_scatter_subset": True}).to_csv(out / "v48g1_reestimated_scatter_hosts_50.csv", index=False)
    pd.DataFrame(templates).to_csv(out / "v48g1_proxy_templates_5.csv", index=False)
    freeze = {
        "status": STATUS, "version": contract["version"],
        "contract_sha256": sha256(contract_path), "object_summary_sha256": sha256(objects_path),
        "v48f_summary_sha256": sha256(v48f_path), "population_denominator": 277,
        "injection_hosts": 272, "excluded_crossing_objects": 5, "templates": 5,
        "realizations_per_host_template_mode": n_real, "frozen_scatter_modes": n_modes,
        "full_frozen_scatter_trials": expected, "reestimated_scatter_subset_hosts": 50,
        "reestimated_scatter_trials": reestimated_trials, "injection_executed": False,
        "population_limits_computed": False, "archived_outputs_overwritten": False,
        "next_authorized_stage": "V48G2_CANONICAL_INJECTION_RECOVERY_AND_LIMITS"
    }
    (out / "v48g1_injection_contract_freeze.json").write_text(json.dumps(freeze, indent=2), encoding="utf-8")
    lines = [
        STATUS, "V48G1_PROSPECTIVE_FREEZE_GATE_PASS",
        "Population denominator / injection hosts: 277/272", "Excluded crossing objects: 5",
        "Proxy templates: 5", "Realizations per host/template/mode: 30",
        "Alpha x calendar modes: 2 x 2 = 4",
        "Primary and frozen-scatter sensitivity trials: 163200",
        "Re-estimated-scatter subset hosts/trials: 50/30000",
        "Confirmed astrophysical positives: 0", "Injection executed: False",
        "Population limits computed: False", "Archived 219/v44 outputs overwritten: False",
        "NEXT_AUTHORIZED_STAGE=V48G2_CANONICAL_INJECTION_RECOVERY_AND_LIMITS",
    ]
    (out / "v48g1_injection_contract_claim_box.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print("\n".join(lines)); return 0


if __name__ == "__main__": raise SystemExit(main())
