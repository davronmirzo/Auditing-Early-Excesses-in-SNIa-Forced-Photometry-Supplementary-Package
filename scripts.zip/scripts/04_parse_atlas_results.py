from __future__ import annotations

import argparse
from io import StringIO
from pathlib import Path
import re
import sys
from typing import Optional

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from earlyrise.io_utils import ensure_dirs, load_config, normalize_columns, project_root
from earlyrise.photometry import mag_to_flux_uJy, magerr_to_fluxerr_uJy

VERSION = "hotfix_v5_object_id_alignment_2026-07-05"


def infer_object_id_from_name(path: Path) -> str | None:
    stem = path.stem
    for pat in [r"(ZTF\d+[a-z]+)", r"(SN\d+[A-Za-z]+)", r"(AT\d+[A-Za-z]+)"]:
        m = re.search(pat, stem)
        if m:
            return m.group(1)
    return None


def collect_result_files(result_dir: Path, recursive: bool = True) -> list[Path]:
    if not result_dir.exists():
        return []
    it = result_dir.rglob("*") if recursive else result_dir.glob("*")
    allowed_suffixes = {".txt", ".csv", ".dat", ".out", ""}
    files: list[Path] = []
    for p in it:
        if not p.is_file():
            continue
        if p.name.startswith("."):
            continue
        if p.suffix.lower() in allowed_suffixes:
            files.append(p)
    return sorted(files)


def load_request_table(root: Path, cfg: dict) -> pd.DataFrame:
    req_dir = root / cfg["paths"]["raw_atlas"] / "request_batches"
    candidates = [req_dir / "atlas_forcedphot_request_all.csv"] + sorted(req_dir.glob("atlas_forcedphot_request_batch_*.csv"))
    rows = []
    for p in candidates:
        if not p.exists():
            continue
        try:
            df = pd.read_csv(p)
        except Exception:
            continue
        df = normalize_columns(df)
        needed = {"object_id", "ra", "dec"}
        if needed.issubset(df.columns):
            rows.append(df[[c for c in ["object_id", "ra", "dec", "redshift", "peak_mjd", "mjd_min", "mjd_max"] if c in df.columns]].copy())
    if not rows:
        return pd.DataFrame()
    out = pd.concat(rows, ignore_index=True).drop_duplicates("object_id")
    out["ra"] = pd.to_numeric(out["ra"], errors="coerce")
    out["dec"] = pd.to_numeric(out["dec"], errors="coerce")
    return out.dropna(subset=["ra", "dec"])


def angular_sep_arcsec(ra1: float, dec1: float, ra2: np.ndarray, dec2: np.ndarray) -> np.ndarray:
    # Small-angle separation, sufficient for matching forced-photometry coordinates.
    dra = (ra2 - ra1) * np.cos(np.deg2rad(dec1))
    ddec = dec2 - dec1
    return np.sqrt(dra * dra + ddec * ddec) * 3600.0


def infer_ra_dec_from_table(df: pd.DataFrame) -> tuple[float | None, float | None]:
    if df.empty:
        return None, None
    cands_ra = ["ra", "radeg", "alpha"]
    cands_dec = ["dec", "decdeg", "delta"]
    ra_col = next((c for c in cands_ra if c in df.columns), None)
    dec_col = next((c for c in cands_dec if c in df.columns), None)
    if not ra_col or not dec_col:
        return None, None
    ra = pd.to_numeric(df[ra_col], errors="coerce").dropna()
    dec = pd.to_numeric(df[dec_col], errors="coerce").dropna()
    if len(ra) == 0 or len(dec) == 0:
        return None, None
    return float(ra.median()), float(dec.median())


def match_object_id(path: Path, df: pd.DataFrame, request_table: pd.DataFrame, max_sep_arcsec: float) -> tuple[str, float | None, float | None, float | None, str]:
    name_id = infer_object_id_from_name(path)
    if name_id:
        return name_id, None, None, None, "filename"
    ra, dec = infer_ra_dec_from_table(df)
    if ra is not None and dec is not None and not request_table.empty:
        seps = angular_sep_arcsec(ra, dec, request_table["ra"].to_numpy(float), request_table["dec"].to_numpy(float))
        idx = int(np.nanargmin(seps))
        sep = float(seps[idx])
        if np.isfinite(sep) and sep <= max_sep_arcsec:
            return str(request_table.iloc[idx]["object_id"]), ra, dec, sep, "radec_request_table"
    return path.stem, ra, dec, None, "fallback_filename"


def parse_header_line(lines: list[str]) -> tuple[list[str] | None, int | None]:
    # ATLAS forced-photometry files often have a commented header, e.g.
    # ###MJD m dm uJy duJy F err chi/N RA Dec ...
    best_cols: list[str] | None = None
    best_idx: int | None = None
    for i, line in enumerate(lines):
        stripped = line.strip()
        if not stripped:
            continue
        cleaned = re.sub(r"^#+", "", stripped).strip()
        tokens = cleaned.split()
        low = [t.lower() for t in tokens]
        if "mjd" in low and ("ujy" in low or "m" in low or "mag" in low):
            best_cols = tokens
            best_idx = i
    return best_cols, best_idx


def is_data_line(line: str) -> bool:
    s = line.strip()
    if not s or s.startswith("#"):
        return False
    first = s.split()[0]
    try:
        float(first)
        return True
    except Exception:
        return False


def read_atlas_table(path: Path) -> pd.DataFrame:
    text = path.read_text(encoding="utf-8", errors="replace")
    lines = text.splitlines()
    cols, header_idx = parse_header_line(lines)
    data_lines = [ln for ln in lines[(header_idx + 1 if header_idx is not None else 0):] if is_data_line(ln)]
    if cols and data_lines:
        # Keep only data rows with the same number of tokens or more; extra tokens are ignored by pandas if names are fixed with usecols.
        table_text = "\n".join(data_lines)
        df = pd.read_csv(StringIO(table_text), sep=r"\s+", header=None, names=cols, engine="python")
    else:
        # Fallback for already-tabular files.
        try:
            df = pd.read_csv(path, comment="#", sep=r"\s+", engine="python")
        except Exception:
            df = pd.read_csv(path, comment="#")
    if df.empty:
        return df
    df = normalize_columns(df)
    df["source_file"] = path.name
    df["source_relpath"] = str(path)
    return df


def standardize_atlas(df: pd.DataFrame, object_id: str, source_path: Path, match_ra: float | None, match_dec: float | None, match_sep: float | None, match_method: str) -> pd.DataFrame:
    if df.empty:
        return df
    # Important: create the output with the input index before assigning scalar columns.
    # Otherwise pandas expands later Series columns but leaves scalar columns as NaN.
    out = pd.DataFrame(index=df.index)
    out["object_id"] = str(object_id)
    out["survey"] = "ATLAS"
    mjd_col = next((c for c in ["mjd", "mjd_obs", "midmjd"] if c in df.columns), None)
    band_col = next((c for c in ["f", "filter", "band", "passband"] if c in df.columns), None)
    mag_col = next((c for c in ["m", "mag", "abmag"] if c in df.columns), None)
    dmag_col = next((c for c in ["dm", "dmag", "magerr", "emag"] if c in df.columns), None)
    flux_col = next((c for c in ["ujy", "flux", "flux_ujy", "dujy", "fnu"] if c in df.columns), None)
    dflux_col = next((c for c in ["dujy", "fluxerr", "eflux", "dfnu", "fluxerr_ujy"] if c in df.columns), None)

    if mjd_col is None:
        raise KeyError(f"No MJD column found in ATLAS file columns={list(df.columns)}")
    out["mjd"] = pd.to_numeric(df[mjd_col], errors="coerce")
    out["band"] = df[band_col].astype(str) if band_col else "atlas_unknown"

    if flux_col and dflux_col and flux_col != "dujy":
        out["flux"] = pd.to_numeric(df[flux_col], errors="coerce")
        out["fluxerr"] = pd.to_numeric(df[dflux_col], errors="coerce")
        out["flux_unit"] = "uJy"
    elif mag_col and dmag_col:
        mag = pd.to_numeric(df[mag_col], errors="coerce")
        dmag = pd.to_numeric(df[dmag_col], errors="coerce")
        out["flux"] = mag_to_flux_uJy(mag)
        out["fluxerr"] = magerr_to_fluxerr_uJy(mag, dmag)
        out["flux_unit"] = "uJy_from_abmag"
    else:
        raise KeyError(f"No usable flux/mag columns found in ATLAS columns={list(df.columns)}")
    out["source_file"] = source_path.name
    out["source_relpath"] = str(source_path)
    out["match_ra"] = match_ra
    out["match_dec"] = match_dec
    out["match_sep_arcsec"] = match_sep
    out["object_id_match_method"] = match_method
    return out


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=".")
    parser.add_argument("--recursive", action="store_true", default=True)
    parser.add_argument("--max-match-sep-arcsec", type=float, default=3.0)
    parser.add_argument("--version", action="store_true")
    args = parser.parse_args()
    if args.version:
        print(VERSION)
        return
    root = project_root(args.root)
    cfg = load_config(root)
    ensure_dirs(root, cfg)

    result_dir = root / cfg["paths"]["atlas_results"]
    result_dir.mkdir(parents=True, exist_ok=True)
    files = collect_result_files(result_dir, recursive=args.recursive)
    if not files:
        print(f"No ATLAS result files found in {result_dir}. Put returned ATLAS files there first.")
        return

    request_table = load_request_table(root, cfg)
    rows = []
    errors = []
    manifest = []
    for path in files:
        try:
            raw = read_atlas_table(path)
            object_id, ra, dec, sep, method = match_object_id(path, raw, request_table, args.max_match_sep_arcsec)
            std = standardize_atlas(raw, object_id, path, ra, dec, sep, method)
            if not std.empty:
                rows.append(std)
            manifest.append({
                "file": path.name,
                "relpath": str(path.relative_to(result_dir)),
                "object_id": object_id,
                "n_rows": len(std),
                "match_method": method,
                "match_ra": ra,
                "match_dec": dec,
                "match_sep_arcsec": sep,
            })
        except Exception as exc:  # noqa: BLE001
            errors.append({"file": str(path), "error": str(exc)})
    if rows:
        atlas = pd.concat(rows, ignore_index=True)
        out = root / cfg["paths"]["interim"] / "atlas_forcedphot_standardized.csv"
        out.parent.mkdir(parents=True, exist_ok=True)
        atlas.to_csv(out, index=False)
        atlas["object_id"] = atlas["object_id"].astype(str)
        print(f"Saved standardized ATLAS light curves: {out} rows={len(atlas)} objects={atlas['object_id'].nunique()}")
    if manifest:
        man = root / cfg["paths"]["tables"] / "atlas_parse_file_manifest.csv"
        pd.DataFrame(manifest).to_csv(man, index=False)
        print(f"Saved parse manifest: {man} files={len(manifest)}")
    if errors:
        err = root / cfg["paths"]["tables"] / "atlas_parse_errors.csv"
        pd.DataFrame(errors).to_csv(err, index=False)
        print(f"Saved parse errors: {err} errors={len(errors)}")


if __name__ == "__main__":
    main()
