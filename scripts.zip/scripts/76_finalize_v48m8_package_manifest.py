from __future__ import annotations

import argparse
import hashlib
from pathlib import Path


DEFAULT_ROOT = Path(__file__).resolve().parents[1]


def digest(path: Path) -> str:
    value = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            value.update(chunk)
    return value.hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=DEFAULT_ROOT)
    parser.add_argument("--manifest", default="V48M8_SHA256_MANIFEST.txt")
    args = parser.parse_args()
    root = args.root.resolve()
    manifest = root / args.manifest
    files = sorted(
        path
        for path in root.rglob("*")
        if path.is_file() and path != manifest and "__pycache__" not in path.parts
    )
    lines = [f"{digest(path)}  {path.relative_to(root).as_posix()}" for path in files]
    manifest.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"V48M8_MANIFEST_PASS files={len(files)}")


if __name__ == "__main__":
    main()
