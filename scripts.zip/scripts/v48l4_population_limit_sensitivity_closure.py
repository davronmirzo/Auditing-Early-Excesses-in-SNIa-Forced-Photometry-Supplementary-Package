from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd

VERSION = "v48l4_population_limit_sensitivity_closure_1.0.0"
OUT_REL = Path("results/v48_canonical/revision/v48l4_population_limits")


def require(ok: bool, message: str) -> None:
    if not ok:
        raise RuntimeError(message)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--project-root", default=".")
    args = ap.parse_args()
    root = Path(args.project_root).resolve()
    out = root / OUT_REL
    out.mkdir(parents=True, exist_ok=True)

    base = root / "results/v48_canonical/injection/population_limits"
    all_path = base / "v48g2c_population_limits_all_modes.csv"
    primary_path = base / "v48g2c_primary_population_limits.csv"
    summary_path = base / "v48g2c_population_limit_summary.json"
    for p in (all_path, primary_path, summary_path):
        require(p.is_file(), f"Missing canonical V48G2C input: {p}")
    d = pd.read_csv(all_path)
    supplied_primary = pd.read_csv(primary_path)
    canonical_summary = json.loads(summary_path.read_text(encoding="utf-8"))

    required = {
        "template_id", "alpha_refit_mode", "calendar_mode", "scatter_policy",
        "analysis_role", "population_denominator", "observed_confirmed_positives",
        "injection_trials", "recovered", "efficiency", "efficiency_q025",
        "frequentist_exact_f95_raw", "frequentist_exact_f95",
        "frequentist_conservative_eff_q025_f95", "bayesian_beta11_f95",
        "bayesian_beta05_f95", "limit_informative_below_one",
    }
    require(required.issubset(d.columns), f"Missing columns: {sorted(required-set(d.columns))}")
    require(len(d) == 40, f"Expected 40 all-mode cells, got {len(d)}")
    require(d["template_id"].nunique() == 5, "Expected five proxy templates")
    require(set(d["analysis_role"]) == {"primary", "sensitivity"}, "Unexpected analysis roles")
    require((pd.to_numeric(d["population_denominator"]) == 277).all(), "Population denominator changed")
    require((pd.to_numeric(d["observed_confirmed_positives"]) == 0).all(), "Confirmed-positive count changed")

    p = d[d["analysis_role"] == "primary"].copy()
    require(len(p) == 5 and len(supplied_primary) == 5, "Expected five primary cells")
    require((p["alpha_refit_mode"] == "free").all(), "Primary alpha mode changed")
    require((p["calendar_mode"] == "shared-physical-date").all(), "Primary calendar mode changed")
    require((p["scatter_policy"] == "frozen-pre-injection").all(), "Primary scatter mode changed")
    require((pd.to_numeric(p["frequentist_exact_f95"]) == 1.0).all(), "Primary frequentist limits changed")
    informative = d["limit_informative_below_one"].astype(str).str.lower().isin({"true", "1", "yes"})
    p_informative = p["limit_informative_below_one"].astype(str).str.lower().isin({"true", "1", "yes"})
    require(int(informative.sum()) == 6 and int(p_informative.sum()) == 0, "Informative-cell counts changed")

    # Validate the stated efficiency posterior contract directly from k and n.
    require(np.allclose(pd.to_numeric(d["efficiency_beta_posterior_a"]), pd.to_numeric(d["recovered"]) + 1), "Efficiency posterior a != k+1")
    require(np.allclose(pd.to_numeric(d["efficiency_beta_posterior_b"]), pd.to_numeric(d["injection_trials"]) - pd.to_numeric(d["recovered"]) + 1), "Efficiency posterior b != n-k+1")

    table = p[[
        "template_id", "efficiency", "efficiency_q025", "frequentist_exact_f95",
        "frequentist_conservative_eff_q025_f95", "bayesian_beta11_f95",
        "bayesian_beta05_f95", "limit_informative_below_one",
    ]].copy()
    table["bayesian_prior_spread_beta05_minus_beta11"] = table["bayesian_beta05_f95"] - table["bayesian_beta11_f95"]
    table.to_csv(out / "v48l4_primary_limit_prior_sensitivity.csv", index=False)

    informative_cells = d[informative].copy()
    informative_cells.to_csv(out / "v48l4_nonprimary_informative_cells_6.csv", index=False)

    mode_summary = d.groupby(["alpha_refit_mode", "calendar_mode", "scatter_policy"], as_index=False).agg(
        template_cells=("template_id", "size"),
        efficiency_min=("efficiency", "min"), efficiency_max=("efficiency", "max"),
        frequentist_f95_min=("frequentist_exact_f95", "min"), frequentist_f95_max=("frequentist_exact_f95", "max"),
        beta11_f95_min=("bayesian_beta11_f95", "min"), beta11_f95_max=("bayesian_beta11_f95", "max"),
        beta05_f95_min=("bayesian_beta05_f95", "min"), beta05_f95_max=("bayesian_beta05_f95", "max"),
    )
    mode_summary.to_csv(out / "v48l4_mode_level_limit_ranges.csv", index=False)

    closure = {
        "version": VERSION,
        "population_denominator": 277,
        "confirmed_astrophysical_positives": 0,
        "templates": 5,
        "all_mode_cells": len(d),
        "primary_cells": len(p),
        "sensitivity_cells": len(d) - len(p),
        "efficiency_uncertainty": "Beta(k+1,n-k+1)",
        "occurrence_priors": ["Beta(1,1)", "Beta(0.5,0.5)"],
        "primary_mode": {"alpha_refit_mode": "free", "calendar_mode": "shared-physical-date", "scatter_policy": "frozen-pre-injection"},
        "primary_efficiency_range": [float(p.efficiency.min()), float(p.efficiency.max())],
        "primary_efficiency_q025_range": [float(p.efficiency_q025.min()), float(p.efficiency_q025.max())],
        "primary_frequentist_f95_range": [float(p.frequentist_exact_f95.min()), float(p.frequentist_exact_f95.max())],
        "primary_conservative_efficiency_f95_range": [float(p.frequentist_conservative_eff_q025_f95.min()), float(p.frequentist_conservative_eff_q025_f95.max())],
        "primary_beta11_f95_range": [float(p.bayesian_beta11_f95.min()), float(p.bayesian_beta11_f95.max())],
        "primary_beta05_f95_range": [float(p.bayesian_beta05_f95.min()), float(p.bayesian_beta05_f95.max())],
        "primary_prior_spread_range": [float(table.bayesian_prior_spread_beta05_minus_beta11.min()), float(table.bayesian_prior_spread_beta05_minus_beta11.max())],
        "all_mode_informative_cells_below_one": int(informative.sum()),
        "primary_informative_cells_below_one": int(p_informative.sum()),
        "informative_cells_role": "sensitivity only; all six use fixed-to-pre-injection alpha and frozen scatter",
        "frequentist_interpretation": "All primary exact 95% upper limits clip at the physical boundary f=1 and are therefore non-informative below unity.",
        "bayesian_interpretation": "Primary Bayesian upper limits are finite but weak and visibly prior dependent; neither prior is promoted as a physical-channel occurrence constraint.",
        "physical_channel_occurrence_interpretation_authorized": False,
        "proxy_template_interpretation": "Limits apply only to recovery of the specified phenomenological proxy templates under the stated mode.",
        "derived_audit_summaries_computed": True,
        "injections_rerun": False,
        "canonical_outputs_modified": False,
        "claims_frozen": True,
        "next_authorized_stage": "V48L5_THERMAL_PROXY_AND_SN2018OH_LIMITATION_CLOSURE",
    }
    (out / "v48l4_closure_summary.json").write_text(json.dumps(closure, indent=2), encoding="utf-8")

    manuscript = """**Population-limit sensitivity.** **Occurrence limits were computed for 277 primary-denominator objects and zero confirmed astrophysical positives. Recovery-efficiency uncertainty was propagated with a Beta(k+1,n-k+1) posterior for k recoveries in n trials. We report the direct exact 95% frequentist upper limit, a conservative version evaluated at the 2.5th percentile of the efficiency posterior, and Bayesian 95% upper limits under both Beta(1,1) and Beta(0.5,0.5) occurrence priors.**

**In the prospectively frozen primary mode (free alpha, shared physical injection date, and frozen pre-injection scatter), efficiencies span 0.00098-0.00735. All five direct and efficiency-conservative frequentist upper limits reach the physical boundary f=1 and therefore provide no informative sub-unity frequentist constraint. The corresponding Bayesian limits are 0.859-0.942 under Beta(1,1) and 0.931-0.992 under Beta(0.5,0.5), demonstrating substantial prior dependence. Six of the 40 all-mode cells yield sub-unity frequentist limits, but every one is a fixed-alpha, frozen-scatter sensitivity cell; none replaces the frozen primary analysis.**

**These quantities constrain only the incidence of the specified phenomenological proxy signals as recoverable by this pipeline. They are not occurrence-rate measurements for companion interaction, surface radioactivity, or another unique physical channel, because mapping a proxy amplitude and shape onto such channels requires additional physical population assumptions that were not modelled here.**
"""
    (out / "v48l4_manuscript_insertion_bold.txt").write_text(manuscript, encoding="utf-8")
    response = """**Response — population-limit sensitivity.** **We now propagate injection-efficiency uncertainty explicitly with Beta(k+1,n-k+1), report exact and conservative frequentist limits, and show Bayesian limits under both Beta(1,1) and Beta(0.5,0.5) occurrence priors for every mode. In the prospectively frozen primary mode, all five frequentist 95% limits reach unity; the finite Bayesian limits remain weak and prior dependent. Although six sensitivity cells produce sub-unity frequentist limits, all use fixed pre-injection alpha with frozen scatter and are not promoted post hoc. We have accordingly narrowed the interpretation: the limits apply to the specified proxy templates under stated pipeline modes and are not physical-channel occurrence-rate constraints.**
"""
    (out / "v48l4_response_letter_text_bold.txt").write_text(response, encoding="utf-8")
    (out / "v48l4_allowed_claims.txt").write_text(
        "ALLOWED CLAIMS\n- Population denominator is 277 and confirmed positives are zero.\n- Efficiency uncertainty is Beta(k+1,n-k+1).\n- All five primary frequentist limits are non-informative below unity.\n- Primary Bayesian limits are weak and prior dependent.\n- Six non-primary fixed-alpha/frozen-scatter cells have sub-unity frequentist limits.\n- Limits apply to named proxy-template recovery under specified modes.\n", encoding="utf-8")
    (out / "v48l4_prohibited_claims.txt").write_text(
        "PROHIBITED CLAIMS\n- Do not call a sensitivity cell the primary result.\n- Do not select the strongest limit after inspecting all modes.\n- Do not describe a clipped f95=1 result as a constraining upper limit below unity.\n- Do not omit prior dependence from Bayesian limits.\n- Do not interpret proxy-template limits as physical-channel occurrence rates.\n- Do not reuse the obsolete denominator 219.\n", encoding="utf-8")

    report = [
        "V48L4_POPULATION_LIMIT_SENSITIVITY_CLOSURE_PASS",
        f"Population denominator / confirmed positives: 277/0",
        f"All/primary/sensitivity mode cells: {len(d)}/{len(p)}/{len(d)-len(p)}",
        f"All-mode/primary informative-below-one cells: {int(informative.sum())}/{int(p_informative.sum())}",
        f"Primary efficiency range: {p.efficiency.min():.9f}-{p.efficiency.max():.9f}",
        f"Primary frequentist exact f95 range: {p.frequentist_exact_f95.min():.6f}-{p.frequentist_exact_f95.max():.6f}",
        f"Primary Bayesian Beta(1,1) f95 range: {p.bayesian_beta11_f95.min():.6f}-{p.bayesian_beta11_f95.max():.6f}",
        f"Primary Bayesian Beta(0.5,0.5) f95 range: {p.bayesian_beta05_f95.min():.6f}-{p.bayesian_beta05_f95.max():.6f}",
        "Physical-channel occurrence interpretation authorized: False",
        "Injections rerun: False",
        "Canonical outputs modified: False",
        "Claims frozen: True",
        "NEXT_AUTHORIZED_STAGE=V48L5_THERMAL_PROXY_AND_SN2018OH_LIMITATION_CLOSURE",
    ]
    (out / "v48l4_report.txt").write_text("\n".join(report) + "\n", encoding="utf-8")
    print("\n".join(report))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
