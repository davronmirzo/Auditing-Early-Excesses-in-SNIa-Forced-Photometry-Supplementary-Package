from __future__ import annotations

import argparse
import csv
import gzip
import hashlib
import json
import re
from pathlib import Path

VERSION = "v48l2a3_atlas_data_convention_audit_1.0.0"
OUT_REL = Path("results/v48_canonical/revision/v48l2a3_data_convention")

PATTERNS = {
    "flux_unit": re.compile(r"flux[_ ]?unit|microjy|ujy|µjy|mjy|jy\b", re.I),
    "zero_point": re.compile(r"zero[_ -]?point|zeropoint|magzp|zp\b|23\.9|10\s*\*\*\s*\(", re.I),
    "quality_cut": re.compile(r"quality|chi.?n|dujy|fluxerr|flag|mask|sigma|uncert|good[_ ]?row", re.I),
    "band_encoding": re.compile(r"native[_ ]?band|filter|\bband\b|\b[co]\b", re.I),
    "provenance": re.compile(r"source[_ ]?(file|relpath)|atlas|forcedphot|request", re.I),
}


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def open_text(path: Path):
    return gzip.open(path, "rt", encoding="utf-8-sig", errors="replace", newline="") if path.suffix == ".gz" else path.open("r", encoding="utf-8-sig", errors="replace", newline="")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--project-root", default=".")
    args = ap.parse_args()
    root = Path(args.project_root).resolve()
    out = root / OUT_REL
    out.mkdir(parents=True, exist_ok=True)

    preferred = [
        root / "data/interim/atlas_forcedphot_standardized.csv",
        root / "data/processed/earlyrise_lightcurves.csv",
    ]
    data_files = [p for p in preferred if p.is_file()]
    source_files = []
    for base in (root / "scripts", root / "config"):
        if base.exists():
            source_files.extend(p for p in base.rglob("*") if p.is_file() and p.suffix.lower() in {".py", ".json", ".yaml", ".yml", ".toml"})

    evidence = []
    table_profile = []
    for path in data_files:
        rel = str(path.relative_to(root)).replace("/", "\\")
        with open_text(path) as f:
            reader = csv.DictReader(f)
            fields = reader.fieldnames or []
            tracked = {c: set() for c in fields if re.search(r"flux.?unit|band|filter|source|survey|zp|zero", c, re.I)}
            rows = 0
            for row in reader:
                rows += 1
                if rows <= 200000:
                    for c in tracked:
                        v = str(row.get(c, "")).strip()
                        if v and len(tracked[c]) < 30:
                            tracked[c].add(v)
        table_profile.append({"relative_path": rel, "rows": rows, "columns": "|".join(fields), "sha256": sha256(path)})
        for c, vals in tracked.items():
            category = "flux_unit" if re.search(r"flux.?unit", c, re.I) else "zero_point" if re.search(r"zp|zero", c, re.I) else "band_encoding" if re.search(r"band|filter", c, re.I) else "provenance"
            evidence.append({"category": category, "relative_path": rel, "line_number": "TABLE", "evidence": f"{c} unique values: {sorted(vals)}"})

    for path in sorted(source_files):
        try:
            text = path.read_text(encoding="utf-8-sig", errors="replace")
        except OSError:
            continue
        rel = str(path.relative_to(root)).replace("/", "\\")
        for lineno, line in enumerate(text.splitlines(), 1):
            stripped = line.strip()
            if not stripped or len(stripped) > 1000:
                continue
            for category, pattern in PATTERNS.items():
                if pattern.search(stripped):
                    evidence.append({"category": category, "relative_path": rel, "line_number": lineno, "evidence": stripped[:1000]})

    with (out / "v48l2a3_table_profile.csv").open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["relative_path", "rows", "columns", "sha256"])
        w.writeheader(); w.writerows(table_profile)
    with (out / "v48l2a3_literal_evidence.csv").open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["category", "relative_path", "line_number", "evidence"])
        w.writeheader(); w.writerows(evidence)

    counts = {k: sum(e["category"] == k for e in evidence) for k in PATTERNS}
    status = {k: ("FOUND" if counts[k] else "NOT_ENCODED") for k in PATTERNS}
    summary = {
        "version": VERSION,
        "project_root": str(root),
        "tables_profiled": len(table_profile),
        "source_files_scanned": len(source_files),
        "evidence_counts": counts,
        "status": status,
        "scientific_calculations_executed": False,
        "canonical_outputs_modified": False,
        "interpretive_warning": "Pattern hits are an evidence inventory, not automatic scientific validation; V48L2B must quote only inspected literal evidence.",
        "next_authorized_stage": "V48L2B_BASELINE_SCATTER_REPRODUCIBILITY_CONTRACT_FREEZE_AFTER_EVIDENCE_REVIEW",
    }
    (out / "v48l2a3_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")

    print("V48L2A3_ATLAS_DATA_CONVENTION_AUDIT_COMPLETE")
    print("V48L2A3_EVIDENCE_INVENTORY_PASS")
    print(f"Tables/source files: {len(table_profile)}/{len(source_files)}")
    for k in PATTERNS:
        print(f"{k}: {status[k]} ({counts[k]} evidence rows)")
    print("Scientific calculations executed: False")
    print("Canonical outputs modified: False")
    print("NEXT_AUTHORIZED_STAGE=" + summary["next_authorized_stage"])
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
