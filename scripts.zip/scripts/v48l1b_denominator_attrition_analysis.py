from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import chi2_contingency, kruskal, mannwhitneyu

VERSION = "v48l1b_denominator_attrition_analysis_1.0.0"
GROUP_ORDER = ["no_valid_fit", "fit_valid_chi2_gt5", "primary_chi2_le5"]


def truth(s: pd.Series) -> pd.Series:
    return s.astype(str).str.strip().str.lower().isin(["true", "1", "yes"])


def unique_by(df: pd.DataFrame, key: str, label: str) -> pd.DataFrame:
    if key not in df.columns:
        raise RuntimeError(f"{label}: missing key {key}")
    dup = df[key].astype(str).duplicated(keep=False)
    if dup.any():
        # Exact duplicate object rows are harmless; conflicting rows are not.
        cols = [c for c in df.columns if not str(c).lower().startswith("unnamed")]
        conflicts = df.loc[dup, cols].astype(str).groupby(df.loc[dup, key].astype(str)).nunique().max(axis=1)
        if (conflicts > 1).any():
            raise RuntimeError(f"{label}: conflicting duplicate IDs")
    return df.assign(**{key: df[key].astype(str)}).drop_duplicates(key, keep="first")


def cliffs_delta(x: np.ndarray, y: np.ndarray) -> float:
    # x is attrition group; y is primary reference.
    x, y = np.asarray(x, float), np.asarray(y, float)
    x, y = x[np.isfinite(x)], y[np.isfinite(y)]
    if not len(x) or not len(y):
        return np.nan
    return float(sum(np.sign(v - y).sum() for v in x) / (len(x) * len(y)))


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--project-root", type=Path, default=Path.cwd())
    ap.add_argument("--output-dir", type=Path,
                    default=Path("results/v48_canonical/revision/v48l1b_attrition"))
    args = ap.parse_args()
    root = args.project_root.resolve()
    out = (root / args.output_dir).resolve() if not args.output_dir.is_absolute() else args.output_dir
    out.mkdir(parents=True, exist_ok=True)

    paths = {
        "canonical": root / "results/v48_canonical/audit/v48c_denominator_adjudication_368.csv",
        "native": root / "results/tables/eeri_native_co_gate_368_from_stage4.csv",
        "snia": root / "data/raw/ztf_dr2/tables/local_snia_data.csv",
        "host": root / "data/raw/ztf_dr2/tables/local_globalhost_data.csv",
    }
    missing = [str(p) for p in paths.values() if not p.exists()]
    if missing:
        raise SystemExit("MISSING_AUTHORITATIVE_INPUTS=" + "|".join(missing))

    c = unique_by(pd.read_csv(paths["canonical"]), "object_id", "canonical")
    if len(c) != 368 or c.object_id.nunique() != 368:
        raise SystemExit("CANONICAL_368_GATE_FAIL")
    fit = truth(c["fit_valid"])
    primary = truth(c["primary_chi2_le_5"])
    c["attrition_group"] = np.select(
        [~fit, fit & ~primary, fit & primary], GROUP_ORDER, default="invalid_state")
    expected = c.attrition_group.value_counts().to_dict()
    if expected != {"primary_chi2_le5": 277, "no_valid_fit": 65, "fit_valid_chi2_gt5": 26}:
        raise SystemExit(f"ATTRITION_COUNT_GATE_FAIL={expected}")

    native = unique_by(pd.read_csv(paths["native"]), "ztf_id", "native").rename(columns={"ztf_id": "object_id"})
    snia = unique_by(pd.read_csv(paths["snia"]), "ztfname", "snia").rename(columns={"ztfname": "object_id"})
    host = unique_by(pd.read_csv(paths["host"]), "ztfname", "host").rename(columns={"ztfname": "object_id"})

    keep_native = ["object_id", "n_early_points", "n_early_det3", "first_phase", "last_phase", "span_days"]
    keep_snia = ["object_id", "redshift", "x0", "mwebv", "sn_type", "sub_type", "fitprob", "lccoverage_flag"]
    keep_host = ["object_id", "mass", "restframe_gz", "d_dlr"]
    for cols, df, label in [(keep_native, native, "native"), (keep_snia, snia, "snia"), (keep_host, host, "host")]:
        miss = [x for x in cols if x not in df.columns]
        if miss:
            raise SystemExit(f"{label.upper()}_COLUMNS_MISSING={miss}")

    d = c.merge(native[keep_native], on="object_id", how="left", validate="one_to_one")
    d = d.merge(snia[keep_snia], on="object_id", how="left", validate="one_to_one")
    d = d.merge(host[keep_host], on="object_id", how="left", validate="one_to_one")
    d["salt2_brightness_proxy"] = -2.5 * np.log10(pd.to_numeric(d.x0, errors="coerce").where(lambda z: z > 0))

    numeric = [
        "n_early_points", "n_early_det3", "span_days", "n_night_blocks",
        "minimum_valid_band_points", "redshift", "salt2_brightness_proxy", "mwebv",
        "mass", "restframe_gz", "d_dlr", "max_positive_residual",
        "max_negative_abs_residual", "n_signal_points", "n_signal_bands",
    ]
    for col in numeric:
        d[col] = pd.to_numeric(d[col], errors="coerce")

    summary_rows = []
    for metric in numeric:
        groups = []
        for g in GROUP_ORDER:
            vals = d.loc[d.attrition_group.eq(g), metric].dropna().to_numpy(float)
            groups.append(vals)
            summary_rows.append({
                "metric": metric, "group": g, "n_total": int(d.attrition_group.eq(g).sum()),
                "n_available": len(vals), "missing_fraction": 1 - len(vals) / int(d.attrition_group.eq(g).sum()),
                "median": np.nanmedian(vals) if len(vals) else np.nan,
                "q16": np.nanpercentile(vals, 16) if len(vals) else np.nan,
                "q84": np.nanpercentile(vals, 84) if len(vals) else np.nan,
                "mean": np.nanmean(vals) if len(vals) else np.nan,
            })
        p_kw = kruskal(*groups, nan_policy="omit").pvalue if all(len(v) for v in groups) else np.nan
        for row in summary_rows[-3:]:
            row["kruskal_p_all_groups"] = p_kw

    summary = pd.DataFrame(summary_rows)
    pair_rows = []
    primary_vals = {m: d.loc[d.attrition_group.eq(GROUP_ORDER[2]), m].dropna().to_numpy(float) for m in numeric}
    for metric in numeric:
        for g in GROUP_ORDER[:2]:
            x = d.loc[d.attrition_group.eq(g), metric].dropna().to_numpy(float)
            y = primary_vals[metric]
            p = mannwhitneyu(x, y, alternative="two-sided").pvalue if len(x) and len(y) else np.nan
            pair_rows.append({"metric": metric, "attrition_group": g, "reference_group": GROUP_ORDER[2],
                              "n_attrition": len(x), "n_reference": len(y), "mannwhitney_p": p,
                              "cliffs_delta": cliffs_delta(x, y)})
    pair = pd.DataFrame(pair_rows)
    pair["holm_significant_0p05"] = False
    finite = pair.mannwhitney_p.notna()
    order = pair.loc[finite, "mannwhitney_p"].sort_values().index
    m = len(order)
    still = True
    for rank, idx in enumerate(order, start=1):
        passed = pair.loc[idx, "mannwhitney_p"] <= 0.05 / (m - rank + 1)
        still = still and passed
        pair.loc[idx, "holm_significant_0p05"] = still

    cat_rows = []
    for col in ["sn_type", "sub_type"]:
        x = d[["attrition_group", col]].copy()
        x[col] = x[col].fillna("MISSING").astype(str).str.strip().replace("", "MISSING")
        tab = pd.crosstab(x.attrition_group, x[col]).reindex(GROUP_ORDER, fill_value=0)
        p = chi2_contingency(tab).pvalue if tab.shape[1] > 1 else np.nan
        for g in GROUP_ORDER:
            for level, count in tab.loc[g].items():
                cat_rows.append({"variable": col, "group": g, "level": level, "count": int(count),
                                 "fraction_within_group": count / tab.loc[g].sum(), "chi2_p": p})
    categorical = pd.DataFrame(cat_rows)

    threshold_rows = []
    fitvalid = d[fit].copy()
    for threshold in [3.0, 5.0, 7.0, 10.0]:
        member = fitvalid.median_chi2_dof.le(threshold)
        threshold_rows.append({
            "chi2_threshold": threshold, "fit_valid_objects": len(fitvalid),
            "denominator_objects": int(member.sum()),
            "raw_positive_crossings": int(truth(fitvalid.loc[member, "positive_threshold_crossing"]).sum()),
            "raw_negative_crossings": int(truth(fitvalid.loc[member, "negative_threshold_crossing"]).sum()),
            "confirmed_positive_count": 0 if threshold == 5.0 else np.nan,
            "forensic_status": "canonical_complete" if threshold == 5.0 else "raw_crossings_only_not_forensically_readjudicated",
        })
    thresholds = pd.DataFrame(threshold_rows)

    provenance = pd.DataFrame([
        {"domain": "cadence", "source": str(paths["native"].relative_to(root)), "variables": "n_early_points|n_early_det3|first_phase|last_phase|span_days"},
        {"domain": "redshift_brightness_subtype", "source": str(paths["snia"].relative_to(root)), "variables": "redshift|x0|mwebv|sn_type|sub_type|fitprob|lccoverage_flag"},
        {"domain": "host", "source": str(paths["host"].relative_to(root)), "variables": "mass|restframe_gz|d_dlr"},
        {"domain": "fit_and_early_structure", "source": str(paths["canonical"].relative_to(root)), "variables": "fit_valid|median_chi2_dof|n_night_blocks|residual extrema|signal counts|crossings"},
    ])

    d.to_csv(out / "v48l1b_object_level_attrition_covariates_368.csv", index=False)
    summary.to_csv(out / "v48l1b_numeric_group_summary.csv", index=False)
    pair.to_csv(out / "v48l1b_pairwise_primary_comparisons.csv", index=False)
    categorical.to_csv(out / "v48l1b_subtype_group_summary.csv", index=False)
    thresholds.to_csv(out / "v48l1b_chi2_threshold_sensitivity.csv", index=False)
    provenance.to_csv(out / "v48l1b_authoritative_source_freeze.csv", index=False)

    payload = {
        "version": VERSION, "canonical_objects": 368,
        "group_counts": {k: int(v) for k, v in expected.items()},
        "numeric_metrics": numeric, "subtype_variables": ["sn_type", "sub_type"],
        "host_metrics": ["mass", "restframe_gz", "d_dlr"],
        "brightness_metric_interpretation": "-2.5 log10(SALT2 x0); relative brightness proxy only",
        "canonical_outputs_modified": False,
        "next_authorized_stage": "V48L1C_ATTRITION_INTERPRETATION_AND_MANUSCRIPT_CLAIM_FREEZE",
    }
    (out / "v48l1b_summary.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")
    report = ["V48L1B_DENOMINATOR_ATTRITION_ANALYSIS_COMPLETE",
              "V48L1B_ATTRITION_GATE_PASS",
              f"Group counts: no-valid-fit/high-chi2/primary = {expected['no_valid_fit']}/{expected['fit_valid_chi2_gt5']}/{expected['primary_chi2_le5']}",
              f"Numeric metrics: {len(numeric)}", "Subtype variables: sn_type, sub_type",
              "Host proxies: mass, restframe_gz, d_dlr", "Canonical outputs modified: False",
              "Non-primary threshold rows are raw-crossing sensitivity only: True",
              "NEXT_AUTHORIZED_STAGE=V48L1C_ATTRITION_INTERPRETATION_AND_MANUSCRIPT_CLAIM_FREEZE"]
    (out / "v48l1b_report.txt").write_text("\n".join(report) + "\n", encoding="utf-8")
    print("\n".join(report))
    print("\nCHI2 THRESHOLD SENSITIVITY")
    print(thresholds.to_string(index=False))
    print("\nHOLM-SIGNIFICANT PAIRWISE DIFFERENCES")
    sig = pair[pair.holm_significant_0p05]
    print(sig.to_string(index=False) if len(sig) else "NONE")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
