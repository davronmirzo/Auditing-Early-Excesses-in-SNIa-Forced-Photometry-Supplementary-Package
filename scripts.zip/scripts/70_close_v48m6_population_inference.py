from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from scipy.integrate import quad
from scipy.optimize import brentq


VERSION = "v48m6_population_inference_1.0.0"
TARGET_LOG = math.log(0.05)
CROSSING_IDS = {
    "ZTF18abebzog", "ZTF18ablqlzp", "ZTF18abnygkb", "ZTF19aawupxb", "ZTF19acoxgqw"
}


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def truthy(series: pd.Series) -> pd.Series:
    return series.astype(str).str.strip().str.lower().isin({"true", "1", "yes", "y", "t"})


def log_likelihood_zero(f: float, eps: np.ndarray) -> float:
    with np.errstate(divide="ignore", invalid="ignore"):
        return float(np.log1p(-float(f) * eps).sum())


def frequentist_f95(eps: np.ndarray) -> tuple[float, bool]:
    at_one = log_likelihood_zero(1.0, eps)
    if at_one > TARGET_LOG:
        return 1.0, True
    return float(brentq(lambda f: log_likelihood_zero(f, eps) - TARGET_LOG, 0.0, 1.0)), False


def bayesian_upper(eps: np.ndarray, a: float, b: float, quantile: float = 0.95) -> float:
    def log_kernel(f: float) -> float:
        if f <= 0.0:
            if a < 1.0: return math.inf
            if a > 1.0: return -math.inf
        if f >= 1.0:
            if b < 1.0: return math.inf
            if b > 1.0: return -math.inf
        prior = (a - 1.0) * math.log(max(f, 1e-300)) + (b - 1.0) * math.log(max(1.0 - f, 1e-300))
        return prior + log_likelihood_zero(f, eps)

    probe = np.linspace(1e-8, 1.0 - 1e-8, 2001)
    shift = max(log_kernel(float(x)) for x in probe)
    kernel = lambda x: math.exp(min(700.0, log_kernel(float(x)) - shift))
    denominator = quad(kernel, 0.0, 1.0, points=[0.0, 1.0], epsabs=1e-10, limit=300)[0]
    return float(brentq(lambda x: quad(kernel, 0.0, x, points=[0.0], epsabs=1e-10, limit=300)[0] / denominator - quantile,
                         1e-12, 1.0 - 1e-12))


def pooled_f95(n: int, mean_efficiency: float) -> float:
    if mean_efficiency <= 0:
        return 1.0
    value = (1.0 - 0.05 ** (1.0 / n)) / mean_efficiency
    return float(min(1.0, value))


def window_key(lo: float, hi: float) -> str:
    return f"window_{str(lo).replace('-', 'm').replace('.', 'p')}_{str(hi).replace('.', 'p')}"


def offset_key(offset: float) -> str:
    return f"phase_offset_{str(offset).replace('-', 'm').replace('.', 'p')}"


def observed_confirmation(root: Path) -> pd.DataFrame:
    deletion = pd.read_csv(root / "results/v48_canonical/forensics/v48e_single_extreme_point_deletion_5.csv")
    decisions = pd.read_csv(root / "results/v48_canonical/forensics/v48e_candidate_adjudication_5.csv")
    points = pd.read_csv(root / "results/v48_canonical/forensics/v48e_candidate_signal_points_with_provenance.csv")
    positives = deletion[deletion["crossing_label"] == "positive"].copy()
    rows: list[dict[str, Any]] = []
    for row in positives.itertuples(index=False):
        oid = str(row.object_id)
        q = points[points["object_id"].astype(str) == oid].copy()
        q["night"] = np.floor(pd.to_numeric(q["mjd"], errors="coerce")).astype("Int64")
        block = q.groupby(["band", "night"])["residual_sigma"].max()
        bands = set(block[block > 3.0].index.get_level_values("band"))
        lono = bool(decisions.loc[decisions["object_id"].astype(str) == oid, "survives_all_leave_trigger_night_refits"].iloc[0])
        single = bool(row.crossing_survives_single_extreme_deletion)
        two_band = {"c", "o"}.issubset(bands)
        rows.append({
            "object_id": oid, "raw_positive": True, "single_point_survives": single,
            "lono_all_survive": lono, "two_band_coherent": two_band,
            "structurally_confirmed": bool(single and lono and two_band),
            "support_bands_gt3": "|".join(sorted(bands)), "version": VERSION,
        })
    return pd.DataFrame(rows)


def bootstrap_f95(eps: np.ndarray, rng: np.random.Generator, draws: int = 20000, batch: int = 400) -> np.ndarray:
    n = len(eps)
    out = np.empty(draws, dtype=float)
    for start in range(0, draws, batch):
        stop = min(start + batch, draws)
        sampled = eps[rng.integers(0, n, size=(stop - start, n))]
        with np.errstate(divide="ignore"):
            log_one = np.log1p(-sampled).sum(axis=1)
        capped = log_one > TARGET_LOG
        lo = np.zeros(stop - start)
        hi = np.ones(stop - start)
        for _ in range(48):
            mid = (lo + hi) / 2.0
            with np.errstate(divide="ignore"):
                val = np.log1p(-mid[:, None] * sampled).sum(axis=1)
            too_high = val > TARGET_LOG
            lo = np.where(too_high, mid, lo)
            hi = np.where(too_high, hi, mid)
        out[start:stop] = np.where(capped, 1.0, hi)
    return out


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=".")
    args = parser.parse_args()
    root = Path(args.root).resolve()
    contract_path = root / "config/v48m6_end_to_end_contract.json"
    trials_path = root / "results/v48m6_end_to_end/production/v48m6_injection_trials_43050.csv.gz"
    summary_path = root / "results/v48m6_end_to_end/production/v48m6_adjudicated_production_summary.json"
    for path in (contract_path, trials_path, summary_path):
        if not path.is_file():
            raise FileNotFoundError(path)
    production = json.loads(summary_path.read_text(encoding="utf-8"))
    if production.get("status") != "V48M6_END_TO_END_PRODUCTION_COMPLETE_WITH_ONE_CONSERVATIVE_NONRECOVERY" or not production.get("gate_pass"):
        raise RuntimeError("V48M6 production gate is not closed")
    contract = json.loads(contract_path.read_text(encoding="utf-8"))
    trials = pd.read_csv(trials_path)
    objects = pd.read_csv(root / "results/v48_canonical/baseline/v48b_object_summary.csv")
    objects["fit_valid_bool"] = truthy(objects["fit_valid"])
    objects["median_chi2_dof"] = pd.to_numeric(objects["median_chi2_dof"], errors="coerce")
    templates = [x["template_id"] for x in json.loads((root / "config/v48g1_injection_contract.json").read_text(encoding="utf-8"))["templates"]]
    primary_ids = set(objects.loc[objects["fit_valid_bool"] & objects["median_chi2_dof"].le(5.0), "object_id"].astype(str))
    if len(trials) != 43050 or len(primary_ids) != 277:
        raise RuntimeError("Frozen V48M6 trial or primary-host count changed")

    configs: list[dict[str, Any]] = []
    for threshold in contract["one_at_a_time_population_grid"]["quality_thresholds_chi2_dof"]:
        ids = set(objects.loc[objects["fit_valid_bool"] & objects["median_chi2_dof"].le(float(threshold)), "object_id"].astype(str))
        configs.append({"axis": "quality_threshold", "setting": f"chi2_dof_le_{threshold:g}", "flag": "raw_primary", "ids": ids,
                        "quality_threshold": float(threshold), "window_lo": -0.5, "window_hi": 6.0, "phase_offset": 0.0,
                        "analysis_family": "raw_screen"})
    for lo, hi in contract["one_at_a_time_population_grid"]["signal_windows_days"]:
        configs.append({"axis": "signal_window", "setting": f"window_{lo:g}_{hi:g}", "flag": window_key(float(lo), float(hi)), "ids": primary_ids,
                        "quality_threshold": 5.0, "window_lo": float(lo), "window_hi": float(hi), "phase_offset": 0.0,
                        "analysis_family": "raw_screen"})
    for offset in contract["one_at_a_time_population_grid"]["named_phase_zero_offsets_days"]:
        configs.append({"axis": "phase_zero", "setting": f"offset_{offset:+.2f}", "flag": offset_key(float(offset)), "ids": primary_ids,
                        "quality_threshold": 5.0, "window_lo": -0.5, "window_hi": 6.0, "phase_offset": float(offset),
                        "analysis_family": "raw_screen"})
    configs.append({"axis": "confirmation", "setting": "structural_end_to_end", "flag": "structurally_confirmed", "ids": primary_ids,
                    "quality_threshold": 5.0, "window_lo": -0.5, "window_hi": 6.0, "phase_offset": 0.0,
                    "analysis_family": "end_to_end"})

    limit_rows: list[dict[str, Any]] = []
    object_rows: list[dict[str, Any]] = []
    for cfg in configs:
        subset0 = trials[trials["object_id"].astype(str).isin(cfg["ids"])].copy()
        for template in templates:
            subset = subset0[subset0["template_id"] == template].copy()
            subset["hit"] = truthy(subset[cfg["flag"]])
            by_object = subset.groupby("object_id", as_index=False).agg(trials=("hit", "size"), recovered=("hit", "sum"))
            if len(by_object) != len(cfg["ids"]) or not by_object["trials"].eq(30).all():
                raise RuntimeError(f"Incomplete object-specific grid for {cfg['axis']} {cfg['setting']} {template}")
            by_object["efficiency"] = by_object["recovered"] / by_object["trials"]
            eps = by_object["efficiency"].to_numpy(float)
            f95, capped = frequentist_f95(eps)
            mean_eff = float(eps.mean())
            limit_rows.append({
                "analysis_family": cfg["analysis_family"], "axis": cfg["axis"], "setting": cfg["setting"],
                "template_id": template, "objects": len(eps), "trials": int(by_object["trials"].sum()),
                "recovered": int(by_object["recovered"].sum()), "mean_efficiency": mean_eff,
                "hosts_with_nonzero_efficiency": int((eps > 0).sum()),
                "f95_object_specific": f95, "f95_capped_at_one": capped,
                "f95_homogeneous_pooled_comparator": pooled_f95(len(eps), mean_eff),
                "bayes95_uniform": bayesian_upper(eps, 1.0, 1.0),
                "bayes95_jeffreys": bayesian_upper(eps, 0.5, 0.5),
                "quality_threshold": cfg["quality_threshold"], "window_lo": cfg["window_lo"],
                "window_hi": cfg["window_hi"], "phase_offset": cfg["phase_offset"], "version": VERSION,
            })
            for row in by_object.itertuples(index=False):
                object_rows.append({
                    "analysis_family": cfg["analysis_family"], "axis": cfg["axis"], "setting": cfg["setting"],
                    "template_id": template, "object_id": row.object_id, "trials": int(row.trials),
                    "recovered": int(row.recovered), "efficiency": float(row.efficiency), "version": VERSION,
                })
    limits = pd.DataFrame(limit_rows)
    object_eff = pd.DataFrame(object_rows)
    observed = observed_confirmation(root)
    if int(observed["structurally_confirmed"].sum()) != 0:
        raise RuntimeError("Observed structural-confirmation count is not zero")

    rng = np.random.default_rng(4806)
    bootstrap_rows: list[dict[str, Any]] = []
    for family, setting in (("raw_screen", "chi2_dof_le_5"), ("end_to_end", "structural_end_to_end")):
        q = object_eff[(object_eff["analysis_family"] == family) & (object_eff["setting"] == setting)]
        for template in templates:
            eps = q[q["template_id"] == template].sort_values("object_id")["efficiency"].to_numpy(float)
            draws = bootstrap_f95(eps, rng)
            bootstrap_rows.append({
                "analysis_family": family, "setting": setting, "template_id": template,
                "bootstrap_draws": len(draws), "seed": 4806,
                "f95_p2p5": float(np.quantile(draws, 0.025)), "f95_median": float(np.quantile(draws, 0.5)),
                "f95_p97p5": float(np.quantile(draws, 0.975)), "fraction_capped_at_one": float(np.mean(draws >= 1.0 - 1e-12)),
                "version": VERSION,
            })
    bootstrap = pd.DataFrame(bootstrap_rows)

    out = root / "results/v48m6_end_to_end/population"
    out.mkdir(parents=True, exist_ok=True)
    limits.to_csv(out / "v48m6_population_sensitivity_all_cells.csv", index=False)
    object_eff.to_csv(out / "v48m6_object_specific_efficiencies.csv.gz", index=False, compression="gzip")
    primary_objects = object_eff[(object_eff["axis"] == "quality_threshold") & (object_eff["setting"] == "chi2_dof_le_5")]
    primary_objects.to_csv(out / "v48m6_primary_object_specific_efficiencies_277x5.csv", index=False)
    crossing = primary_objects[primary_objects["object_id"].astype(str).isin(CROSSING_IDS)].copy()
    crossing.to_csv(out / "v48m6_five_crossing_host_efficiencies.csv", index=False)
    observed.to_csv(out / "v48m6_observed_structural_confirmation_audit.csv", index=False)
    bootstrap.to_csv(out / "v48m6_primary_cluster_bootstrap.csv", index=False)
    primary_limits = limits[(limits["axis"] == "quality_threshold") & (limits["setting"] == "chi2_dof_le_5")]
    e2e_limits = limits[limits["analysis_family"] == "end_to_end"]
    summary = {
        "status": "V48M6_OBJECT_SPECIFIC_END_TO_END_POPULATION_INFERENCE_COMPLETE",
        "version": VERSION, "gate_pass": True,
        "production_trials_sha256": sha256(trials_path), "contract_sha256": sha256(contract_path),
        "production_hosts": 287, "primary_hosts": 277, "templates": 5, "realizations_per_host_template": 30,
        "observed_raw_positive_crossings": 2, "observed_structural_confirmations": 0,
        "primary_raw_efficiency_range": [float(primary_limits["mean_efficiency"].min()), float(primary_limits["mean_efficiency"].max())],
        "primary_raw_f95_range": [float(primary_limits["f95_object_specific"].min()), float(primary_limits["f95_object_specific"].max())],
        "end_to_end_efficiency_range": [float(e2e_limits["mean_efficiency"].min()), float(e2e_limits["mean_efficiency"].max())],
        "end_to_end_f95_range": [float(e2e_limits["f95_object_specific"].min()), float(e2e_limits["f95_object_specific"].max())],
        "all_end_to_end_limits_capped_at_one": bool(e2e_limits["f95_capped_at_one"].all()),
        "quality_cells": int((limits["axis"] == "quality_threshold").sum()),
        "window_cells": int((limits["axis"] == "signal_window").sum()),
        "phase_cells": int((limits["axis"] == "phase_zero").sum()),
        "bootstrap_draws_per_primary_cell": 20000,
        "pooled_272_to_277_transport_used": False,
        "unmeasured_eta_used": False,
        "physical_channel_occurrence_claim_authorized": False,
    }
    (out / "v48m6_population_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    report = [
        summary["status"], "V48M6_POPULATION_GATE_PASS", "Object-specific likelihood: product_i(1-f*epsilon_i)",
        "Observed raw/structurally confirmed positives: 2/0", "Production hosts / primary hosts: 287/277",
        f"Primary raw efficiency range: {summary['primary_raw_efficiency_range'][0]:.6f}--{summary['primary_raw_efficiency_range'][1]:.6f}",
        f"Primary raw f95 range: {summary['primary_raw_f95_range'][0]:.6f}--{summary['primary_raw_f95_range'][1]:.6f}",
        f"End-to-end efficiency range: {summary['end_to_end_efficiency_range'][0]:.6f}--{summary['end_to_end_efficiency_range'][1]:.6f}",
        f"End-to-end f95 range: {summary['end_to_end_f95_range'][0]:.6f}--{summary['end_to_end_f95_range'][1]:.6f}",
        "Pooled 272-to-277 transport used: False", "Unmeasured eta used: False",
        "Physical progenitor-channel rate claim authorized: False",
    ]
    (out / "v48m6_population_claim_box.txt").write_text("\n".join(report) + "\n", encoding="utf-8")
    print(json.dumps(summary, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
