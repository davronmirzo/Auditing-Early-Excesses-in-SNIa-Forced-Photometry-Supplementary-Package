from __future__ import annotations

import argparse
import hashlib
import json
import re
from pathlib import Path

import pandas as pd

VERSION = "v48l2a_baseline_scatter_source_contract_inventory_1.0.0"

PATTERNS = {
    "fit_interval": r"fit[_ -]?(window|interval)|phase[_a-z]*min|phase[_a-z]*max|FIT_.*(MIN|MAX)",
    "minimum_points_nights_dof": r"min[_a-z]*(point|night)|n_points|distinct[_a-z]*night|\bdof\b|degrees?[_ -]of[_ -]freedom",
    "parameter_bounds": r"bounds?|lower[_a-z]*bound|upper[_a-z]*bound|alpha[_a-z]*(min|max)|least_squares\(",
    "initialization_multistart": r"initial|start|seed|guess|multistart|multi[_ -]?start|t0[_a-z]*grid",
    "robust_loss": r"loss\s*=|soft_l1|huber|f_scale|robust",
    "scatter_estimation": r"extra[_a-z]*scatter|empirical[_a-z]*scatter|scatter[_a-z]*(iteration|conver|update)|mad|median_absolute",
    "band_night_aggregation": r"band[_ -]?night|night[_a-z]*block|floor\(.*mjd|groupby\(.*night|night\s*=",
    "atlas_quality_cuts": r"chi/?n|dujy|quality|flag|fluxerr|snr|signal.to.noise|uJy|microjy",
    "flux_zero_point_convention": r"zeropoint|zero[_ -]?point|flux[_a-z]*unit|microjy|uJy|AB\b|magzp",
    "scatter_injection_policy": r"frozen.pre.injection|reestimated.post.injection|scatter_policy|pre[_ -]?injection.*scatter",
}


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--project-root", type=Path, default=Path.cwd())
    ap.add_argument("--output-dir", type=Path,
                    default=Path("results/v48_canonical/revision/v48l2a_source_contract"))
    a = ap.parse_args(); root = a.project_root.resolve()
    out = (root/a.output_dir).resolve() if not a.output_dir.is_absolute() else a.output_dir
    out.mkdir(parents=True, exist_ok=True)

    candidates = []
    for base in [root/"scripts", root]:
        if base.exists():
            candidates.extend(base.glob("*.py"))
            candidates.extend(base.glob("*.bat"))
    candidates = sorted(set(p.resolve() for p in candidates if p.is_file()))
    priority = [p for p in candidates if re.search(r"v48|baseline|scatter|injection|forcedphot|standard", p.name, re.I)]
    if not priority:
        raise SystemExit("NO_RELEVANT_SOURCE_FILES_FOUND")

    hit_rows=[]; file_rows=[]
    for path in priority:
        rel=path.relative_to(root)
        try: text=path.read_text(encoding="utf-8",errors="replace")
        except Exception as exc:
            file_rows.append({"relative_path":str(rel),"bytes":path.stat().st_size,"sha256":sha256(path),"lines":None,"read_error":type(exc).__name__})
            continue
        lines=text.splitlines()
        file_rows.append({"relative_path":str(rel),"bytes":path.stat().st_size,"sha256":sha256(path),"lines":len(lines),"read_error":""})
        for category,pattern in PATTERNS.items():
            rx=re.compile(pattern,re.I)
            for i,line in enumerate(lines,1):
                if rx.search(line):
                    lo=max(1,i-2); hi=min(len(lines),i+2)
                    snippet="\n".join(f"{j}: {lines[j-1]}" for j in range(lo,hi+1))
                    hit_rows.append({"category":category,"relative_path":str(rel),"line_number":i,
                                     "matched_line":line.strip(),"context_2_lines":snippet})

    files=pd.DataFrame(file_rows).sort_values("relative_path")
    hits=pd.DataFrame(hit_rows).sort_values(["category","relative_path","line_number"])
    files.to_csv(out/"v48l2a_relevant_source_manifest.csv",index=False)
    hits.to_csv(out/"v48l2a_source_contract_hits.csv",index=False)
    cat=(hits.groupby("category").agg(hits=("line_number","size"),files=("relative_path","nunique"))
         .reset_index().sort_values("category"))
    cat.to_csv(out/"v48l2a_contract_category_summary.csv",index=False)

    # Freeze schemas of direct inputs/outputs that define conventions.
    schema_paths=[
        root/"data/interim/atlas_forcedphot_standardized.csv",
        root/"results/v48_canonical/baseline/v48b_object_band_fits.csv",
        root/"results/v48_canonical/baseline/v48b_object_summary.csv",
        root/"results/v48_canonical/audit/v48c_object_band_convergence_audit_736.csv",
        root/"results/v48_canonical/injection/freeze/v48g1_proxy_templates_5.csv",
        root/"results/v48_canonical/injection/production/v48g2b_recovery_efficiency_by_mode.csv",
    ]
    schemas=[]
    for p in schema_paths:
        if p.exists():
            cols=list(pd.read_csv(p,nrows=0).columns)
            schemas.append({"relative_path":str(p.relative_to(root)),"exists":True,"columns":"|".join(cols),"sha256":sha256(p)})
        else:
            schemas.append({"relative_path":str(p.relative_to(root)),"exists":False,"columns":"","sha256":""})
    pd.DataFrame(schemas).to_csv(out/"v48l2a_method_table_schema_freeze.csv",index=False)

    # Collect compact canonical JSON/TXT contracts without modifying them.
    contract_files=[]
    for p in sorted((root/"results/v48_canonical").rglob("*")):
        if p.is_file() and p.suffix.lower() in {".json",".txt"} and re.search(r"contract|claim_box|summary",p.name,re.I):
            contract_files.append({"relative_path":str(p.relative_to(root)),"bytes":p.stat().st_size,"sha256":sha256(p)})
    pd.DataFrame(contract_files).to_csv(out/"v48l2a_existing_contract_manifest.csv",index=False)

    required=set(PATTERNS); found=set(hits.category.unique())
    missing_categories=sorted(required-found)
    summary={"version":VERSION,"relevant_source_files":len(files),"source_hits":len(hits),
             "categories_found":sorted(found),"categories_missing":missing_categories,
             "existing_canonical_outputs_modified":False,"method_claims_finalized":False,
             "next_authorized_stage":"V48L2B_BASELINE_SCATTER_REPRODUCIBILITY_CONTRACT_FREEZE"}
    (out/"v48l2a_summary.json").write_text(json.dumps(summary,indent=2),encoding="utf-8")
    report=["V48L2A_BASELINE_SCATTER_SOURCE_CONTRACT_INVENTORY_PASS",
            f"Relevant source files: {len(files)}",f"Source-contract hits: {len(hits)}",
            "Categories found: "+"|".join(sorted(found)),
            "Categories missing: "+("NONE" if not missing_categories else "|".join(missing_categories)),
            "Existing canonical outputs modified: False","Method claims finalized: False",
            "NEXT_AUTHORIZED_STAGE=V48L2B_BASELINE_SCATTER_REPRODUCIBILITY_CONTRACT_FREEZE"]
    (out/"v48l2a_report.txt").write_text("\n".join(report)+"\n",encoding="utf-8")
    print("\n".join(report)); print("\nCATEGORY SUMMARY"); print(cat.to_string(index=False))
    return 0

if __name__=="__main__": raise SystemExit(main())
