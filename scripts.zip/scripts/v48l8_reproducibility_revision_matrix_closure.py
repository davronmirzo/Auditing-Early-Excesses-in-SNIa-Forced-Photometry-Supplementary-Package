from __future__ import annotations

import argparse
import csv
import hashlib
import json
import shutil
import zipfile
from pathlib import Path

import pandas as pd

VERSION = "v48l8_reproducibility_revision_matrix_closure_1.0.0"
OUT_REL = Path("results/v48_canonical/revision/v48l8_reproducibility")


def require(ok: bool, message: str) -> None:
    if not ok:
        raise RuntimeError(message)


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def find_one(base: Path, name: str) -> Path:
    hits = sorted(base.rglob(name)) if base.exists() else []
    require(len(hits) >= 1, f"Required closure file not found: {name}")
    return hits[-1]


def read_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def copy_file(root: Path, src: Path, bundle: Path, records: list[dict], role: str) -> None:
    rel = src.relative_to(root)
    dst = bundle / rel
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)
    records.append({"relative_path": str(rel).replace("/", "\\"), "role": role,
                    "bytes": dst.stat().st_size, "sha256": sha256(dst)})


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--project-root", default=".")
    args = ap.parse_args()
    root = Path(args.project_root).resolve()
    out = root / OUT_REL
    out.mkdir(parents=True, exist_ok=True)
    revision = root / "results/v48_canonical/revision"

    # Resolve the complete major-revision evidence chain by authoritative filenames.
    l1b = find_one(revision, "v48l1b_summary.json")
    l1b2 = find_one(revision, "v48l1b2_summary.json")
    l2b = find_one(revision, "v48l2b_frozen_contract.json")
    l3 = find_one(revision, "v48l3_closure_summary.json")
    l4 = find_one(revision, "v48l4_closure_summary.json")
    l5 = find_one(revision, "v48l5_closure_summary.json")
    l6 = find_one(revision, "v48l6_closure_summary.json")
    l7 = find_one(revision, "v48l7_closure_summary.json")
    j1, j2, j3, j4, j5, j6, j7 = map(read_json, (l1b, l2b, l3, l4, l5, l6, l7))
    require(int(j2["verified_counts"]["primary_chi2_le_5_objects"]) == 277, "L2B primary count changed")
    require(int(j3["confirmed_astrophysical_detections"]) == 0, "L3 confirmed count changed")
    require(int(j4["primary_informative_cells_below_one"]) == 0, "L4 primary limit interpretation changed")
    require(j5["v40_benchmark"]["independent_validation_of_atlas_search"] is False, "L5 limitation changed")
    require(int(j6["muller_bravo_ladder"]["primary"]) == 4 and int(j6["muller_bravo_ladder"]["crossing"]) == 0, "L6 crossmatch changed")
    require(int(j7["confirmed_astrophysical_positives"]) == 0, "L7 confirmed count changed")

    parse_script = root / "scripts/04_parse_atlas_results.py"
    require(parse_script.is_file(), "Missing ATLAS parser source")
    parse_text = parse_script.read_text(encoding="utf-8", errors="replace")
    require('parser.add_argument("--max-match-sep-arcsec", type=float, default=3.0)' in parse_text,
            "Exact default 3-arcsec association radius not found")
    require("sep <= max_sep_arcsec" in parse_text and "angular_sep_arcsec" in parse_text,
            "Association-radius implementation not found")

    matrix_rows = [
        ["1", "Denominator attrition and selection bias", "PASS_ANALYSIS", "V48L1B+V48L1B2", "65 no-valid-fit, 26 high-chi2, 277 primary; cadence/coverage and local-noise proxies quantified", "PENDING_V48M1"],
        ["2", "Sign-flip and false-positive interpretation", "PASS_ANALYSIS", "V48L7", "Conditional Binomial(5,0.5), P(N+>=2)=0.8125; not a false-positive rate; zero confirmed", "PENDING_V48M1"],
        ["3", "Baseline/scatter reproducibility", "PASS_ANALYSIS", "V48L2B", "Exact flux convention, cuts, model, bounds, optimizer, multistart, scatter estimator and convergence frozen", "PENDING_V48M1"],
        ["4", "Phase and injection-calendar sensitivity", "PASS_ANALYSIS", "V48L3", "16 quality-window cells, five offsets, 20 paired calendar comparisons; mode dependence retained", "PENDING_V48M1"],
        ["5", "Population-limit sensitivity", "PASS_ANALYSIS", "V48L4", "40 modes, Beta efficiency uncertainty, two priors; all five primary frequentist f95 values equal unity", "PENDING_V48M1"],
        ["6", "Thermal proxy and SN2018oh limitations", "PASS_ANALYSIS", "V48L5", "Proxy-only interpretation; top-hat V44 disclosed; mixed-sign benchmark and ATLAS-only non-evaluable", "PENDING_V48M1"],
        ["7", "Muller-Bravo crossmatch and Liu context", "PASS_ANALYSIS", "V48L6", "17-object ladder gives four evaluable and zero crossings; Liu baseline/truncation dependence integrated", "PENDING_V48M1"],
        ["8", "Reproducibility and exact association convention", "PASS_ANALYSIS", "V48L8", "SHA256 bundle; canonical input/config/source/output chain; nearest request coordinate within 3 arcsec", "PENDING_V48M1"],
    ]
    matrix_path = out / "v48l8_referee_requirement_matrix.csv"
    with matrix_path.open("w", encoding="utf-8", newline="") as f:
        w = csv.writer(f); w.writerow(["requirement", "topic", "analysis_status", "evidence_stage", "verified_resolution", "manuscript_status"]); w.writerows(matrix_rows)

    bundle = out / "reproducibility_bundle_v1_0_0"
    if bundle.exists():
        shutil.rmtree(bundle)
    bundle.mkdir(parents=True)
    records: list[dict] = []

    # Canonical analysis input and configurations.
    required_inputs = [
        root / "data/processed/earlyrise_lightcurves.csv",
        root / "config/v48a_canonical_methods_contract.json",
        root / "config/v48g1_injection_contract.json",
        root / "config/default_config.yaml",
    ]
    for p in required_inputs:
        require(p.is_file(), f"Missing reproducibility input/config: {p}")
        copy_file(root, p, bundle, records, "canonical_input_or_config")

    # Upstream parser/merge, canonical V48 engine, crossmatch, and revision scripts.
    script_names = {"04_parse_atlas_results.py", "05_merge_cross_survey_lightcurves.py"}
    script_names.update({f"{n:02d}_{suffix}" for n, suffix in [
        (58, "freeze_v48a_canonical_methods_contract.py"), (59, "run_v48b_canonical_baseline_scatter.py"),
        (60, "run_v48c_denominator_baseline_audit.py"), (61, "run_v48d_prespecified_sensitivity.py"),
        (62, "run_v48e_point_baseline_forensics.py"), (63, "run_v48f_photometric_vetting_null.py"),
        (64, "freeze_v48g1_injection_contract.py"), (65, "validate_v48g2_full_refit_engine.py"),
        (66, "run_v48g2b_production.py")]})
    for p in sorted((root / "scripts").glob("*.py")):
        if p.name in script_names or p.name.startswith("v48"):
            copy_file(root, p, bundle, records, "analysis_source")
    require(any(r["relative_path"].endswith("59_run_v48b_canonical_baseline_scatter.py") for r in records), "Canonical baseline source not packaged")
    require(any(r["relative_path"].endswith("66_run_v48g2b_production.py") for r in records), "Canonical production source not packaged")

    # Canonical outputs and all revision evidence, excluding restart checkpoints and this live L8 directory.
    canon = root / "results/v48_canonical"
    for p in sorted(canon.rglob("*")):
        if not p.is_file():
            continue
        relc = p.relative_to(canon)
        if "checkpoints" in relc.parts or (len(relc.parts) >= 2 and relc.parts[0] == "revision" and relc.parts[1] == "v48l8_reproducibility"):
            continue
        copy_file(root, p, bundle, records, "canonical_output_or_revision_evidence")

    # The live L8 directory is excluded from recursive collection, so add the
    # completed requirement matrix explicitly without self-recursing.
    copy_file(root, matrix_path, bundle, records, "revision_requirement_matrix")

    # Optional environment locks are included when present, without fabricating one.
    for pat in ("environment*.yml", "environment*.yaml", "requirements*.txt", "pyproject.toml"):
        for p in sorted(root.glob(pat)):
            if p.is_file(): copy_file(root, p, bundle, records, "environment_specification")

    data_note = """DATA AND PROVENANCE BOUNDARY

The canonical analysis input data/processed/earlyrise_lightcurves.csv is bundled
with source_file, source_relpath, survey, coordinate-association, redshift, peak
epoch, phase, and detection columns. Raw ATLAS returned job files are not
duplicated in this package. They remain traceable through the bundled provenance
columns and the project raw-data manifest/request structure.

ATLAS association first accepts an object identifier inferred from the returned
filename when available. Otherwise, the median returned coordinate is matched to
the nearest request-table coordinate using the implemented small-angle separation
and a default maximum radius of 3.0 arcsec. Unmatched cases retain the fallback
filename stem and are not silently treated as secure coordinate associations.
"""
    note_path = bundle / "DATA_AND_PROVENANCE_BOUNDARY.txt"
    note_path.write_text(data_note, encoding="utf-8")
    records.append({"relative_path": "DATA_AND_PROVENANCE_BOUNDARY.txt", "role": "documentation", "bytes": note_path.stat().st_size, "sha256": sha256(note_path)})

    readme = """V48 CANONICAL REPRODUCIBILITY BUNDLE

Authoritative sequence
1. Freeze eligibility and methods (V48A).
2. Run band-wise baseline/scatter fits (V48B).
3. Audit denominator and raw crossings (V48C).
4. Evaluate phase/window sensitivities (V48D).
5. Perform point and baseline-influence forensics (V48E).
6. Run targeted raw-quality and conditional sign-reversal diagnostics (V48F).
7. Freeze, validate, and run injection recovery (V48G1/G2A/G2B).
8. Compute mode-resolved population limits (V48G2C).
9. Perform external candidate crossmatch (V48I1/I2).
10. Apply revision claim closures (V48L1-L8).

The historical denominator 219 and V44 transport are noncanonical context only.
The authoritative population denominator is 277. No physical-channel occurrence
interpretation is authorized for the phenomenological proxy limits.

Use v48l8_sha256_manifest.csv to verify every bundled file before reproduction.
"""
    readme_path = bundle / "README_REPRODUCIBILITY.txt"
    readme_path.write_text(readme, encoding="utf-8")
    records.append({"relative_path": "README_REPRODUCIBILITY.txt", "role": "documentation", "bytes": readme_path.stat().st_size, "sha256": sha256(readme_path)})

    manifest_path = bundle / "v48l8_sha256_manifest.csv"
    with manifest_path.open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["relative_path", "role", "bytes", "sha256"]); w.writeheader(); w.writerows(records)

    zip_path = out / "V48L8_CANONICAL_REPRODUCIBILITY_BUNDLE.zip"
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for p in sorted(bundle.rglob("*")):
            if p.is_file(): z.write(p, p.relative_to(bundle.parent))
    require(zip_path.is_file() and zip_path.stat().st_size > 0, "Reproducibility ZIP was not created")

    closure = {
        "version": VERSION,
        "requirements_total": len(matrix_rows),
        "analysis_requirements_pass": sum(r[2] == "PASS_ANALYSIS" for r in matrix_rows),
        "manuscript_requirements_integrated": 0,
        "manuscript_integration_status": "PENDING_V48M1",
        "association_radius_arcsec": 3.0,
        "association_rule": "filename object ID when available; otherwise nearest request-table coordinate within 3 arcsec using implemented small-angle separation",
        "bundle_files_excluding_manifest": len(records),
        "bundle_bytes_excluding_manifest": int(sum(r["bytes"] for r in records)),
        "reproducibility_zip": zip_path.name,
        "raw_atlas_jobs_duplicated": False,
        "canonical_input_bundled": True,
        "sha256_manifest_created": True,
        "scientific_calculations_executed": False,
        "canonical_outputs_modified": False,
        "revision_analysis_closure_pass": True,
        "submission_ready": False,
        "next_authorized_stage": "V48M1_CONTROLLED_MANUSCRIPT_AND_RESPONSE_INTEGRATION",
    }
    (out / "v48l8_closure_summary.json").write_text(json.dumps(closure, indent=2), encoding="utf-8")

    final_claim = """V48L8 freezes the evidence chain and reproducibility package only. It does not assert that the manuscript has already been revised. All manuscript and response-letter insertions remain pending for V48M1, where only approved additions will be bolded and unchanged text will be preserved verbatim.
"""
    (out / "v48l8_manuscript_boundary.txt").write_text(final_claim, encoding="utf-8")
    report = [
        "V48L8_REPRODUCIBILITY_PACKAGE_AND_REVISION_MATRIX_CLOSURE_PASS",
        f"Analysis requirements passed: {len(matrix_rows)}/{len(matrix_rows)}",
        "Manuscript requirements integrated: 0/8 (pending V48M1)",
        "ATLAS coordinate association radius: 3.0 arcsec",
        f"Bundle files/bytes excluding manifest: {len(records)}/{sum(r['bytes'] for r in records)}",
        "Canonical input bundled: True",
        "Raw ATLAS jobs duplicated: False",
        "SHA256 manifest created: True",
        "Scientific calculations executed: False",
        "Canonical outputs modified: False",
        "Submission ready: False",
        "NEXT_AUTHORIZED_STAGE=V48M1_CONTROLLED_MANUSCRIPT_AND_RESPONSE_INTEGRATION",
    ]
    (out / "v48l8_report.txt").write_text("\n".join(report) + "\n", encoding="utf-8")
    print("\n".join(report))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
