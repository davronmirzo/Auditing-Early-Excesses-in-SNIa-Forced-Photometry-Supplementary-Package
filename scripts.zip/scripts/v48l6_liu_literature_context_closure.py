from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd

VERSION = "v48l6_liu_literature_context_closure_1.0.0"
OUT_REL = Path("results/v48_canonical/revision/v48l6_literature_context")


def require(ok: bool, message: str) -> None:
    if not ok:
        raise RuntimeError(message)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--project-root", default=".")
    args = ap.parse_args()
    root = Path(args.project_root).resolve()
    out = root / OUT_REL
    out.mkdir(parents=True, exist_ok=True)

    base = root / "results/v48_canonical/external_crossmatch/muller_bravo"
    ladder_path = base / "v48i2_muller_bravo_ladder_counts.csv"
    attr_path = base / "v48i2_muller_bravo_attrition_summary.csv"
    object_path = base / "v48i2_muller_bravo_object_level_crossmatch_17.csv"
    audit_path = base / "v48i2_crossmatch_audit.json"
    for p in (ladder_path, attr_path, object_path, audit_path):
        require(p.is_file(), f"Missing Müller-Bravo crossmatch input: {p}")

    ladder = pd.read_csv(ladder_path)
    attr = pd.read_csv(attr_path)
    objects = pd.read_csv(object_path)
    audit = json.loads(audit_path.read_text(encoding="utf-8"))
    counts = dict(zip(ladder["stage"].astype(str), pd.to_numeric(ladder["objects"]).astype(int)))
    expected = {"published": 17, "request": 13, "raw": 9, "assoc": 9, "coverage": 9,
                "native": 4, "fit": 4, "primary": 4, "crossing": 0, "confirmed": 0}
    require(counts == expected, f"Crossmatch ladder changed: {counts}")
    require(len(objects) == 17 and objects["published_ztf_name"].nunique() == 17, "Object table is not 17 unique candidates")
    reasons = dict(zip(attr["attrition_reason"].astype(str), pd.to_numeric(attr["objects"]).astype(int)))
    expected_reasons = {"failed_strict_native_band_gate": 5, "no_standardized_atlas_photometry": 4,
                        "not_in_atlas_request_manifest": 4, "passed_denominator_no_raw_eeri_crossing": 4}
    require(reasons == expected_reasons, f"Attrition reasons changed: {reasons}")
    require(audit.get("obsolete_219_used") is False, "Obsolete 219 denominator was used")
    require(int(audit.get("canonical_primary_denominator_size")) == 277, "Canonical denominator changed")

    source_snapshot = {
        "verified_on_utc": "2026-08-18",
        "muller_bravo_2026": {
            "title": "ZTF SN Ia DR2 follow-up: early excess in Type Ia supernova light curves",
            "arxiv": "2607.22050",
            "version_reviewed": "v2 (2026-08-04)",
            "status": "accepted in Astronomy & Astrophysics",
            "sample_claim": "17 robust early-excess candidates after combining methods",
            "method_context": "power-law/SALT2 residual searches plus double-detonation and companion-interaction comparisons; methods disagree substantially",
            "physical_interpretation": "no compelling preference between the two tested physical scenarios",
            "primary_source": "https://arxiv.org/abs/2607.22050",
            "crossmatch_catalogue_freeze": "v1 Table 5; object-level EERI ladder already frozen in V48I1/V48I2",
        },
        "liu_2026": {
            "title": "Decoding the Early-Time Light Curves of Type Ia Supernovae. II. Population Parameters of One Thousand ZTF Supernovae",
            "arxiv": "2607.00081",
            "sample": "972 normal SNe Ia from the volume-complete ZTF DR2 sample",
            "method_context": "hierarchical Bayesian power-law fits to data up to 30 percent of peak flux",
            "relevant_result": "rise fits are sensitive to truncation when data beyond about 40 percent of peak are included and generally converge when restricted earlier",
            "interpretive_context": "rise morphology and early colour depend on stretch regime; some long-duration excess-like behaviour is tied to shallow high-stretch rises",
            "primary_source": "https://arxiv.org/abs/2607.00081",
        },
    }
    (out / "v48l6_primary_source_snapshot.json").write_text(json.dumps(source_snapshot, indent=2), encoding="utf-8")

    crossmatch = {
        "version": VERSION,
        "muller_bravo_ladder": expected,
        "attrition_reasons": expected_reasons,
        "fraction_published_reaching_primary": 4 / 17,
        "fraction_published_with_raw_eeri_crossing": 0.0,
        "fraction_published_confirmed_by_eeri": 0.0,
        "interpretation": "Only four of 17 published candidates are evaluable in the canonical EERI denominator; none crosses the raw EERI rule. This is an attrition-aware method comparison, not evidence that the other catalogue is false and not a complete recovery fraction for its candidates.",
        "physical_channel_occurrence_interpretation_authorized": False,
        "literature_claims_frozen": True,
        "new_crossmatch_or_scientific_fit_executed": False,
        "canonical_outputs_modified": False,
        "next_authorized_stage": "V48L7_SIGN_FLIP_AND_FALSE_POSITIVE_INTERPRETATION_CLOSURE",
    }
    (out / "v48l6_closure_summary.json").write_text(json.dumps(crossmatch, indent=2), encoding="utf-8")

    bib = r"""@article{MullerBravo2026,
  author        = {M{\"u}ller-Bravo, Tom{\'a}s E. and Maguire, Kate and Alburai, Alaa and Burgaz, Umut and Dimitriadis, Georgios and Galbany, Llu{\'i}s and Johansson, Joel and Kim, Young-Lo and Liu, Chang and Miller, Adam A. and Smith, Mathew and Sollerman, Jesper and Bellm, Eric C. and Castaneda Jaimes, Joahan and Kasliwal, Mansi M. and Laher, Russ R. and Smith, Roger and Sravan, Niharika},
  title         = {{ZTF SN Ia DR2 follow-up: early excess in Type Ia supernova light curves}},
  year          = {2026},
  eprint        = {2607.22050},
  archivePrefix = {arXiv},
  primaryClass  = {astro-ph.CO},
  doi           = {10.48550/arXiv.2607.22050},
  note          = {Accepted in Astronomy \& Astrophysics}
}

@article{Liu2026EarlyRiseII,
  author        = {Liu, Chang and Miller, Adam A. and Sarin, Nikhil and Maguire, Kate and M{\"u}ller-Bravo, Tom{\'a}s E. and Chen, Ping and Galbany, L. and Kim, Young-Lo and Sollerman, Jesper and Bellm, Eric C. and Castaneda Jaimes, Joahan and Chen, Tracy X. and Graham, Matthew J. and Hale, David and Kasliwal, Mansi M. and Purdum, Josiah},
  title         = {{Decoding the Early-Time Light Curves of Type Ia Supernovae. II. Population Parameters of One Thousand ZTF Supernovae}},
  year          = {2026},
  eprint        = {2607.00081},
  archivePrefix = {arXiv},
  primaryClass  = {astro-ph.HE},
  doi           = {10.48550/arXiv.2607.00081}
}
"""
    (out / "v48l6_verified_references.bib").write_text(bib, encoding="utf-8")

    manuscript = """**Recent ZTF DR2 context and catalogue crossmatch.** **Müller-Bravo et al. (2026) searched the same broad ZTF DR2 parent population using complementary empirical residual and physical-model comparisons. Their methods disagree substantially at the candidate level, but their combined selection identifies 17 robust early-excess candidates and does not favour a unique double-detonation or companion-interaction origin. This method dependence is directly relevant to EERI: our criterion is an ATLAS-native, band-night residual decision rule with its own coverage, passband, and denominator requirements, rather than a reproduction of their ZTF-based selectors.**

**We passed all 17 Müller-Bravo et al. candidates through the frozen EERI ladder. Thirteen appear in the ATLAS request manifest, nine have usable standardized ATLAS photometry and secure ZTF associations with early coverage, four pass the strict native-band gate, and the same four have valid fits and enter the canonical 277-object denominator. None of those four produces a raw EERI crossing, and none is a confirmed EERI detection. The remaining attrition comprises four objects absent from the request manifest, four without standardized ATLAS photometry, and five failing the strict native-band gate. Because only four published candidates are evaluable, this comparison is not a complete recovery fraction for the Müller-Bravo catalogue and does not invalidate candidates excluded by EERI coverage or gate requirements.**

**Liu et al. (2026) independently characterize the early rises of 972 normal ZTF DR2 SNe Ia with hierarchical power-law models. They show that inferred rise parameters depend on the fitted light-curve extent when data beyond approximately 40 per cent of peak are included, while fits generally converge when restricted to earlier epochs; they also find stretch-dependent rise and colour behaviour. Their results reinforce two boundaries of the present analysis: a residual excess is defined relative to a specified baseline and phase interval, and broad excess-like structure can covary with smooth-rise morphology. EERI therefore reports baseline, phase, alpha-refit, and calendar sensitivities explicitly and does not treat a residual crossing as a model-independent physical classification.**
"""
    (out / "v48l6_manuscript_insertion_bold.txt").write_text(manuscript, encoding="utf-8")
    response = """**Response — recent ZTF DR2 studies.** **We have added both Müller-Bravo et al. (2026) and Liu et al. (2026). For Müller-Bravo et al., we performed the requested object-level crossmatch through the complete frozen EERI ladder: 17 published candidates become 13 ATLAS requests, nine usable/secure/covered objects, four strict-native/valid-fit/canonical-denominator objects, and zero raw or confirmed EERI crossings. We provide every object and its first attrition reason and emphasize that the four evaluable objects do not constitute a complete catalogue-recovery experiment. We use Liu et al. to place our baseline and phase sensitivities in the appropriate context: early-rise parameters and excess-like structure depend on the fitted interval, smooth-rise model, and stretch regime. We consequently avoid presenting EERI residual crossings as model-independent physical classifications.**
"""
    (out / "v48l6_response_letter_text_bold.txt").write_text(response, encoding="utf-8")
    (out / "v48l6_allowed_claims.txt").write_text(
        "ALLOWED CLAIMS\n- Report the exact 17->13->9->9->9->4->4->4->0->0 ladder.\n- State that four candidates are evaluable and none crosses the EERI rule.\n- Attribute the null overlap partly to coverage/gate/method differences.\n- Use Liu et al. to motivate explicit baseline and fitted-interval dependence.\n- Describe the studies as complementary analyses of the broad ZTF DR2 population.\n", encoding="utf-8")
    (out / "v48l6_prohibited_claims.txt").write_text(
        "PROHIBITED CLAIMS\n- Do not claim EERI disproves the Müller-Bravo candidates.\n- Do not quote 0/17 as an EERI recovery efficiency; only four are evaluable.\n- Do not imply identical passbands, coverage, baselines, or candidate rules.\n- Do not say Liu et al. establishes one unique early-rise model.\n- Do not infer a physical-channel occurrence rate from the crossmatch.\n", encoding="utf-8")

    report = [
        "V48L6_LIU_2026_AND_LITERATURE_CONTEXT_CLOSURE_PASS",
        "Muller-Bravo ladder: 17/13/9/9/9/4/4/4/0/0",
        "Attrition: request-absent/raw-missing/native-fail/primary-no-crossing = 4/4/5/4",
        "Muller-Bravo candidates evaluable in canonical EERI denominator: 4/17",
        "Raw/confirmed EERI crossings among evaluable candidates: 0/0",
        "Liu et al. sample: 972 normal ZTF DR2 SNe Ia",
        "Baseline/fitted-interval model dependence acknowledged: True",
        "Physical-channel occurrence interpretation authorized: False",
        "New crossmatch or scientific fit executed: False",
        "Canonical outputs modified: False",
        "Literature claims frozen: True",
        "NEXT_AUTHORIZED_STAGE=V48L7_SIGN_FLIP_AND_FALSE_POSITIVE_INTERPRETATION_CLOSURE",
    ]
    (out / "v48l6_report.txt").write_text("\n".join(report) + "\n", encoding="utf-8")
    print("\n".join(report))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
