from __future__ import annotations

import argparse
import hashlib
import json
import math
import platform
import time
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from scipy.optimize import least_squares


VERSION = "v48g2a_full_refit_engine_validation_1.0.2"
STATUS = "V48G2A_FULL_REFIT_ENGINE_VALIDATION_COMPLETE"


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def truthy(series: pd.Series) -> pd.Series:
    return series.astype(str).str.strip().str.lower().isin({"true", "1", "yes", "y", "t"})


def model(t_rel: np.ndarray, amp: float, t0_rel: float, alpha: float) -> np.ndarray:
    return float(amp) * np.power(np.maximum(np.asarray(t_rel, float) - float(t0_rel), 0.0), float(alpha))


def robust_scale(raw_residual: np.ndarray, formal: np.ndarray) -> float:
    good = np.isfinite(raw_residual) & np.isfinite(formal) & (formal > 0)
    if not np.any(good):
        return 0.0
    r = np.asarray(raw_residual, float)[good]
    f = np.asarray(formal, float)[good]
    mad = 1.4826 * float(np.median(np.abs(r - np.median(r))))
    fmed = float(np.median(f))
    return float(math.sqrt(max(mad * mad - fmed * fmed, 0.0))) if np.isfinite(mad + fmed) else 0.0


def fit_once(t: np.ndarray, y: np.ndarray, eff: np.ndarray, cfg: dict[str, Any],
             alpha_mode: str, pre_alpha: float, init: dict[str, float] | None) -> dict[str, Any]:
    tref = float(np.min(t)); tr = np.asarray(t, float) - tref
    yscale = max(float(np.nanpercentile(np.abs(y), 90)), float(np.nanmedian(eff)), 1.0)
    t0_lo = float(cfg["t0_relative_bounds_days"][0]); t0_hi = min(5.0, float(np.min(tr)) + 2.0)
    alo, ahi = map(float, cfg["alpha_bounds"])
    starts = cfg["multistart_t0_guesses_days"] if init is None else [float(init["t0_rel"])]
    best: dict[str, Any] | None = None
    for t0g0 in starts:
        t0g = float(np.clip(float(t0g0), t0_lo + 1e-8, t0_hi - 1e-8))
        alpha0 = float(pre_alpha if alpha_mode == "fixed-to-pre-injection" else (cfg["initial_alpha"] if init is None else init["alpha"]))
        base = max(float(np.max(tr) - t0g), 1.0)
        amp0 = max(float(np.nanmax(y)) / base ** alpha0, 1e-8) if init is None else max(float(init["amp"]), 1e-8)
        if alpha_mode == "free":
            p0 = np.array([amp0, t0g, alpha0]); lo = np.array([1e-14, t0_lo, alo]); hi = np.array([max(1e6 * yscale, 1.0), t0_hi, ahi])
            unpack = lambda p: (float(p[0]), float(p[1]), float(p[2]))
        elif alpha_mode == "fixed-to-pre-injection":
            p0 = np.array([amp0, t0g]); lo = np.array([1e-14, t0_lo]); hi = np.array([max(1e6 * yscale, 1.0), t0_hi])
            unpack = lambda p: (float(p[0]), float(p[1]), float(pre_alpha))
        else:
            raise ValueError(alpha_mode)

        def residual(p: np.ndarray) -> np.ndarray:
            amp, t0r, alpha = unpack(p)
            return (y - model(tr, amp, t0r, alpha)) / eff

        try:
            result = least_squares(residual, p0, bounds=(lo, hi), loss=str(cfg["robust_loss"]),
                                   f_scale=float(cfg["robust_f_scale"]), max_nfev=int(cfg["maximum_function_evaluations"]))
            amp, t0r, alpha = unpack(result.x)
            candidate = {"success": bool(result.success and np.all(np.isfinite(result.x))), "message": str(result.message)[:200],
                         "cost": float(result.cost), "amp": amp, "t0_rel": t0r, "alpha": alpha, "nfev": int(result.nfev)}
        except Exception as exc:  # noqa: BLE001
            candidate = {"success": False, "message": str(exc)[:200], "cost": np.inf}
        if best is None or candidate["cost"] < best["cost"]:
            best = candidate
    assert best is not None
    best["t_ref"] = tref; best["t0"] = tref + float(best.get("t0_rel", np.nan))
    return best


def refit_band(g: pd.DataFrame, injected_flux: np.ndarray, cfg: dict[str, Any], alpha_mode: str,
               prefit: pd.Series, scatter_policy: str) -> dict[str, Any]:
    g = g.sort_values("mjd")
    t = g["mjd"].to_numpy(float); formal = g["fluxerr"].to_numpy(float); y = np.asarray(injected_flux, float)
    scatter = float(prefit["extra_scatter"]); converged = scatter_policy == "frozen-pre-injection"
    best: dict[str, Any] | None = None; iterations = 0
    maximum = 1 if scatter_policy == "frozen-pre-injection" else 20
    for iteration in range(1, maximum + 1):
        iterations = iteration
        eff = np.sqrt(formal * formal + scatter * scatter)
        # The first post-injection fit must replay the five frozen V48A t0 starts.
        # Later scatter iterations warm-start from the preceding optimum.
        init = None if best is None else best
        best = fit_once(t, y, eff, cfg, alpha_mode, float(prefit["alpha"]), init)
        if not best["success"] or scatter_policy == "frozen-pre-injection":
            break
        pred = model(t - best["t_ref"], best["amp"], best["t0_rel"], best["alpha"])
        new_scatter = robust_scale(y - pred, formal)
        scale = max(abs(scatter), abs(new_scatter), 1e-8)
        if abs(new_scatter - scatter) / scale <= 1e-4:
            scatter = new_scatter; converged = True; break
        scatter = new_scatter
    assert best is not None
    if best["success"] and scatter_policy == "reestimated-post-injection":
        best = fit_once(t, y, np.sqrt(formal * formal + scatter * scatter), cfg, alpha_mode, float(prefit["alpha"]), best)
    if not best["success"]:
        return {"success": False, "scatter": scatter, "scatter_converged": converged, "scatter_iterations": iterations}
    pred = model(t - best["t_ref"], best["amp"], best["t0_rel"], best["alpha"])
    residual_sigma = (y - pred) / np.sqrt(formal * formal + scatter * scatter)
    return {"success": True, "t0": best["t0"], "alpha": best["alpha"], "amplitude": best["amp"], "scatter": scatter,
            "scatter_converged": converged, "scatter_iterations": iterations, "residual_sigma": residual_sigma}


def recovered(blocks: pd.DataFrame) -> bool:
    if blocks.empty: return False
    maxima = blocks.groupby(["band", "night"])["residual_sigma"].max().to_numpy(float)
    return bool(np.any(maxima > 5.0) or np.sum(maxima > 3.0) >= 2)


def main() -> int:
    ap = argparse.ArgumentParser(); ap.add_argument("--root", default="."); ap.add_argument("--hosts", type=int, default=2)
    args = ap.parse_args(); root = Path(args.root).resolve()
    paths = {
        "methods": root / "config/v48a_canonical_methods_contract.json",
        "contract": root / "config/v48g1_injection_contract.json",
        "freeze": root / "results/v48_canonical/injection/freeze/v48g1_injection_contract_freeze.json",
        "hosts": root / "results/v48_canonical/injection/freeze/v48g1_injection_hosts_272.csv",
        "fits": root / "results/v48_canonical/baseline/v48b_object_band_fits.csv",
        "lightcurves": root / "data/processed/earlyrise_lightcurves.csv",
    }
    for path in paths.values():
        if not path.is_file(): raise FileNotFoundError(path)
    methods = json.loads(paths["methods"].read_text(encoding="utf-8")); contract = json.loads(paths["contract"].read_text(encoding="utf-8"))
    freeze = json.loads(paths["freeze"].read_text(encoding="utf-8"))
    if freeze.get("status") != "V48G1_CANONICAL_INJECTION_CONTRACT_FROZEN" or freeze.get("contract_sha256") != sha256(paths["contract"]):
        raise RuntimeError("V48G1 freeze gate/hash is not valid")
    host_all = pd.read_csv(paths["hosts"])["object_id"].astype(str).tolist()
    ranked = sorted(host_all, key=lambda oid: hashlib.sha256(f"{contract['random_seed']}|G2A|{oid}".encode()).hexdigest())
    host_ids = ranked[:args.hosts]
    fits = pd.read_csv(paths["fits"]); fits = fits[truthy(fits["valid_fit"]) & fits["object_id"].astype(str).isin(host_ids)].copy()
    d = pd.read_csv(paths["lightcurves"], low_memory=False)
    for col in ("mjd", "flux", "fluxerr", "redshift", "rest_phase"): d[col] = pd.to_numeric(d[col], errors="coerce")
    d["object_id"] = d["object_id"].astype(str); d["band"] = d["band"].astype(str).str.lower()
    lo, hi = methods["eligibility"]["phase_window_days"]
    d = d[d["object_id"].isin(host_ids) & d["band"].isin({"c", "o"}) & d["mjd"].notna() & d["flux"].notna() & d["fluxerr"].gt(0) & d["rest_phase"].between(lo, hi, inclusive="both")].copy()
    templates = contract["templates"]; alpha_modes = contract["mode_grid"]["alpha_refit_modes"]
    calendar_modes = contract["mode_grid"]["calendar_modes"]
    scatter_modes = ["frozen-pre-injection", "reestimated-post-injection"]
    rows: list[dict[str, Any]] = []; start = time.perf_counter()
    for oid in host_ids:
        ofits = fits[fits["object_id"] == oid].copy(); z = float(d.loc[d["object_id"] == oid, "redshift"].median()); z = z if np.isfinite(z) else 0.0
        shared_anchor = float(ofits["t0"].median())
        for template in templates:
            for alpha_mode in alpha_modes:
                for calendar_mode in calendar_modes:
                    for scatter_policy in scatter_modes:
                        # Scatter sensitivity is paired: both policies receive exactly the same injection.
                        seed_text = f"{contract['random_seed']}|G2A|{oid}|{template['template_id']}|{alpha_mode}|{calendar_mode}"
                        rng = np.random.default_rng(int(hashlib.sha256(seed_text.encode()).hexdigest()[:16], 16))
                        phase_jitter = float(rng.normal(0.0, contract["phase_jitter_days"]))
                        amplitude_jitter = float(max(0.0, rng.normal(1.0, contract["amplitude_jitter_fraction"])))
                        point_parts = []; band_success = True; fixed_ok = True; peak_mjds = []
                        for prefit in ofits.itertuples(index=False):
                            g = d[(d["object_id"] == oid) & (d["band"] == prefit.band)].sort_values("mjd").copy()
                            anchor = shared_anchor if calendar_mode == "shared-physical-date" else float(prefit.t0)
                            peak_mjd = anchor + (float(template["phase_peak_days"]) + phase_jitter) * (1.0 + z); peak_mjds.append(peak_mjd)
                            width_obs = float(template["width_days"]) * (1.0 + z)
                            scale = float(template["c_scale"] if prefit.band == "c" else template["o_scale"])
                            eff_pre = np.sqrt(g["fluxerr"].to_numpy(float) ** 2 + float(prefit.extra_scatter) ** 2)
                            bump = float(template["peak_sigma"]) * scale * amplitude_jitter * float(np.median(eff_pre)) * np.exp(-0.5 * ((g["mjd"].to_numpy(float) - peak_mjd) / width_obs) ** 2)
                            result = refit_band(g, g["flux"].to_numpy(float) + bump, methods["baseline"], alpha_mode, pd.Series(prefit._asdict()), scatter_policy)
                            if not result["success"]: band_success = False; continue
                            fixed_ok = fixed_ok and (alpha_mode != "fixed-to-pre-injection" or abs(float(result["alpha"]) - float(prefit.alpha)) < 1e-12)
                            phase = (g["mjd"].to_numpy(float) - float(result["t0"])) / (1.0 + z)
                            q = pd.DataFrame({"band": prefit.band, "night": np.floor(g["mjd"]).astype(int), "residual_sigma": result["residual_sigma"]})
                            point_parts.append(q[(phase >= contract["signal_window_days"][0]) & (phase <= contract["signal_window_days"][1])])
                        blocks = pd.concat(point_parts, ignore_index=True) if point_parts else pd.DataFrame()
                        rows.append({"object_id": oid, "template_id": template["template_id"], "alpha_refit_mode": alpha_mode,
                                     "calendar_mode": calendar_mode, "scatter_policy": scatter_policy, "phase_jitter_days": phase_jitter,
                                     "amplitude_jitter_factor": amplitude_jitter, "valid_band_refits": len(point_parts), "all_band_refits_success": band_success,
                                     "fixed_alpha_invariant": fixed_ok, "peak_mjd_span_days": float(max(peak_mjds) - min(peak_mjds)) if peak_mjds else np.nan,
                                     "recovered": recovered(blocks), "n_signal_blocks": int(len(blocks.groupby(["band", "night"]))) if len(blocks) else 0})
    elapsed = time.perf_counter() - start
    trials = pd.DataFrame(rows)
    expected = args.hosts * len(templates) * len(alpha_modes) * len(calendar_modes) * len(scatter_modes)
    paired = trials.groupby(["object_id", "template_id", "alpha_refit_mode", "calendar_mode"]).agg(
        phase_values=("phase_jitter_days", "nunique"), amplitude_values=("amplitude_jitter_factor", "nunique"))
    checks = {
        "expected_trial_count": len(trials) == expected,
        "all_refits_success": bool(trials["all_band_refits_success"].all()),
        "fixed_alpha_exact": bool(trials.loc[trials["alpha_refit_mode"] == "fixed-to-pre-injection", "fixed_alpha_invariant"].all()),
        "shared_calendar_common_peak": bool((trials.loc[trials["calendar_mode"] == "shared-physical-date", "peak_mjd_span_days"] < 1e-9).all()),
        "both_scatter_policies_exercised": set(trials["scatter_policy"]) == set(scatter_modes),
        "scatter_sensitivity_uses_paired_injections": bool((paired["phase_values"] == 1).all() and (paired["amplitude_values"] == 1).all()),
        "deterministic_trial_keys_unique": not trials.duplicated(["object_id", "template_id", "alpha_refit_mode", "calendar_mode", "scatter_policy"]).any(),
    }
    gate = bool(all(checks.values()))
    per_trial = elapsed / max(len(trials), 1); total_trials = 163200 + 30000
    out = root / "results/v48_canonical/injection/engine_validation"; out.mkdir(parents=True, exist_ok=True)
    trials.to_csv(out / "v48g2a_engine_validation_trials.csv", index=False)
    summary = {"status": STATUS, "version": VERSION, "gate_pass": gate, "checks": checks, "validation_hosts": host_ids,
               "validation_trials": len(trials), "elapsed_seconds": elapsed, "seconds_per_trial": per_trial,
               "projected_193200_trial_serial_hours": per_trial * total_trials / 3600.0,
               "platform": platform.platform(), "python": platform.python_version(), "injection_recovery_production_executed": False,
               "population_limits_computed": False, "archived_outputs_overwritten": False,
               "next_authorized_stage": "V48G2B_193200_TRIAL_PRODUCTION_RUN" if gate else "NONE_ENGINE_VALIDATION_FAILED"}
    (out / "v48g2a_engine_validation_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    lines = [STATUS, "V48G2A_FULL_REFIT_ENGINE_GATE_PASS" if gate else "V48G2A_FULL_REFIT_ENGINE_GATE_FAIL",
             f"Validation hosts/trials: {len(host_ids)}/{len(trials)}", f"All injected object-band refits succeeded: {checks['all_refits_success']}",
             f"Fixed-alpha invariant: {checks['fixed_alpha_exact']}", f"Shared-calendar invariant: {checks['shared_calendar_common_peak']}",
             f"Frozen/re-estimated scatter modes exercised: {checks['both_scatter_policies_exercised']}",
             f"Scatter sensitivity uses paired injections: {checks['scatter_sensitivity_uses_paired_injections']}",
             f"Benchmark seconds/trial: {per_trial:.6f}", f"Projected serial runtime for 193200 trials (hours): {per_trial * total_trials / 3600.0:.3f}",
             "Production injection executed: False", "Population limits computed: False", "Archived 219/v44 outputs overwritten: False",
             f"NEXT_AUTHORIZED_STAGE={summary['next_authorized_stage']}"]
    (out / "v48g2a_engine_validation_claim_box.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print("\n".join(lines)); return 0 if gate else 2


if __name__ == "__main__": raise SystemExit(main())
