from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd


PASS = "V48A_CANONICAL_METHODS_CONTRACT_FROZEN"


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=".")
    args = ap.parse_args()
    root = Path(args.root).resolve()
    contract_path = root / "config" / "v48a_canonical_methods_contract.json"
    lc_path = root / "data" / "processed" / "earlyrise_lightcurves.csv"
    v47_path = root / "results" / "tables" / "v47_stage5_provenance_adjudication.json"
    for p in (contract_path, lc_path, v47_path):
        if not p.is_file():
            raise FileNotFoundError(p)
    contract = json.loads(contract_path.read_text(encoding="utf-8"))
    v47 = json.loads(v47_path.read_text(encoding="utf-8"))
    if v47.get("decision") != "V47_EXACT_STAGE5_REPLAY_IMPOSSIBLE_FROM_CURRENT_ARCHIVE":
        raise RuntimeError("V47 forensic adjudication gate is not closed")

    d = pd.read_csv(lc_path, low_memory=False)
    required = {"object_id", "mjd", "band", "flux", "fluxerr", "rest_phase"}
    missing = sorted(required - set(d.columns))
    if missing:
        raise ValueError(f"Missing light-curve columns: {missing}")
    for c in ("mjd", "flux", "fluxerr", "rest_phase"):
        d[c] = pd.to_numeric(d[c], errors="coerce")
    d["object_id"] = d["object_id"].astype(str).str.strip()
    d["band"] = d["band"].astype(str).str.strip().str.lower()
    lo, hi = contract["eligibility"]["phase_window_days"]
    native = set(contract["eligibility"]["native_bands"])
    valid = d["mjd"].notna() & d["flux"].notna() & d["fluxerr"].gt(0) & d["rest_phase"].between(lo, hi, inclusive="both") & d["band"].isin(native)
    q = d.loc[valid].copy()
    q["detection"] = (q["flux"] / q["fluxerr"]) >= 3.0
    g = q.groupby("object_id", sort=True).agg(
        n_valid_native_rows=("mjd", "size"),
        n_native_detections=("detection", "sum"),
        n_native_bands_with_rows=("band", "nunique"),
    )
    eligible = g[(g["n_native_detections"] >= int(contract["eligibility"]["minimum_total_native_band_detections"])) & (g["n_native_bands_with_rows"] == len(native))].copy()
    expected = int(contract["eligibility"]["expected_eligible_objects"])
    if len(eligible) != expected:
        raise RuntimeError(f"Eligibility contract mismatch: observed={len(eligible)} expected={expected}")

    out = root / "results" / "v48_canonical" / "freeze"
    out.mkdir(parents=True, exist_ok=True)
    eligible.reset_index().to_csv(out / "v48a_eligible_native_co_368.csv", index=False)
    summary = {
        "status": PASS,
        "contract_version": contract["version"],
        "contract_sha256": sha256(contract_path),
        "input_sha256": sha256(lc_path),
        "v47_adjudication_sha256": sha256(v47_path),
        "input_rows": int(len(d)),
        "input_objects": int(d["object_id"].nunique()),
        "valid_native_rows_in_phase_window": int(len(q)),
        "eligible_native_co_objects": int(len(eligible)),
        "archived_outputs_overwritten": False,
        "new_science_fit_executed": False,
        "new_injection_recovery_executed": False
    }
    (out / "v48a_methods_contract_freeze.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    lines = [
        PASS,
        f"Contract version: {contract['version']}",
        f"Input rows/objects: {len(d)}/{d['object_id'].nunique()}",
        f"Native c/o eligible objects: {len(eligible)}",
        "New science fit executed: False",
        "New injection-recovery executed: False",
        "Archived 219/v44 outputs overwritten: False",
        "NEXT_AUTHORIZED_STAGE=V48B_CANONICAL_BASELINE_AND_SCATTER_RERUN"
    ]
    (out / "v48a_methods_contract_claim_box.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print("\n".join(lines))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
