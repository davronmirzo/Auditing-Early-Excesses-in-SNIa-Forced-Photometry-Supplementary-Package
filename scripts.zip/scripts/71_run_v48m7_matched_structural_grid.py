from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd


VERSION = "v48m7_matched_structural_grid_1.0.0"
EXPECTED_ARCHIVE_ROWS = 43050
EXPECTED_CANDIDATE_ROWS = 455
EXPECTED_CANDIDATE_HOSTS = 9
MOD: Any = None

UNIQUE_CONFIGS = {
    "primary": (-0.5, 6.0, 0.0, "raw_primary"),
    "window_0_6": (0.0, 6.0, 0.0, "window_0p0_6p0"),
    "window_m0p5_5": (-0.5, 5.0, 0.0, "window_m0p5_5p0"),
    "window_m1_6": (-1.0, 6.0, 0.0, "window_m1p0_6p0"),
    "phase_m0p5": (-0.5, 6.0, -0.5, "phase_offset_m0p5"),
    "phase_m0p25": (-0.5, 6.0, -0.25, "phase_offset_m0p25"),
    "phase_p0p25": (-0.5, 6.0, 0.25, "phase_offset_0p25"),
    "phase_p0p5": (-0.5, 6.0, 0.5, "phase_offset_0p5"),
}

AXIS_CONFIGS = [
    ("quality_threshold", "chi2_dof_le_3", "primary", 3.0),
    ("quality_threshold", "chi2_dof_le_5", "primary", 5.0),
    ("quality_threshold", "chi2_dof_le_7", "primary", 7.0),
    ("quality_threshold", "chi2_dof_le_10", "primary", 10.0),
    ("signal_window", "window_-0.5_6", "primary", 5.0),
    ("signal_window", "window_0_6", "window_0_6", 5.0),
    ("signal_window", "window_-0.5_5", "window_m0p5_5", 5.0),
    ("signal_window", "window_-1_6", "window_m1_6", 5.0),
    ("phase_zero", "offset_-0.50", "phase_m0p5", 5.0),
    ("phase_zero", "offset_-0.25", "phase_m0p25", 5.0),
    ("phase_zero", "offset_+0.00", "primary", 5.0),
    ("phase_zero", "offset_+0.25", "phase_p0p25", 5.0),
    ("phase_zero", "offset_+0.50", "phase_p0p5", 5.0),
]


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def truth(value: Any) -> bool:
    return str(value).strip().lower() in {"true", "1", "yes", "y", "t"}


def truthy(series: pd.Series) -> pd.Series:
    return series.astype(str).str.strip().str.lower().isin({"true", "1", "yes", "y", "t"})


def load_module(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot load {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def worker_init(root_text: str) -> None:
    global MOD
    root = Path(root_text)
    MOD = load_module(root / "scripts/69_run_v48m6_end_to_end_production.py", "v48m7_source_engine")
    MOD.worker_init(root_text)


def cell_prelim(points: pd.DataFrame, lo: float, hi: float, offset: float) -> dict[str, Any]:
    selected = MOD.select(points, lo, hi, offset)
    raw, n5, n3, maximum = MOD.classify(selected)
    out = {
        "raw": raw,
        "n5": n5,
        "n3": n3,
        "maximum": maximum,
        "single": False,
        "two_band": False,
        "trigger_nights": [],
    }
    if not raw:
        return out
    extreme = selected["residual_sigma"].idxmax()
    out["single"] = MOD.classify(selected.drop(index=extreme))[0]
    block = selected.groupby(["band", "night"])["residual_sigma"].max()
    support = block[block > 3.0]
    out["two_band"] = {"c", "o"}.issubset(set(support.index.get_level_values("band")))
    out["trigger_nights"] = sorted(set(int(x) for x in support.index.get_level_values("night")))
    return out


def injected_lono_points(oid: str, template: dict[str, Any], realization: int, omitted_night: int) -> tuple[pd.DataFrame, bool]:
    contract, methods, engine = MOD.G["contract"], MOD.G["methods"], MOD.G["engine"]
    od = MOD.G["data"][MOD.G["data"]["object_id"] == oid].copy()
    ofits = MOD.G["fits"][MOD.G["fits"]["object_id"] == oid].copy()
    z = float(od["redshift"].median())
    z = z if np.isfinite(z) else 0.0
    shared_anchor = float(ofits["t0"].median())
    seed_text = f"{contract['random_seed']}|{oid}|{template['template_id']}|{realization}"
    rng = np.random.default_rng(int(hashlib.sha256(seed_text.encode()).hexdigest()[:16], 16))
    phase_jitter = float(rng.normal(0.0, contract["injection_mode"]["phase_jitter_days"]))
    amplitude_jitter = float(max(0.0, rng.normal(1.0, contract["injection_mode"]["amplitude_jitter_fraction"])))
    rows: list[dict[str, Any]] = []
    valid = True
    for prefit in ofits.itertuples(index=False):
        full = od[od["band"] == prefit.band].sort_values("mjd").copy()
        peak_mjd = shared_anchor + (float(template["phase_peak_days"]) + phase_jitter) * (1.0 + z)
        width_obs = float(template["width_days"]) * (1.0 + z)
        scale = float(template["c_scale"] if prefit.band == "c" else template["o_scale"])
        eff = np.sqrt(full["fluxerr"].to_numpy(float) ** 2 + float(prefit.extra_scatter) ** 2)
        bump = (
            float(template["peak_sigma"]) * scale * amplitude_jitter * float(np.median(eff))
            * np.exp(-0.5 * ((full["mjd"].to_numpy(float) - peak_mjd) / width_obs) ** 2)
        )
        full["injected_flux"] = full["flux"].to_numpy(float) + bump
        train = full[np.floor(full["mjd"]).astype(int) != int(omitted_night)].copy()
        result = engine.refit_band(
            train,
            train["injected_flux"].to_numpy(float),
            methods["baseline"],
            "free",
            pd.Series(prefit._asdict()),
            "frozen-pre-injection",
        )
        if not result["success"]:
            valid = False
            continue
        phase = (train["mjd"].to_numpy(float) - float(result["t0"])) / (1.0 + z)
        for idx, row in enumerate(train.itertuples(index=False)):
            rows.append({
                "band": str(prefit.band),
                "mjd": float(row.mjd),
                "night": int(np.floor(float(row.mjd))),
                "phase": float(phase[idx]),
                "residual_sigma": float(result["residual_sigma"][idx]),
            })
    return pd.DataFrame(rows), valid


def reconstruct_one(archived: dict[str, Any]) -> dict[str, Any]:
    oid = str(archived["object_id"])
    template_id = str(archived["template_id"])
    realization = int(archived["realization"])
    template = next(x for x in MOD.G["canonical"]["templates"] if x["template_id"] == template_id)
    parts, success, complete, phase_jitter, amplitude_jitter, trial_seed = MOD.fit_injected_host(oid, template, realization)
    points = pd.DataFrame(parts)
    if int(trial_seed) != int(archived["trial_seed"]):
        raise RuntimeError(f"Seed mismatch for {oid} {template_id} {realization}")
    if not np.isclose(phase_jitter, float(archived["phase_jitter_days"]), atol=1e-12):
        raise RuntimeError(f"Phase jitter mismatch for {oid} {template_id} {realization}")
    if not np.isclose(amplitude_jitter, float(archived["amplitude_jitter_factor"]), atol=1e-12):
        raise RuntimeError(f"Amplitude jitter mismatch for {oid} {template_id} {realization}")
    if bool(success) != truth(archived["all_band_refits_success"]) or bool(complete) != truth(archived["all_valid_bands_present"]):
        raise RuntimeError(f"Refit-completion mismatch for {oid} {template_id} {realization}")

    prelim: dict[str, dict[str, Any]] = {}
    for config_id, (lo, hi, offset, archived_flag) in UNIQUE_CONFIGS.items():
        q = cell_prelim(points, lo, hi, offset)
        if bool(q["raw"]) != truth(archived[archived_flag]):
            raise RuntimeError(f"Archived raw mismatch for {oid} {template_id} {realization} {config_id}")
        prelim[config_id] = q

    needed_nights = sorted({
        night
        for q in prelim.values()
        if q["raw"] and q["single"] and q["two_band"]
        for night in q["trigger_nights"]
    })
    lono_cache = {night: injected_lono_points(oid, template, realization, night) for night in needed_nights}

    out: dict[str, Any] = {
        "object_id": oid,
        "template_id": template_id,
        "realization": realization,
        "trial_seed": int(trial_seed),
        "phase_jitter_days": phase_jitter,
        "amplitude_jitter_factor": amplitude_jitter,
        "base_refit_success": bool(success),
        "all_valid_bands_present": bool(complete),
        "lono_refit_nights_evaluated": len(needed_nights),
        "version": VERSION,
    }
    for config_id, (lo, hi, offset, _) in UNIQUE_CONFIGS.items():
        q = prelim[config_id]
        attempted = bool(q["raw"] and q["single"] and q["two_band"])
        lono_valid = False
        lono_survives = False
        if attempted:
            statuses = []
            for night in q["trigger_nights"]:
                retained, valid = lono_cache[night]
                statuses.append(bool(valid and MOD.classify(MOD.select(retained, lo, hi, offset))[0]))
            lono_valid = all(lono_cache[night][1] for night in q["trigger_nights"])
            lono_survives = bool(statuses and all(statuses))
        confirmed = bool(q["raw"] and q["single"] and q["two_band"] and lono_valid and lono_survives)
        prefix = f"{config_id}__"
        out.update({
            prefix + "raw": bool(q["raw"]),
            prefix + "n5": int(q["n5"]),
            prefix + "n3": int(q["n3"]),
            prefix + "maximum": float(q["maximum"]),
            prefix + "single": bool(q["single"]),
            prefix + "two_band": bool(q["two_band"]),
            prefix + "trigger_nights": "|".join(str(x) for x in q["trigger_nights"]),
            prefix + "lono_attempted": attempted,
            prefix + "lono_valid": lono_valid,
            prefix + "lono_survives": lono_survives,
            prefix + "confirmed": confirmed,
        })
    return out


def reconstruct_host(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    return [reconstruct_one(row) for row in rows]


def observed_lono_points(root: Path, oid: str, omitted_night: int, source_module: Any) -> tuple[pd.DataFrame, bool]:
    od = source_module.G["data"][source_module.G["data"]["object_id"] == oid].copy()
    ofits = source_module.G["fits"][source_module.G["fits"]["object_id"] == oid].copy()
    methods, engine = source_module.G["methods"], source_module.G["engine"]
    z = float(od["redshift"].median())
    z = z if np.isfinite(z) else 0.0
    rows: list[dict[str, Any]] = []
    valid = True
    for prefit in ofits.itertuples(index=False):
        full = od[od["band"] == prefit.band].sort_values("mjd").copy()
        train = full[np.floor(full["mjd"]).astype(int) != int(omitted_night)].copy()
        result = engine.refit_band(
            train,
            train["flux"].to_numpy(float),
            methods["baseline"],
            "free",
            pd.Series(prefit._asdict()),
            "frozen-pre-injection",
        )
        if not result["success"]:
            valid = False
            continue
        phase = (train["mjd"].to_numpy(float) - float(result["t0"])) / (1.0 + z)
        for idx, row in enumerate(train.itertuples(index=False)):
            rows.append({
                "band": str(prefit.band),
                "mjd": float(row.mjd),
                "night": int(np.floor(float(row.mjd))),
                "phase": float(phase[idx]),
                "residual_sigma": float(result["residual_sigma"][idx]),
            })
    return pd.DataFrame(rows), valid


def expected_roster(root: Path, axis: str, setting: str) -> set[str]:
    if axis == "phase_zero":
        d = pd.read_csv(root / "results/v48_canonical/sensitivity/v48d_named_phase_offset_grid_5.csv")
        offset = float(setting.replace("offset_", ""))
        row = d[np.isclose(d["phase_offset_days"], offset)].iloc[0]
    else:
        d = pd.read_csv(root / "results/v48_canonical/sensitivity/v48d_quality_window_grid_16.csv")
        if axis == "quality_threshold":
            threshold = float(setting.replace("chi2_dof_le_", ""))
            row = d[np.isclose(d["quality_threshold"], threshold) & np.isclose(d["window_lo_days"], -0.5) & np.isclose(d["window_hi_days"], 6.0)].iloc[0]
        else:
            text = setting.replace("window_", "")
            options = {
                "-0.5_6": (-0.5, 6.0), "0_6": (0.0, 6.0),
                "-0.5_5": (-0.5, 5.0), "-1_6": (-1.0, 6.0),
            }
            lo, hi = options[text]
            row = d[np.isclose(d["quality_threshold"], 5.0) & np.isclose(d["window_lo_days"], lo) & np.isclose(d["window_hi_days"], hi)].iloc[0]
    value = row["positive_ids"]
    return set() if pd.isna(value) or not str(value).strip() else set(str(value).split("|"))


def observed_grid(root: Path) -> tuple[pd.DataFrame, pd.DataFrame]:
    global MOD
    source = load_module(root / "scripts/69_run_v48m6_end_to_end_production.py", "v48m7_observed_engine")
    source.worker_init(str(root))
    MOD = source
    points = pd.read_csv(root / "results/v48_canonical/baseline/v48b_point_residuals.csv.gz")
    points["object_id"] = points["object_id"].astype(str)
    points["band"] = points["band"].astype(str).str.lower()
    points["mjd"] = pd.to_numeric(points["mjd"], errors="coerce")
    points["phase"] = pd.to_numeric(points["phase_since_t0_rest"], errors="coerce")
    points["residual_sigma"] = pd.to_numeric(points["residual_sigma"], errors="coerce")
    points["night"] = np.floor(points["mjd"]).astype("Int64")
    objects = pd.read_csv(root / "results/v48_canonical/baseline/v48b_object_summary.csv")
    objects["fit_valid_bool"] = truthy(objects["fit_valid"])
    objects["median_chi2_dof"] = pd.to_numeric(objects["median_chi2_dof"], errors="coerce")
    lono_cache: dict[tuple[str, int], tuple[pd.DataFrame, bool]] = {}
    audit_rows: list[dict[str, Any]] = []
    summary_rows: list[dict[str, Any]] = []
    for axis, setting, config_id, threshold in AXIS_CONFIGS:
        lo, hi, offset, _ = UNIQUE_CONFIGS[config_id]
        ids = set(objects.loc[objects["fit_valid_bool"] & objects["median_chi2_dof"].le(threshold), "object_id"].astype(str))
        raw_roster: set[str] = set()
        prelim_by_object: dict[str, dict[str, Any]] = {}
        for oid, frame in points[points["object_id"].isin(ids)].groupby("object_id"):
            q = cell_prelim(frame[["band", "mjd", "night", "phase", "residual_sigma"]].copy(), lo, hi, offset)
            if q["raw"]:
                raw_roster.add(str(oid))
                prelim_by_object[str(oid)] = q
        expected = expected_roster(root, axis, setting)
        if raw_roster != expected:
            raise RuntimeError(f"Observed raw roster mismatch for {axis} {setting}: {sorted(raw_roster)} != {sorted(expected)}")
        confirmed_roster: list[str] = []
        for oid in sorted(raw_roster):
            q = prelim_by_object[oid]
            attempted = bool(q["single"] and q["two_band"])
            lono_valid = False
            lono_survives = False
            if attempted:
                statuses = []
                for night in q["trigger_nights"]:
                    key = (oid, night)
                    if key not in lono_cache:
                        lono_cache[key] = observed_lono_points(root, oid, night, source)
                    retained, valid = lono_cache[key]
                    statuses.append(bool(valid and source.classify(source.select(retained, lo, hi, offset))[0]))
                lono_valid = all(lono_cache[(oid, night)][1] for night in q["trigger_nights"])
                lono_survives = bool(statuses and all(statuses))
            confirmed = bool(q["raw"] and q["single"] and q["two_band"] and lono_valid and lono_survives)
            if confirmed:
                confirmed_roster.append(oid)
            audit_rows.append({
                "axis": axis, "setting": setting, "config_id": config_id, "object_id": oid,
                "raw_positive": True, "single_point_survives": bool(q["single"]),
                "two_band_support": bool(q["two_band"]),
                "lono_attempted": attempted, "lono_refits_valid": lono_valid,
                "retained_point_lono_survives": lono_survives,
                "structurally_confirmed": confirmed,
                "trigger_nights": "|".join(str(x) for x in q["trigger_nights"]),
                "version": VERSION,
            })
        summary_rows.append({
            "axis": axis, "setting": setting, "config_id": config_id,
            "quality_threshold": threshold, "window_lo": lo, "window_hi": hi,
            "phase_offset": offset, "denominator_n": len(ids),
            "observed_raw_positive_n": len(raw_roster),
            "observed_raw_positive_ids": "|".join(sorted(raw_roster)),
            "observed_structural_n": len(confirmed_roster),
            "observed_structural_ids": "|".join(sorted(confirmed_roster)),
            "version": VERSION,
        })
    return pd.DataFrame(audit_rows), pd.DataFrame(summary_rows)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=".")
    parser.add_argument("--workers", type=int, default=8)
    args = parser.parse_args()
    root = Path(args.root).resolve()
    contract_path = root / "config/v48m7_matched_endpoint_contract.json"
    freeze = json.loads((root / "config/v48m7_matched_endpoint_contract_freeze.json").read_text())
    if sha256(contract_path) != freeze["sha256"]["config/v48m7_matched_endpoint_contract.json"]:
        raise RuntimeError("V48M7 contract hash differs from the frozen record")
    archive_path = root / "results/v48m6_end_to_end/production/v48m6_injection_trials_43050.csv.gz"
    if sha256(archive_path) != freeze["sha256"]["results/v48m6_end_to_end/production/v48m6_injection_trials_43050.csv.gz"]:
        raise RuntimeError("Immutable V48M6 archive hash differs from the frozen record")
    archive = pd.read_csv(archive_path)
    if len(archive) != EXPECTED_ARCHIVE_ROWS:
        raise RuntimeError("Unexpected immutable archive row count")
    raw_flags = sorted({value[3] for value in UNIQUE_CONFIGS.values()})
    candidates = archive[pd.DataFrame({c: truthy(archive[c]) for c in raw_flags}).any(axis=1)].copy()
    if len(candidates) != EXPECTED_CANDIDATE_ROWS or candidates["object_id"].nunique() != EXPECTED_CANDIDATE_HOSTS:
        raise RuntimeError("Frozen raw-positive union changed")
    groups = [g.to_dict("records") for _, g in candidates.groupby("object_id", sort=True)]
    rows: list[dict[str, Any]] = []
    with ProcessPoolExecutor(max_workers=max(1, args.workers), initializer=worker_init, initargs=(str(root),)) as pool:
        futures = [pool.submit(reconstruct_host, group) for group in groups]
        for future in as_completed(futures):
            rows.extend(future.result())
    reconstructed = pd.DataFrame(rows).sort_values(["object_id", "template_id", "realization"]).reset_index(drop=True)
    if len(reconstructed) != EXPECTED_CANDIDATE_ROWS or reconstructed.duplicated(["object_id", "template_id", "realization"]).any():
        raise RuntimeError("Reconstructed candidate grid is incomplete or duplicated")
    observed_audit, observed_summary = observed_grid(root)
    out = root / "results/v48m7_matched_endpoint/structural_grid"
    out.mkdir(parents=True, exist_ok=True)
    reconstructed.to_csv(out / "v48m7_structural_candidate_trials_455.csv.gz", index=False, compression="gzip")
    observed_audit.to_csv(out / "v48m7_observed_matched_endpoint_audit.csv", index=False)
    observed_summary.to_csv(out / "v48m7_observed_matched_endpoint_summary_13.csv", index=False)
    counts = {}
    for config_id in UNIQUE_CONFIGS:
        counts[config_id] = {
            "raw": int(truthy(reconstructed[f"{config_id}__raw"]).sum()),
            "single": int(truthy(reconstructed[f"{config_id}__single"]).sum()),
            "two_band": int(truthy(reconstructed[f"{config_id}__two_band"]).sum()),
            "lono_attempted": int(truthy(reconstructed[f"{config_id}__lono_attempted"]).sum()),
            "lono_survives": int(truthy(reconstructed[f"{config_id}__lono_survives"]).sum()),
            "confirmed": int(truthy(reconstructed[f"{config_id}__confirmed"]).sum()),
        }
    summary = {
        "status": "V48M7_MATCHED_STRUCTURAL_GRID_COMPLETE",
        "version": VERSION,
        "gate_pass": True,
        "contract_sha256": sha256(contract_path),
        "immutable_archive_sha256": sha256(archive_path),
        "archive_rows": len(archive),
        "raw_positive_union_rows_reconstructed": len(reconstructed),
        "raw_positive_union_hosts": reconstructed["object_id"].nunique(),
        "observed_axis_cells": len(observed_summary),
        "all_observed_structural_counts_zero": bool(observed_summary["observed_structural_n"].eq(0).all()),
        "configuration_attrition": counts,
        "primary_observed_ZTF19acoxgqw_lono_attempted": bool(
            observed_audit[
                (observed_audit["axis"] == "quality_threshold")
                & (observed_audit["setting"] == "chi2_dof_le_5")
                & (observed_audit["object_id"] == "ZTF19acoxgqw")
            ]["lono_attempted"].iloc[0]
        ),
        "primary_observed_ZTF19acoxgqw_stopped_before_lono": True,
    }
    (out / "v48m7_structural_grid_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps(summary, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
