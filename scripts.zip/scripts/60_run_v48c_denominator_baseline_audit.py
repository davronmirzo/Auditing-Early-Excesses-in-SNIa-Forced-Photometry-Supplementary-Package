from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd


VERSION = "v48c_denominator_baseline_audit_1.0.0"
STATUS = "V48C_DENOMINATOR_AND_BASELINE_AUDIT_COMPLETE"


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def as_bool(series: pd.Series) -> pd.Series:
    return series.astype(str).str.strip().str.lower().isin({"true", "1", "yes", "y", "t"})


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=".")
    args = ap.parse_args()
    root = Path(args.root).resolve()
    base = root / "results" / "v48_canonical" / "baseline"
    out = root / "results" / "v48_canonical" / "audit"
    paths = {
        "contract": root / "config" / "v48a_canonical_methods_contract.json",
        "freeze": root / "results" / "v48_canonical" / "freeze" / "v48a_methods_contract_freeze.json",
        "summary": base / "v48b_baseline_scatter_summary.json",
        "fits": base / "v48b_object_band_fits.csv",
        "objects": base / "v48b_object_summary.csv",
        "points": base / "v48b_point_residuals.csv.gz",
    }
    for path in paths.values():
        if not path.is_file():
            raise FileNotFoundError(path)

    freeze = json.loads(paths["freeze"].read_text(encoding="utf-8"))
    bsum = json.loads(paths["summary"].read_text(encoding="utf-8"))
    if freeze.get("status") != "V48A_CANONICAL_METHODS_CONTRACT_FROZEN":
        raise RuntimeError("V48A freeze gate is not closed")
    if bsum.get("status") != "V48B_CANONICAL_BASELINE_AND_SCATTER_RERUN_COMPLETE":
        raise RuntimeError("V48B production gate is not closed")
    if freeze.get("contract_sha256") != sha256(paths["contract"]):
        raise RuntimeError("Frozen V48A contract changed")

    fits = pd.read_csv(paths["fits"])
    objects = pd.read_csv(paths["objects"])
    points = pd.read_csv(paths["points"])
    for frame, columns in ((fits, ["success", "valid_fit", "alpha_boundary", "scatter_converged"]),
                           (objects, ["fit_valid", "primary_chi2_le_5", "positive_flag", "negative_flag"]),
                           (points, ["in_signal_window"])):
        for column in columns:
            frame[column + "__bool"] = as_bool(frame[column])

    if len(fits) != 736 or len(objects) != 368:
        raise RuntimeError("V48B dimensions differ from the frozen 736/368 contract")
    if int(fits["valid_fit__bool"].sum()) != 405:
        raise RuntimeError("Valid object-band fit count is not 405")
    if int(objects["fit_valid__bool"].sum()) != 303 or int(objects["primary_chi2_le_5__bool"].sum()) != 277:
        raise RuntimeError("Fit-valid/primary object counts are not 303/277")

    primary_ids = set(objects.loc[objects["primary_chi2_le_5__bool"], "object_id"].astype(str))
    fit_valid_ids = set(objects.loc[objects["fit_valid__bool"], "object_id"].astype(str))
    denominator = objects.copy()
    denominator["decision"] = np.where(
        denominator["primary_chi2_le_5__bool"], "included_primary",
        np.where(denominator["fit_valid__bool"], "excluded_median_chi2_gt_5", "excluded_no_valid_band_fit"),
    )
    denominator["positive_threshold_crossing"] = denominator["positive_flag__bool"]
    denominator["negative_threshold_crossing"] = denominator["negative_flag__bool"]
    denominator["version"] = VERSION

    fits["convergence_class"] = np.select(
        [fits["scatter_converged"].isna(),
         (~fits["success__bool"]) & (~fits["scatter_converged"].isna()),
         fits["success__bool"] & fits["scatter_converged__bool"],
         fits["success__bool"] & (~fits["scatter_converged__bool"])],
        ["not_evaluated", "optimizer_failed", "converged", "iteration_cap_nonconverged"],
        default="unclassified",
    )
    fits["object_fit_valid"] = fits["object_id"].astype(str).isin(fit_valid_ids)
    fits["object_in_primary"] = fits["object_id"].astype(str).isin(primary_ids)
    fits["version_audit"] = VERSION

    valid_fits = fits[fits["valid_fit__bool"]].copy()
    fit_risk = valid_fits.groupby("object_id").agg(
        valid_band_count=("band", "size"),
        any_valid_band_nonconverged=("scatter_converged__bool", lambda x: bool((~x).any())),
        any_valid_band_chi2_gt_5=("chi2_dof", lambda x: bool((pd.to_numeric(x, errors="coerce") > 5).any())),
        minimum_valid_band_points=("n_points", "min"),
        maximum_valid_band_chi2_dof=("chi2_dof", "max"),
    ).reset_index()
    denominator = denominator.merge(fit_risk, on="object_id", how="left")

    q = points[points["in_signal_window__bool"]].copy()
    q["night"] = np.floor(pd.to_numeric(q["mjd"], errors="coerce")).astype("Int64")
    nightly = q.groupby(["object_id", "band", "night"], dropna=False).agg(
        n_points=("residual_sigma", "size"),
        maximum_residual_sigma=("residual_sigma", "max"),
        minimum_residual_sigma=("residual_sigma", "min"),
        minimum_phase_since_t0_rest=("phase_since_t0_rest", "min"),
        maximum_phase_since_t0_rest=("phase_since_t0_rest", "max"),
    ).reset_index()
    nightly["positive_gt_5"] = nightly["maximum_residual_sigma"] > 5
    nightly["positive_gt_3"] = nightly["maximum_residual_sigma"] > 3
    nightly["negative_lt_minus5"] = nightly["minimum_residual_sigma"] < -5
    nightly["negative_lt_minus3"] = nightly["minimum_residual_sigma"] < -3

    candidates = denominator[
        denominator["primary_chi2_le_5__bool"]
        & (denominator["positive_flag__bool"] | denominator["negative_flag__bool"])
    ].copy()
    candidate_ids = set(candidates["object_id"].astype(str))
    candidate_nightly = nightly[nightly["object_id"].astype(str).isin(candidate_ids)].copy()
    candidate_nightly["version"] = VERSION
    night_stats = candidate_nightly.groupby("object_id").agg(
        positive_blocks_gt_5=("positive_gt_5", "sum"),
        positive_blocks_gt_3=("positive_gt_3", "sum"),
        negative_blocks_lt_minus5=("negative_lt_minus5", "sum"),
        negative_blocks_lt_minus3=("negative_lt_minus3", "sum"),
        trigger_band_count=("band", "nunique"),
    ).reset_index()
    candidates = candidates.merge(night_stats, on="object_id", how="left")
    candidates["crossing_label"] = np.select(
        [candidates["positive_flag__bool"] & candidates["negative_flag__bool"],
         candidates["positive_flag__bool"], candidates["negative_flag__bool"]],
        ["positive_and_negative", "positive", "negative"], default="none")
    candidates["candidate_status"] = "threshold_crossing_not_astrophysical_detection"
    candidates["requires_v48d_forensics"] = True
    candidates["version_audit"] = VERSION

    expected_candidates = {
        "ZTF18abebzog": "positive", "ZTF19acoxgqw": "positive",
        "ZTF18ablqlzp": "negative", "ZTF18abnygkb": "negative", "ZTF19aawupxb": "negative",
    }
    observed_candidates = dict(zip(candidates["object_id"].astype(str), candidates["crossing_label"].astype(str)))
    if observed_candidates != expected_candidates:
        raise RuntimeError(f"Unexpected threshold-crossing set: {observed_candidates}")

    evaluated = fits["scatter_converged"].notna()
    n_eval = int(evaluated.sum())
    n_conv = int(fits.loc[evaluated, "scatter_converged__bool"].sum())
    n_nonconv = n_eval - n_conv
    n_nonconv_valid = int((fits["success__bool"] & fits["valid_fit__bool"] & ~fits["scatter_converged__bool"]).sum())
    n_nonconv_primary = int((fits["success__bool"] & fits["valid_fit__bool"] & ~fits["scatter_converged__bool"] & fits["object_in_primary"]).sum())
    candidate_nonconv = int(candidates["any_valid_band_nonconverged"].eq(True).sum())
    if n_eval != 719 or n_conv not in {701, 702} or n_nonconv_valid not in {11, 12}:
        raise RuntimeError("Scatter-convergence result lies outside the adjudicated one-group platform envelope")
    if candidate_nonconv != 0:
        raise RuntimeError("A threshold crossing depends on a non-converged valid-band fit")

    out.mkdir(parents=True, exist_ok=True)
    keep_den = [c for c in denominator.columns if not c.endswith("__bool")]
    keep_fit = [c for c in fits.columns if not c.endswith("__bool")]
    keep_cand = [c for c in candidates.columns if not c.endswith("__bool")]
    denominator[keep_den].to_csv(out / "v48c_denominator_adjudication_368.csv", index=False)
    fits[keep_fit].to_csv(out / "v48c_object_band_convergence_audit_736.csv", index=False)
    candidates[keep_cand].to_csv(out / "v48c_threshold_crossing_forensic_5.csv", index=False)
    candidate_nightly.to_csv(out / "v48c_threshold_crossing_nightly_blocks.csv", index=False)

    summary = {
        "status": STATUS,
        "version": VERSION,
        "input_sha256": {k: sha256(v) for k, v in paths.items()},
        "eligible_objects": 368,
        "fit_valid_objects": 303,
        "primary_objects": 277,
        "excluded_median_chi2_gt_5": int(((denominator["decision"] == "excluded_median_chi2_gt_5")).sum()),
        "excluded_no_valid_band_fit": int(((denominator["decision"] == "excluded_no_valid_band_fit")).sum()),
        "scatter_evaluated_groups": n_eval,
        "scatter_converged_groups": n_conv,
        "scatter_nonconverged_groups": n_nonconv,
        "nonconverged_valid_fits": n_nonconv_valid,
        "nonconverged_valid_fits_in_primary": n_nonconv_primary,
        "platform_envelope_converged_groups": [701, 702],
        "platform_numeric_variation_groups": 1,
        "positive_threshold_crossings": 2,
        "negative_threshold_crossings": 3,
        "threshold_crossings_depending_on_nonconverged_fit": candidate_nonconv,
        "candidate_interpretation": "threshold crossings only; not astrophysical detections",
        "archived_219_outputs_overwritten": False,
        "v44_outputs_overwritten": False,
        "injection_recovery_executed": False,
        "population_limits_computed": False,
        "next_authorized_stage": "V48D_PRESPECIFIED_SENSITIVITY_AND_CANDIDATE_FORENSICS",
    }
    (out / "v48c_denominator_baseline_audit_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    lines = [
        STATUS,
        "V48C_DENOMINATOR_GATE_PASS",
        "V48C_PLATFORM_NUMERIC_VARIATION_ADJUDICATED_ONE_GROUP",
        "V48C_THRESHOLD_CROSSINGS_NOT_ASTROPHYSICAL_DETECTIONS",
        "Eligible/fit-valid/primary objects: 368/303/277",
        f"Primary exclusions (median chi2>5/no valid fit): {summary['excluded_median_chi2_gt_5']}/{summary['excluded_no_valid_band_fit']}",
        f"Scatter convergence: {n_conv}/{n_eval}; non-converged: {n_nonconv}",
        f"Non-converged valid fits / in primary: {n_nonconv_valid}/{n_nonconv_primary}",
        "Threshold crossings positive/negative: 2/3",
        "Threshold crossings depending on non-converged fit: 0",
        "Archived 219/v44 outputs overwritten: False",
        "Injection-recovery executed: False",
        "Population limits computed: False",
        "NEXT_AUTHORIZED_STAGE=V48D_PRESPECIFIED_SENSITIVITY_AND_CANDIDATE_FORENSICS",
    ]
    (out / "v48c_denominator_baseline_claim_box.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print("\n".join(lines))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
