from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd


VERSION = "v48m7p3_alpha_boundary_denominator_sensitivity_1.0.0"


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def truthy(series: pd.Series) -> pd.Series:
    return series.astype(str).str.strip().str.lower().isin({"true", "1", "yes", "y", "t"})


def model(t_rel: np.ndarray, amplitude: float, t0_rel: float, alpha: float) -> np.ndarray:
    return float(amplitude) * np.power(
        np.maximum(np.asarray(t_rel, dtype=float) - float(t0_rel), 0.0),
        float(alpha),
    )


def classify(points: pd.DataFrame) -> dict[str, Any]:
    if points.empty:
        return {
            "positive_flag": False,
            "negative_flag": False,
            "n_night_blocks": 0,
            "max_positive_residual": np.nan,
            "max_negative_abs_residual": np.nan,
        }
    q = points.copy()
    q["night"] = np.floor(q["mjd"]).astype(int)
    grouped = q.groupby(["band", "night"])["residual_sigma"]
    maximum = grouped.max().to_numpy(float)
    minimum = grouped.min().to_numpy(float)
    return {
        "positive_flag": bool(np.any(maximum > 5.0) or np.sum(maximum > 3.0) >= 2),
        "negative_flag": bool(np.any(minimum < -5.0) or np.sum(minimum < -3.0) >= 2),
        "n_night_blocks": int(len(maximum)),
        "max_positive_residual": float(np.max(maximum)),
        "max_negative_abs_residual": float(abs(np.min(minimum))),
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=".")
    args = parser.parse_args()
    root = Path(args.root).resolve()

    contract_path = root / "config/v48a_canonical_methods_contract.json"
    lightcurve_path = root / "data/processed/earlyrise_lightcurves.csv"
    eligible_path = root / "results/v48_canonical/freeze/v48a_eligible_native_co_368.csv"
    fits_path = root / "results/v48_canonical/baseline/v48b_object_band_fits.csv"
    canonical_objects_path = root / "results/v48_canonical/baseline/v48b_object_summary.csv"
    for path in (contract_path, lightcurve_path, eligible_path, fits_path, canonical_objects_path):
        if not path.is_file():
            raise FileNotFoundError(path)

    contract = json.loads(contract_path.read_text(encoding="utf-8"))
    eligible = pd.read_csv(eligible_path)
    eligible_ids = set(eligible["object_id"].astype(str))
    if len(eligible_ids) != 368:
        raise RuntimeError("Expected 368 frozen native-band eligible objects")

    fits = pd.read_csv(fits_path)
    canonical_objects = pd.read_csv(canonical_objects_path)
    success = truthy(fits["success"])
    finite = np.isfinite(pd.to_numeric(fits["t0"], errors="coerce"))
    finite &= np.isfinite(pd.to_numeric(fits["amplitude"], errors="coerce"))
    finite &= np.isfinite(pd.to_numeric(fits["alpha"], errors="coerce"))
    finite &= np.isfinite(pd.to_numeric(fits["chi2_dof"], errors="coerce"))
    admissible = success & finite
    admissible &= pd.to_numeric(fits["amplitude"], errors="coerce").gt(0)
    admissible &= pd.to_numeric(fits["dof"], errors="coerce").gt(0)
    sensitivity_fits = fits.loc[admissible].copy()
    if len(fits) != 736 or int(success.sum()) != 717:
        raise RuntimeError("Canonical fit accounting changed")
    if len(sensitivity_fits) != 717:
        raise RuntimeError("Not all optimizer-successful fits satisfy the non-boundary validity checks")

    lightcurves = pd.read_csv(lightcurve_path, low_memory=False)
    for column in ("mjd", "flux", "fluxerr", "redshift", "rest_phase"):
        lightcurves[column] = pd.to_numeric(lightcurves[column], errors="coerce")
    lightcurves["object_id"] = lightcurves["object_id"].astype(str).str.strip()
    lightcurves["band"] = lightcurves["band"].astype(str).str.strip().str.lower()
    phase_lo, phase_hi = contract["eligibility"]["phase_window_days"]
    lightcurves = lightcurves[
        lightcurves["object_id"].isin(eligible_ids)
        & lightcurves["band"].isin({"c", "o"})
        & lightcurves["mjd"].notna()
        & lightcurves["flux"].notna()
        & lightcurves["fluxerr"].gt(0)
        & lightcurves["rest_phase"].between(phase_lo, phase_hi, inclusive="both")
    ].copy()
    redshift = lightcurves.groupby("object_id")["redshift"].median().to_dict()

    point_frames: list[pd.DataFrame] = []
    for row in sensitivity_fits.itertuples(index=False):
        group = lightcurves[
            (lightcurves["object_id"] == str(row.object_id))
            & (lightcurves["band"] == str(row.band))
        ].copy()
        reference = float(group["mjd"].min())
        prediction = model(
            group["mjd"].to_numpy(float) - reference,
            float(row.amplitude),
            float(row.t0) - reference,
            float(row.alpha),
        )
        effective_sigma = np.sqrt(
            group["fluxerr"].to_numpy(float) ** 2 + float(row.extra_scatter) ** 2
        )
        z = float(redshift.get(str(row.object_id), 0.0))
        if not np.isfinite(z):
            z = 0.0
        group["model_flux"] = prediction
        group["effective_sigma"] = effective_sigma
        group["residual_sigma"] = (group["flux"].to_numpy(float) - prediction) / effective_sigma
        group["phase_since_t0_rest"] = (group["mjd"].to_numpy(float) - float(row.t0)) / (1.0 + z)
        group["in_signal_window"] = group["phase_since_t0_rest"].between(-0.5, 6.0, inclusive="both")
        group["baseline_alpha"] = float(row.alpha)
        group["baseline_alpha_boundary"] = bool(truthy(pd.Series([row.alpha_boundary])).iloc[0])
        point_frames.append(
            group[
                [
                    "object_id", "band", "mjd", "flux", "fluxerr", "model_flux",
                    "effective_sigma", "residual_sigma", "phase_since_t0_rest",
                    "in_signal_window", "baseline_alpha", "baseline_alpha_boundary",
                ]
            ]
        )
    points = pd.concat(point_frames, ignore_index=True)

    object_rows: list[dict[str, Any]] = []
    for object_id in sorted(eligible_ids):
        object_fits = sensitivity_fits[sensitivity_fits["object_id"].astype(str) == object_id]
        signal_points = points[
            (points["object_id"].astype(str) == object_id) & truthy(points["in_signal_window"])
        ]
        summary = classify(signal_points)
        object_rows.append(
            {
                "object_id": object_id,
                "n_admitted_band_fits": int(len(object_fits)),
                "fit_valid_boundary_admitted": bool(len(object_fits)),
                "n_boundary_band_fits": int(truthy(object_fits["alpha_boundary"]).sum()),
                "median_chi2_dof_boundary_admitted": (
                    float(pd.to_numeric(object_fits["chi2_dof"], errors="coerce").median())
                    if len(object_fits) else np.nan
                ),
                "primary_chi2_le_5_boundary_admitted": bool(
                    len(object_fits)
                    and pd.to_numeric(object_fits["chi2_dof"], errors="coerce").median() <= 5.0
                ),
                "n_signal_points": int(len(signal_points)),
                "n_signal_bands": int(signal_points["band"].nunique()) if len(signal_points) else 0,
                **summary,
            }
        )
    objects = pd.DataFrame(object_rows)

    canonical_primary = set(
        canonical_objects.loc[truthy(canonical_objects["primary_chi2_le_5"]), "object_id"].astype(str)
    )
    branch_primary = set(
        objects.loc[truthy(objects["primary_chi2_le_5_boundary_admitted"]), "object_id"].astype(str)
    )
    branch_crossings = objects[
        truthy(objects["primary_chi2_le_5_boundary_admitted"])
        & (truthy(objects["positive_flag"]) | truthy(objects["negative_flag"]))
    ].copy()
    branch_crossings["crossing_label"] = np.select(
        [truthy(branch_crossings["positive_flag"]), truthy(branch_crossings["negative_flag"])],
        ["positive", "sign_reversed"],
        default="none",
    )

    membership = pd.DataFrame({"object_id": sorted(eligible_ids)})
    membership["canonical_primary"] = membership["object_id"].isin(canonical_primary)
    membership["boundary_admitted_primary"] = membership["object_id"].isin(branch_primary)
    membership["membership_change"] = np.select(
        [
            membership["canonical_primary"] & membership["boundary_admitted_primary"],
            ~membership["canonical_primary"] & membership["boundary_admitted_primary"],
            membership["canonical_primary"] & ~membership["boundary_admitted_primary"],
        ],
        ["retained", "added", "dropped"],
        default="excluded_both",
    )

    out = root / "results/v48m7p3_alpha_boundary_sensitivity"
    out.mkdir(parents=True, exist_ok=True)
    sensitivity_fits.to_csv(out / "v48m7p3_boundary_admitted_band_fits_717.csv", index=False)
    points.to_csv(out / "v48m7p3_boundary_admitted_point_residuals.csv.gz", index=False, compression="gzip")
    objects.to_csv(out / "v48m7p3_boundary_admitted_object_summary_368.csv", index=False)
    membership.to_csv(out / "v48m7p3_boundary_admitted_primary_membership_368.csv", index=False)
    branch_crossings.to_csv(out / "v48m7p3_boundary_admitted_crossing_roster.csv", index=False)

    branch_primary_rows = objects[truthy(objects["primary_chi2_le_5_boundary_admitted"])]
    result = {
        "status": "V48M7P3_ALPHA_BOUNDARY_DENOMINATOR_SENSITIVITY_COMPLETE",
        "version": VERSION,
        "input_sha256": {
            "contract": sha256(contract_path),
            "lightcurves": sha256(lightcurve_path),
            "canonical_fits": sha256(fits_path),
            "canonical_objects": sha256(canonical_objects_path),
        },
        "rule": "Admit every optimizer-successful finite positive-amplitude fit with dof>0, including alpha-boundary solutions; keep median chi2<=5 unchanged.",
        "role": "post-revision denominator sensitivity diagnostic; not a replacement primary estimand because boundary solutions are not interior identified fits",
        "canonical": {
            "fit_valid_objects": int(truthy(canonical_objects["fit_valid"]).sum()),
            "primary_objects": len(canonical_primary),
            "positive_crossings": int(
                (truthy(canonical_objects["primary_chi2_le_5"]) & truthy(canonical_objects["positive_flag"])).sum()
            ),
            "sign_reversed_crossings": int(
                (truthy(canonical_objects["primary_chi2_le_5"]) & truthy(canonical_objects["negative_flag"])).sum()
            ),
        },
        "boundary_admitted": {
            "admitted_band_fits": int(len(sensitivity_fits)),
            "fit_valid_objects": int(truthy(objects["fit_valid_boundary_admitted"]).sum()),
            "primary_objects": len(branch_primary),
            "positive_crossings": int(truthy(branch_primary_rows["positive_flag"]).sum()),
            "sign_reversed_crossings": int(truthy(branch_primary_rows["negative_flag"]).sum()),
            "crossing_object_ids": branch_crossings[
                ["object_id", "crossing_label"]
            ].to_dict(orient="records"),
        },
        "membership_delta": {
            "retained": int((membership["membership_change"] == "retained").sum()),
            "added": int((membership["membership_change"] == "added").sum()),
            "dropped": int((membership["membership_change"] == "dropped").sum()),
        },
    }
    (out / "v48m7p3_alpha_boundary_sensitivity_summary.json").write_text(
        json.dumps(result, indent=2), encoding="utf-8"
    )
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
