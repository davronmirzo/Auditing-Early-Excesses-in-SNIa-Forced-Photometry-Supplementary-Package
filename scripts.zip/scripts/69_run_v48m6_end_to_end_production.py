from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import os
import time
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd


VERSION = "v48m6_end_to_end_production_1.0.0"
EXPECTED_HOSTS = 287
EXPECTED_TRIALS = 43050
G: dict[str, Any] = {}


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def truthy(series: pd.Series) -> pd.Series:
    return series.astype(str).str.strip().str.lower().isin({"true", "1", "yes", "y", "t"})


def load_engine(root: Path):
    path = root / "scripts/65_validate_v48g2_full_refit_engine.py"
    spec = importlib.util.spec_from_file_location("v48m6_refit_engine", path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot load {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def classify(points: pd.DataFrame) -> tuple[bool, int, int, float]:
    if points.empty:
        return False, 0, 0, np.nan
    block = points.groupby(["band", "night"])["residual_sigma"].max()
    n5 = int((block > 5.0).sum())
    n3 = int((block > 3.0).sum())
    return bool(n5 >= 1 or n3 >= 2), n5, n3, float(block.max())


def select(points: pd.DataFrame, lo: float, hi: float, offset: float = 0.0) -> pd.DataFrame:
    phase = points["phase"] - float(offset)
    return points[phase.between(float(lo), float(hi), inclusive="both")].copy()


def worker_init(root_text: str) -> None:
    root = Path(root_text)
    contract = json.loads((root / "config/v48m6_end_to_end_contract.json").read_text(encoding="utf-8"))
    canonical = json.loads((root / "config/v48g1_injection_contract.json").read_text(encoding="utf-8"))
    methods = json.loads((root / "config/v48a_canonical_methods_contract.json").read_text(encoding="utf-8"))
    fits = pd.read_csv(root / "results/v48_canonical/baseline/v48b_object_band_fits.csv")
    fits["object_id"] = fits["object_id"].astype(str)
    fits["band"] = fits["band"].astype(str).str.lower()
    fits = fits[truthy(fits["valid_fit"])].copy()
    data = pd.read_csv(root / "data/processed/earlyrise_lightcurves.csv", low_memory=False)
    for col in ("mjd", "flux", "fluxerr", "redshift", "rest_phase"):
        data[col] = pd.to_numeric(data[col], errors="coerce")
    data["object_id"] = data["object_id"].astype(str)
    data["band"] = data["band"].astype(str).str.lower()
    lo, hi = methods["eligibility"]["phase_window_days"]
    data = data[
        data["band"].isin({"c", "o"})
        & data["mjd"].notna()
        & data["flux"].notna()
        & data["fluxerr"].gt(0)
        & data["rest_phase"].between(lo, hi, inclusive="both")
    ].copy()
    G.update(root=root, contract=contract, canonical=canonical, methods=methods,
             fits=fits, data=data, engine=load_engine(root))


def fit_injected_host(oid: str, template: dict[str, Any], realization: int) -> tuple[list[dict[str, Any]], bool, bool, float, float, int]:
    contract, canonical, methods, engine = G["contract"], G["canonical"], G["methods"], G["engine"]
    od = G["data"][G["data"]["object_id"] == oid].copy()
    ofits = G["fits"][G["fits"]["object_id"] == oid].copy()
    z = float(od["redshift"].median())
    z = z if np.isfinite(z) else 0.0
    shared_anchor = float(ofits["t0"].median())
    seed_text = f"{contract['random_seed']}|{oid}|{template['template_id']}|{realization}"
    trial_seed = int(hashlib.sha256(seed_text.encode()).hexdigest()[:16], 16)
    rng = np.random.default_rng(trial_seed)
    phase_jitter = float(rng.normal(0.0, contract["injection_mode"]["phase_jitter_days"]))
    amplitude_jitter = float(max(0.0, rng.normal(1.0, contract["injection_mode"]["amplitude_jitter_fraction"])))
    parts: list[dict[str, Any]] = []
    all_success = True
    fixed_inputs: dict[str, tuple[pd.DataFrame, np.ndarray, pd.Series]] = {}
    for prefit in ofits.itertuples(index=False):
        g = od[od["band"] == prefit.band].sort_values("mjd").copy()
        peak_mjd = shared_anchor + (float(template["phase_peak_days"]) + phase_jitter) * (1.0 + z)
        width_obs = float(template["width_days"]) * (1.0 + z)
        band_scale = float(template["c_scale"] if prefit.band == "c" else template["o_scale"])
        effective_pre = np.sqrt(g["fluxerr"].to_numpy(float) ** 2 + float(prefit.extra_scatter) ** 2)
        bump = (
            float(template["peak_sigma"]) * band_scale * amplitude_jitter * float(np.median(effective_pre))
            * np.exp(-0.5 * ((g["mjd"].to_numpy(float) - peak_mjd) / width_obs) ** 2)
        )
        injected_flux = g["flux"].to_numpy(float) + bump
        prefit_series = pd.Series(prefit._asdict())
        result = engine.refit_band(g, injected_flux, methods["baseline"], "free", prefit_series, "frozen-pre-injection")
        if not result["success"]:
            all_success = False
            continue
        phase = (g["mjd"].to_numpy(float) - float(result["t0"])) / (1.0 + z)
        for idx, row in enumerate(g.itertuples(index=False)):
            parts.append({
                "band": str(prefit.band), "mjd": float(row.mjd), "night": int(np.floor(float(row.mjd))),
                "phase": float(phase[idx]), "residual_sigma": float(result["residual_sigma"][idx]),
            })
        fixed_inputs[str(prefit.band)] = (g, injected_flux, prefit_series)
    return parts, all_success, bool(len(fixed_inputs) == len(ofits)), phase_jitter, amplitude_jitter, trial_seed


def structural_confirmation(points: pd.DataFrame, fixed_inputs: dict[str, tuple[pd.DataFrame, np.ndarray, pd.Series]] | None = None) -> dict[str, Any]:
    # fixed_inputs is reconstructed by the caller only when an expensive LONO check is needed.
    primary = select(points, -0.5, 6.0, 0.0)
    raw, n5, n3, maximum = classify(primary)
    out: dict[str, Any] = {
        "raw_primary": raw, "raw_n_blocks_gt5": n5, "raw_n_blocks_gt3": n3,
        "raw_max_block_residual": maximum, "single_point_survives": False,
        "two_band_coherent": False, "lono_all_survive": False, "lono_refits_valid": False,
        "n_trigger_nights": 0, "structurally_confirmed": False,
    }
    if not raw:
        return out
    extreme_idx = primary["residual_sigma"].idxmax()
    out["single_point_survives"] = classify(primary.drop(index=extreme_idx))[0]
    block = primary.groupby(["band", "night"])["residual_sigma"].max()
    positive_bands = set(block[block > 3.0].index.get_level_values("band"))
    out["two_band_coherent"] = {"c", "o"}.issubset(positive_bands)
    trigger_nights = sorted(set(int(x) for x in block[block > 3.0].index.get_level_values("night")))
    out["n_trigger_nights"] = len(trigger_nights)
    # LONO is evaluated in a separate helper because it needs injected flux arrays.
    return out


def lono_confirmation(oid: str, template: dict[str, Any], realization: int, trigger_nights: list[int]) -> tuple[bool, bool]:
    contract, methods, engine = G["contract"], G["methods"], G["engine"]
    od = G["data"][G["data"]["object_id"] == oid].copy()
    ofits = G["fits"][G["fits"]["object_id"] == oid].copy()
    z = float(od["redshift"].median())
    z = z if np.isfinite(z) else 0.0
    shared_anchor = float(ofits["t0"].median())
    seed_text = f"{contract['random_seed']}|{oid}|{template['template_id']}|{realization}"
    rng = np.random.default_rng(int(hashlib.sha256(seed_text.encode()).hexdigest()[:16], 16))
    phase_jitter = float(rng.normal(0.0, contract["injection_mode"]["phase_jitter_days"]))
    amplitude_jitter = float(max(0.0, rng.normal(1.0, contract["injection_mode"]["amplitude_jitter_fraction"])))
    every_survives = True
    every_refit_valid = True
    for omitted_night in trigger_nights:
        parts: list[dict[str, Any]] = []
        this_valid = True
        for prefit in ofits.itertuples(index=False):
            full = od[od["band"] == prefit.band].sort_values("mjd").copy()
            peak_mjd = shared_anchor + (float(template["phase_peak_days"]) + phase_jitter) * (1.0 + z)
            width_obs = float(template["width_days"]) * (1.0 + z)
            scale = float(template["c_scale"] if prefit.band == "c" else template["o_scale"])
            eff_pre = np.sqrt(full["fluxerr"].to_numpy(float) ** 2 + float(prefit.extra_scatter) ** 2)
            bump = float(template["peak_sigma"]) * scale * amplitude_jitter * float(np.median(eff_pre)) * np.exp(
                -0.5 * ((full["mjd"].to_numpy(float) - peak_mjd) / width_obs) ** 2
            )
            full["injected_flux"] = full["flux"].to_numpy(float) + bump
            train = full[np.floor(full["mjd"]).astype(int) != int(omitted_night)].copy()
            result = engine.refit_band(
                train, train["injected_flux"].to_numpy(float), methods["baseline"], "free",
                pd.Series(prefit._asdict()), "frozen-pre-injection",
            )
            if not result["success"]:
                this_valid = False
                continue
            phase = (train["mjd"].to_numpy(float) - float(result["t0"])) / (1.0 + z)
            for idx, row in enumerate(train.itertuples(index=False)):
                parts.append({"band": str(prefit.band), "mjd": float(row.mjd),
                              "night": int(np.floor(float(row.mjd))), "phase": float(phase[idx]),
                              "residual_sigma": float(result["residual_sigma"][idx])})
        every_refit_valid = every_refit_valid and this_valid
        if not this_valid or not classify(select(pd.DataFrame(parts), -0.5, 6.0, 0.0))[0]:
            every_survives = False
    return every_survives, every_refit_valid


def run_host(task: tuple[str, str]) -> tuple[str, list[dict[str, Any]]]:
    oid, contract_hash = task
    contract, canonical = G["contract"], G["canonical"]
    rows: list[dict[str, Any]] = []
    windows = contract["one_at_a_time_population_grid"]["signal_windows_days"]
    offsets = contract["one_at_a_time_population_grid"]["named_phase_zero_offsets_days"]
    for template in canonical["templates"]:
        for realization in range(int(contract["injection_mode"]["realizations_per_host_template"])):
            parts, all_success, complete, phase_jitter, amplitude_jitter, trial_seed = fit_injected_host(oid, template, realization)
            points = pd.DataFrame(parts)
            confirmation = structural_confirmation(points)
            if confirmation["raw_primary"] and confirmation["single_point_survives"] and confirmation["two_band_coherent"]:
                primary = select(points, -0.5, 6.0, 0.0)
                block = primary.groupby(["band", "night"])["residual_sigma"].max()
                trigger_nights = sorted(set(int(x) for x in block[block > 3.0].index.get_level_values("night")))
                lono_survives, lono_valid = lono_confirmation(oid, template, realization, trigger_nights)
                confirmation["lono_all_survive"] = lono_survives
                confirmation["lono_refits_valid"] = lono_valid
            confirmation["structurally_confirmed"] = bool(
                confirmation["raw_primary"] and confirmation["single_point_survives"]
                and confirmation["two_band_coherent"] and confirmation["lono_all_survive"]
                and confirmation["lono_refits_valid"]
            )
            row: dict[str, Any] = {
                "object_id": oid, "template_id": template["template_id"], "realization": realization,
                "trial_seed": trial_seed, "phase_jitter_days": phase_jitter,
                "amplitude_jitter_factor": amplitude_jitter, "all_band_refits_success": all_success,
                "all_valid_bands_present": complete, **confirmation,
                "contract_sha256": contract_hash, "version": VERSION,
            }
            for lo, hi in windows:
                key = f"window_{str(lo).replace('-', 'm').replace('.', 'p')}_{str(hi).replace('.', 'p')}"
                row[key] = classify(select(points, lo, hi, 0.0))[0]
            for offset in offsets:
                key = f"phase_offset_{str(offset).replace('-', 'm').replace('.', 'p')}"
                row[key] = classify(select(points, -0.5, 6.0, offset))[0]
            rows.append(row)
    return oid, rows


def valid_checkpoint(path: Path, contract_hash: str) -> bool:
    try:
        d = pd.read_csv(path)
        return len(d) == 150 and d["contract_sha256"].eq(contract_hash).all() and not d.duplicated(["object_id", "template_id", "realization"]).any()
    except Exception:  # noqa: BLE001
        return False


def atomic_csv(rows: list[dict[str, Any]], path: Path) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    pd.DataFrame(rows).to_csv(tmp, index=False)
    os.replace(tmp, path)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=".")
    parser.add_argument("--workers", type=int, default=8)
    parser.add_argument("--max-hosts", type=int, default=0, help="Validation only; 0 runs all 287 hosts")
    args = parser.parse_args()
    root = Path(args.root).resolve()
    contract_path = root / "config/v48m6_end_to_end_contract.json"
    freeze_path = root / "config/v48m6_end_to_end_contract_freeze.json"
    contract = json.loads(contract_path.read_text(encoding="utf-8"))
    freeze = json.loads(freeze_path.read_text(encoding="utf-8"))
    contract_hash = sha256(contract_path)
    if freeze["sha256"]["config/v48m6_end_to_end_contract.json"] != contract_hash:
        raise RuntimeError("V48M6 outcome-blind contract hash gate failed")
    for rel, expected in freeze["sha256"].items():
        if sha256(root / rel) != expected:
            raise RuntimeError(f"Frozen input hash changed: {rel}")
    objects = pd.read_csv(root / "results/v48_canonical/baseline/v48b_object_summary.csv")
    hosts = sorted(objects.loc[truthy(objects["fit_valid"]) & (pd.to_numeric(objects["median_chi2_dof"], errors="coerce") <= 10.0), "object_id"].astype(str))
    if len(hosts) != EXPECTED_HOSTS:
        raise RuntimeError(f"Expected {EXPECTED_HOSTS} union hosts, found {len(hosts)}")
    production = args.max_hosts == 0
    if not production:
        hosts = hosts[:max(1, args.max_hosts)]
    out = root / "results/v48m6_end_to_end/production"
    checkpoints = out / "checkpoints"
    checkpoints.mkdir(parents=True, exist_ok=True)
    tasks = [(oid, contract_hash) for oid in hosts if not valid_checkpoint(checkpoints / f"{oid}.csv", contract_hash)]
    start = time.time()
    completed = len(hosts) - len(tasks)
    print(f"V48M6 resume: {completed}/{len(hosts)} checkpoints complete", flush=True)
    with ProcessPoolExecutor(max_workers=max(1, int(args.workers)), initializer=worker_init, initargs=(str(root),)) as pool:
        futures = {pool.submit(run_host, task): task[0] for task in tasks}
        for future in as_completed(futures):
            oid, rows = future.result()
            if len(rows) != 150:
                raise RuntimeError(f"{oid}: expected 150 rows, got {len(rows)}")
            atomic_csv(rows, checkpoints / f"{oid}.csv")
            completed += 1
            print(f"V48M6 progress: {completed}/{len(hosts)} host checkpoints complete", flush=True)
    trials = pd.concat([pd.read_csv(checkpoints / f"{oid}.csv") for oid in hosts], ignore_index=True)
    unique = not trials.duplicated(["object_id", "template_id", "realization"]).any()
    all_success = bool(truthy(trials["all_band_refits_success"]).all())
    gate = bool(production and len(hosts) == EXPECTED_HOSTS and len(trials) == EXPECTED_TRIALS and unique and all_success)
    if production:
        trials.to_csv(out / "v48m6_injection_trials_43050.csv.gz", index=False, compression="gzip")
    else:
        trials.to_csv(out / f"v48m6_validation_trials_{len(trials)}.csv", index=False)
    summary = {
        "status": "V48M6_END_TO_END_PRODUCTION_COMPLETE" if gate else "V48M6_VALIDATION_COMPLETE",
        "version": VERSION, "gate_pass": gate if production else bool(unique and all_success),
        "production": production, "hosts": len(hosts), "trials": len(trials),
        "all_refits_success": all_success, "unique_trial_keys": unique,
        "raw_primary_recoveries": int(truthy(trials["raw_primary"]).sum()),
        "structural_confirmations": int(truthy(trials["structurally_confirmed"]).sum()),
        "workers": max(1, int(args.workers)), "elapsed_seconds": time.time() - start,
        "contract_sha256": contract_hash,
    }
    (out / ("v48m6_production_summary.json" if production else "v48m6_validation_summary.json")).write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps(summary, indent=2), flush=True)
    return 0 if summary["gate_pass"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
